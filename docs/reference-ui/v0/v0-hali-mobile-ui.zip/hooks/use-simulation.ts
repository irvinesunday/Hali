"use client"

import { useEffect, useCallback, useRef } from "react"

// Accelerated time model: 10s real ≈ 2 min simulated
// This means 1 real second = 12 simulated seconds
const TIME_MULTIPLIER = 12

// Convert real milliseconds to simulated milliseconds
export function toSimulatedTime(realMs: number): number {
  return realMs * TIME_MULTIPLIER
}

// Get simulated age in minutes from a createdAt timestamp
export function getSimulatedAgeMinutes(createdAt: number): number {
  const realAge = Date.now() - createdAt
  return Math.floor(toSimulatedTime(realAge) / 60000)
}

// Format simulated time for "last checked" display
export function getSimulatedLastCheckedText(timestamp: number): string {
  const ageMinutes = getSimulatedAgeMinutes(timestamp)
  
  if (ageMinutes < 1) return "just now"
  if (ageMinutes < 5) return "~2 min ago"
  if (ageMinutes < 10) return "~5 min ago"
  if (ageMinutes < 20) return "~10 min ago"
  if (ageMinutes < 40) return "~20 min ago"
  if (ageMinutes < 60) return "~30 min ago"
  
  const hours = Math.floor(ageMinutes / 60)
  if (hours < 24) return `~${hours} hr${hours > 1 ? 's' : ''} ago`
  
  return "~1 day ago"
}

// Signal lifecycle stages
export type LifecycleStage = 
  | "unconfirmed"         // Stage 1: Just reported
  | "growing"             // Stage 2: Reports coming in
  | "steady"              // Stage 3: Steady reports
  | "stabilizing"         // Stage 4: Reports slowing / possible restoration
  | "possible-restoration" // Stage 4b: Restoration in progress
  | "resolved"            // Stage 5: Resolved

// Official update stages (synchronized with signal lifecycle)
export type OfficialStage = 
  | "none"                // No official update yet
  | "dispatched"          // "Teams have been dispatched"
  | "on-site"             // "Teams are on site assessing"
  | "working"             // "Work is ongoing to resolve"
  | "restoring"           // "Restoration is in progress"
  | "restored"            // "Service has been restored"

export interface LifecycleInfo {
  stage: LifecycleStage
  label: string
  activityText: string
  showLive: boolean
  liveIntensity: "strong" | "soft" | "dim" | "none"
  shouldFade: boolean
  shouldHide: boolean
  officialStage: OfficialStage
}

// Signal progression speed factors (assigned per signal)
export type ProgressionSpeed = "fast" | "normal" | "slow" | "stalled"

// Get random progression speed for a signal
// Many livability issues are slow to resolve or persist indefinitely
export function getRandomProgressionSpeed(): ProgressionSpeed {
  const rand = Math.random()
  if (rand < 0.08) return "fast"      // 8% fast (rare quick resolution)
  if (rand < 0.30) return "normal"    // 22% normal progression
  if (rand < 0.65) return "slow"      // 35% slow (most signals)
  return "stalled"                     // 35% stalled (ongoing issues that don't resolve)
}

// Time thresholds for lifecycle stages (in simulated minutes)
// These are base values, modified by progression speed
// EXTENDED: Signals stay active MUCH longer - most never fully resolve in demo
const STAGE_THRESHOLDS = {
  unconfirmed: 0,     // 0-8 min simulated (~40s real)
  growing: 8,         // 8-30 min simulated (~2.5 min real)
  steady: 30,         // 30-90 min simulated (~7.5 min real)
  stabilizing: 90,    // 90-150 min simulated (~12 min real)
  restoration: 150,   // 150-200 min simulated (~15 min real)
  resolved: 200,      // >200 min simulated (~16+ min real - most won't reach)
}

// Get speed multiplier for progression
function getSpeedMultiplier(speed: ProgressionSpeed): number {
  switch (speed) {
    case "fast": return 0.6      // 60% of normal time
    case "normal": return 1.0
    case "slow": return 1.5      // 150% of normal time
    case "stalled": return 999   // Never reaches later stages
  }
}

// Determine if signal will get official updates (most remain citizen-only)
export function willGetOfficialUpdate(signalId: string): boolean {
  // Use signal ID to create deterministic randomness
  const hash = signalId.split('').reduce((a, b) => a + b.charCodeAt(0), 0)
  // Only 25% of signals get official updates - most stay citizen-led
  return (hash % 100) < 25
}

// Get official delay in simulated minutes (before first official appears)
export function getOfficialDelay(signalId: string): number {
  const hash = signalId.split('').reduce((a, b) => a + b.charCodeAt(0), 0)
  // Delay between 15-35 simulated minutes (1.5-3 min real time) - officials respond slowly
  return 15 + (hash % 20)
}

export function getLifecycleInfo(
  createdAt: number, 
  affectedCount: number = 1,
  progressionSpeed: ProgressionSpeed = "normal",
  signalId: string = "",
  observingCount: number = 0
): LifecycleInfo {
  // Total participation affects lifecycle progression
  const totalParticipation = affectedCount + observingCount
  const ageMinutes = getSimulatedAgeMinutes(createdAt)
  const speedMult = getSpeedMultiplier(progressionSpeed)
  
  // Adjust thresholds by speed
  const t = {
    unconfirmed: 0,
    growing: Math.floor(STAGE_THRESHOLDS.growing * speedMult),
    steady: Math.floor(STAGE_THRESHOLDS.steady * speedMult),
    stabilizing: Math.floor(STAGE_THRESHOLDS.stabilizing * speedMult),
    restoration: Math.floor(STAGE_THRESHOLDS.restoration * speedMult),
    resolved: Math.floor(STAGE_THRESHOLDS.resolved * speedMult),
  }
  
  // Determine official stage based on signal stage + delay
  const hasOfficialSupport = willGetOfficialUpdate(signalId)
  const officialDelay = getOfficialDelay(signalId)
  const officialAge = ageMinutes - officialDelay
  
  let officialStage: OfficialStage = "none"
  if (hasOfficialSupport && officialAge >= 0) {
    // Officials progress SLOWLY - most signals stay at early stages
    // Thresholds in simulated minutes: real seconds = value / 12 * 60
    if (officialAge < 15) officialStage = "dispatched"        // 0-15 min (~75s real)
    else if (officialAge < 40) officialStage = "on-site"      // 15-40 min (~2-3 min real)
    else if (officialAge < 80) officialStage = "working"      // 40-80 min (~4-6 min real)
    else if (officialAge < 120) officialStage = "restoring"   // 80-120 min (~6-10 min real)
    else officialStage = "restored"                            // >120 min (>10 min real)
    // Most signals won't reach "restored" in a typical demo session
  }
  
  // Stage 1: Unconfirmed (until total participation > 1 OR time passes)
  // Once ANY confirmations arrive (affected OR observing), move to growing stage
  if (totalParticipation <= 1 && ageMinutes < t.growing) {
    return {
      stage: "unconfirmed",
      label: "Unconfirmed report",
      activityText: "Recently reported",
      showLive: true,
      liveIntensity: "strong",
      shouldFade: false,
      shouldHide: false,
      officialStage,
    }
  }
  
  // Stage 2: Growing - label updates based on total participation
  if (ageMinutes < t.steady) {
    // Dynamic labels based on how many confirmations (affected + observing)
    let label: string
    let activityText: string
    
    if (totalParticipation === 2) {
      label = "Reports coming in"
      activityText = "Being confirmed"
    } else if (totalParticipation <= 4) {
      label = "Based on nearby reports"
      activityText = "Reports increasing"
    } else if (totalParticipation <= 8) {
      label = "Active reports"
      activityText = "Multiple confirmations"
    } else {
      label = "Growing quickly"
      activityText = "Reports rising"
    }
    
    return {
      stage: "growing",
      label,
      activityText,
      showLive: true,
      liveIntensity: "strong",
      shouldFade: false,
      shouldHide: false,
      officialStage,
    }
  }
  
  // Stage 3: Steady (12-30 min simulated) - label varies by total participation
  if (ageMinutes < t.stabilizing) {
    const label = totalParticipation > 10 ? "Widely reported" : "Steady reports"
    return {
      stage: "steady",
      label,
      activityText: "Steady activity",
      showLive: true,
      liveIntensity: "soft",
      shouldFade: false,
      shouldHide: false,
      officialStage,
    }
  }
  
  // Stage 4: Stabilizing - reports slowing down
  if (ageMinutes < t.restoration) {
    // If official says restored, signal should reflect that immediately
    if (officialStage === "restored") {
      return {
        stage: "possible-restoration",
        label: "Restoration confirmed",
        activityText: "Officials confirm restored",
        showLive: false,
        liveIntensity: "none",
        shouldFade: true,
        shouldHide: false,
        officialStage,
      }
    }
    // If official is working on restoration, show progress
    if (officialStage === "restoring") {
      return {
        stage: "possible-restoration",
        label: "Being addressed",
        activityText: "Work ongoing",
        showLive: true,
        liveIntensity: "dim",
        shouldFade: false,
        shouldHide: false,
        officialStage,
      }
    }
    // Citizen-led: if reports are slowing naturally (no officials involved)
    return {
      stage: "stabilizing",
      label: "Reports slowing",
      activityText: officialStage === "none" ? "Check if resolved" : "Stabilizing",
      showLive: true,
      liveIntensity: "dim",
      shouldFade: false,
      shouldHide: false,
      officialStage,
    }
  }
  
  // Stage 4b: Possible restoration - citizen-led resolution becomes primary
  if (ageMinutes < t.resolved) {
    // Official confirmed restoration
    if (officialStage === "restored") {
      return {
        stage: "possible-restoration",
        label: "Restoration confirmed",
        activityText: "Officially resolved",
        showLive: false,
        liveIntensity: "none",
        shouldFade: true,
        shouldHide: false,
        officialStage,
      }
    }
    // Citizen-led resolution: ask users if it's better
    // This is the key moment - signals can resolve via citizen feedback WITHOUT officials
    return {
      stage: "possible-restoration",
      label: "Has it improved?",
      activityText: "Check your status",
      showLive: false,
      liveIntensity: "none",
      shouldFade: true,
      shouldHide: false,
      officialStage,
    }
  }
  
  // Stage 5: Resolved or ongoing
  // Stalled signals stay as ongoing issues (common for livability problems)
  if (progressionSpeed === "stalled") {
    return {
      stage: "steady",
      label: "Ongoing issue",
      activityText: "Still reported",
      showLive: true,
      liveIntensity: "dim",
      shouldFade: false,
      shouldHide: false,
      officialStage,
    }
  }
  
  // Natural resolution - citizen-led or official
  const resolvedLabel = officialStage === "restored" 
    ? "Service restored" 
    : "Appears resolved"
  
  return {
    stage: "resolved",
    label: resolvedLabel,
    activityText: officialStage === "restored" ? "Officially resolved" : "Naturally resolved",
    showLive: false,
    liveIntensity: "none",
    shouldFade: true,
    shouldHide: true,
    officialStage,
  }
}

// Get duration text with variable base duration
export function getSimulatedDuration(createdAt: number, baseDuration?: number): string | null {
  const ageMinutes = getSimulatedAgeMinutes(createdAt)
  
  // Apply base duration offset if provided
  const displayMinutes = baseDuration ? baseDuration + ageMinutes : ageMinutes
  
  if (displayMinutes < 2) return null // "Just reported"
  
  if (displayMinutes < 60) {
    // Round to nice numbers: 2, 5, 10, 12, 15, 20, 25, 30, 37, 45, etc.
    const rounded = displayMinutes < 10 
      ? displayMinutes 
      : Math.round(displayMinutes / 5) * 5
    return `~${rounded} min`
  }
  
  const hours = Math.floor(displayMinutes / 60)
  const remainingMin = displayMinutes % 60
  
  if (remainingMin < 10) {
    return `~${hours} hr${hours > 1 ? 's' : ''}`
  } else if (remainingMin < 30) {
    return `~${hours} hr ${Math.round(remainingMin / 10) * 10} min`
  } else {
    return `~${hours} hr ${Math.round(remainingMin / 10) * 10} min`
  }
}

// Get random base duration for new signal (in simulated minutes)
// Uses varied values to avoid clustering around "~45 min"
export function getRandomBaseDuration(): number {
  const rand = Math.random()
  // More variety in durations to make signals feel realistic
  if (rand < 0.20) return Math.floor(3 + Math.random() * 5)     // 20%: 3-8 min (very recent)
  if (rand < 0.40) return Math.floor(9 + Math.random() * 9)     // 20%: 9-18 min
  if (rand < 0.60) return Math.floor(20 + Math.random() * 15)   // 20%: 20-35 min
  if (rand < 0.80) return Math.floor(40 + Math.random() * 15)   // 20%: 40-55 min
  if (rand < 0.92) return Math.floor(65 + Math.random() * 20)   // 12%: ~1 hr 5-25 min
  return Math.floor(90 + Math.random() * 30)                     // 8%: ~1.5-2 hrs
}

// Calculate priority score for ordering signals
export function calculatePriorityScore(signal: {
  createdAt: number
  affectedCount: number
  observingCount?: number
  lifecycleStage?: LifecycleStage
}): number {
  const totalParticipation = signal.affectedCount + (signal.observingCount || 0)
  const lifecycle = signal.lifecycleStage || getLifecycleInfo(signal.createdAt, signal.affectedCount).stage
  const ageMinutes = getSimulatedAgeMinutes(signal.createdAt)
  
  let score = 0
  
  // Base score from TOTAL participation (affected + observing both matter)
  // Observing counts slightly less than affected but still contributes
  score += signal.affectedCount * 20
  score += (signal.observingCount || 0) * 15
  
  // Recency bonus (newer signals get boosted, decays over time)
  score += Math.max(0, 200 - ageMinutes * 3)
  
  // Lifecycle stage modifiers (stronger weights for visible transitions)
  switch (lifecycle) {
    case "unconfirmed":
      score += 100 // Boost new signals to top visibility
      break
    case "growing":
      score += 180 // Highest priority for growing signals
      break
    case "steady":
      score += 60
      break
    case "stabilizing":
      score -= 50 // Push down more aggressively
      break
    case "possible-restoration":
      score -= 120
      break
    case "resolved":
      score -= 200
      break
  }
  
  return score
}

// Official update message based on stage
export function getOfficialMessage(stage: OfficialStage, issueType: "power" | "road" | "flooding"): string {
  const messages: Record<OfficialStage, Record<string, string>> = {
    none: {
      power: "",
      road: "",
      flooding: "",
    },
    dispatched: {
      power: "Teams have been dispatched to assess the situation.",
      road: "Road maintenance teams have been notified and are en route.",
      flooding: "Emergency response teams have been dispatched to the area.",
    },
    "on-site": {
      power: "Technicians are on site assessing the extent of the outage.",
      road: "Teams are on site evaluating road conditions.",
      flooding: "Response teams are on site assessing water levels.",
    },
    working: {
      power: "Work is ongoing to restore power supply to affected areas.",
      road: "Repair work is in progress. Please use alternative routes.",
      flooding: "Drainage clearing and pumping operations are underway.",
    },
    restoring: {
      power: "Restoration is in progress. Power returning to some areas.",
      road: "Road repairs nearing completion. Lane partially open.",
      flooding: "Water levels receding. Road becoming passable.",
    },
    restored: {
      power: "Power has been restored to the affected area.",
      road: "Road repairs complete. Normal traffic resumed.",
      flooding: "Flooding cleared. Road fully passable.",
    },
  }
  
  return messages[stage][issueType] || ""
}

// Get official update time text based on stage
export function getOfficialTimeText(stage: OfficialStage): string {
  switch (stage) {
    case "dispatched": return "~5 min ago"
    case "on-site": return "~10 min ago"
    case "working": return "~15 min ago"
    case "restoring": return "~20 min ago"
    case "restored": return "~25 min ago"
    default: return ""
  }
}

// Should signal have an official update visible?
export function shouldShowOfficialUpdate(
  signalId: string, 
  createdAt: number
): boolean {
  if (!willGetOfficialUpdate(signalId)) return false
  
  const ageMinutes = getSimulatedAgeMinutes(createdAt)
  const officialDelay = getOfficialDelay(signalId)
  
  return ageMinutes >= officialDelay
}

// Determine if a signal type is "experiential" (no observing option)
// Experiential = you either have the problem or you don't (power, water)
// Observable = you can see it without being directly affected (garbage, noise, road)
export function isExperientialSignal(type: "power" | "road" | "flooding", category?: SignalCategory): boolean {
  // Electricity and water are experiential - you're either affected or not
  if (category === "electricity" || category === "water") return true
  // Legacy: power type without category
  if (type === "power" && !category) return true
  // Everything else can be observed: garbage, noise, dust, flooding, road issues, etc.
  return false
}

// Signal categories - expanded for livability signals
type SignalCategory = "electricity" | "water" | "road" | "flooding" | "garbage" | "noise" | "smell" | "dust" | "lighting" | "safety" | "crowding" | "encroachment"

// Location-aware signal templates per locality
interface SignalTemplate {
  title: string
  condition: string
  type: "power" | "road" | "flooding"
  category: SignalCategory // Semantic category - determines institution
  locations: string[]
  experiential?: boolean // If true, only "I'm Affected" option (like power/water)
}

// EXPANDED: More experiential/livability signals - the app is a "livability radar" not just crisis tracker
const signalTemplatesByLocality: Record<string, SignalTemplate[]> = {
  "south-b": [
    // Infrastructure
    { title: "Power outage reported", condition: "No power", type: "power", category: "electricity", experiential: true,
      locations: ["near Capital Centre", "along Mombasa Road", "by South B shopping center"] },
    { title: "Water supply disruption", condition: "No water", type: "power", category: "water", experiential: true,
      locations: ["in South B estate", "near Nyayo Stadium", "along Muhoho Avenue"] },
    { title: "Low water pressure", condition: "Weak pressure", type: "power", category: "water", experiential: true,
      locations: ["in South B flats", "near the mosque", "along inner roads"] },
    // Livability - Garbage/Smell
    { title: "Garbage piling up", condition: "Uncollected waste", type: "road", category: "garbage",
      locations: ["near South B market", "by collection point", "along estate entrance"] },
    { title: "Bad smell from drainage", condition: "Sewage smell", type: "road", category: "smell",
      locations: ["near the drainage", "by open channel", "along Muhoho Avenue"] },
    // Livability - Noise
    { title: "Loud generator running", condition: "Noise disturbance", type: "road", category: "noise",
      locations: ["near shops", "by apartment block", "along main road"] },
    { title: "Construction noise", condition: "Noisy construction", type: "road", category: "noise",
      locations: ["near new building site", "by residential area", "along access road"] },
    // Road/Traffic
    { title: "Flooding on road", condition: "Partially flooded", type: "flooding", category: "flooding",
      locations: ["near Nyayo roundabout", "along South B road", "by the drainage channel"] },
    { title: "Matatus blocking road", condition: "Lane blocked", type: "road", category: "road",
      locations: ["near stage area", "at T-Mall junction", "by petrol station"] },
    { title: "Dusty unpaved road", condition: "Very dusty", type: "road", category: "dust",
      locations: ["along back roads", "near construction", "by estate entrance"] },
    // Safety/Lighting
    { title: "Street light not working", condition: "Dark area", type: "road", category: "lighting",
      locations: ["near estate gate", "along inner road", "by walkway"] },
  ],
  "nairobi-west": [
    // Infrastructure
    { title: "Power fluctuations", condition: "Unstable power", type: "power", category: "electricity", experiential: true,
      locations: ["in Nairobi West estate", "near shopping area", "along Ring Road"] },
    { title: "Intermittent power", condition: "Power going on/off", type: "power", category: "electricity", experiential: true,
      locations: ["near Nairobi West shops", "in residential area", "along main street"] },
    // Livability - Garbage
    { title: "Waste piling up", condition: "Uncollected waste", type: "road", category: "garbage",
      locations: ["near market area", "along main road", "by residential entrance"] },
    { title: "Illegal dumping spotted", condition: "Dumped waste", type: "road", category: "garbage",
      locations: ["by roadside", "near empty plot", "along back road"] },
    // Livability - Noise/Smell
    { title: "Loud music from bar", condition: "Noise late night", type: "road", category: "noise",
      locations: ["near entertainment spot", "along main road", "by residential flats"] },
    { title: "Smoke from burning", condition: "Air pollution", type: "road", category: "smell",
      locations: ["near dump site", "by open area", "along estate edge"] },
    // Road
    { title: "Potholes getting worse", condition: "Multiple potholes", type: "road", category: "road",
      locations: ["along Lusaka Road", "near Community Centre", "at Uhuru Highway junction"] },
    { title: "Matatus blocking lane", condition: "Lane blocked", type: "road", category: "road",
      locations: ["near stage area", "along Langata Road", "by the bus stop"] },
    // Crowding/Encroachment
    { title: "Street vendors blocking walkway", condition: "Sidewalk blocked", type: "road", category: "encroachment",
      locations: ["near market", "along main street", "by shopping area"] },
    { title: "Overcrowded matatu stage", condition: "Very crowded", type: "road", category: "crowding",
      locations: ["at main stage", "near junction", "by bus stop"] },
  ],
  "industrial-area": [
    // Road/Traffic
    { title: "Trucks blocking lane", condition: "Lane blocked", type: "road", category: "road",
      locations: ["near Enterprise Road", "along main corridor", "by factory gates"] },
    { title: "Traffic obstruction", condition: "Slow moving", type: "road", category: "road",
      locations: ["at Industrial Area junction", "near weighbridge", "along Lunga Lunga"] },
    { title: "Road damage reported", condition: "Poor road condition", type: "road", category: "road",
      locations: ["on Enterprise Road", "near Industrial Area exit", "along access road"] },
    // Environment
    { title: "Factory smoke visible", condition: "Air pollution", type: "road", category: "smell",
      locations: ["near industrial zone", "along main corridor", "by factory area"] },
    { title: "Strong chemical smell", condition: "Bad smell", type: "road", category: "smell",
      locations: ["near factories", "along road", "by drainage"] },
    { title: "Dusty road section", condition: "Very dusty", type: "road", category: "dust",
      locations: ["near construction", "along unpaved stretch", "by access road"] },
    // Flooding
    { title: "Flooding near corridor", condition: "Water on road", type: "flooding", category: "flooding",
      locations: ["near drainage area", "along low section", "by bridge underpass"] },
    // Safety
    { title: "Poorly lit stretch", condition: "No street lights", type: "road", category: "lighting",
      locations: ["along corridor", "near factory exit", "by junction"] },
  ],
  "upper-hill": [
    // Infrastructure
    { title: "Power interruption", condition: "Power outage", type: "power", category: "electricity", experiential: true,
      locations: ["in Upper Hill area", "near hospital road", "along Ralph Bunche"] },
    { title: "Water supply issue", condition: "Low pressure", type: "power", category: "water", experiential: true,
      locations: ["in Upper Hill estate", "near Kenyatta Hospital", "along Community Road"] },
    // Road
    { title: "Minor road obstruction", condition: "Partially blocked", type: "road", category: "road",
      locations: ["near office complex", "along Hospital Road", "by parking area"] },
    { title: "Double parking blocking road", condition: "Road narrowed", type: "road", category: "road",
      locations: ["near offices", "along main road", "by hospital entrance"] },
    // Environment
    { title: "Construction dust", condition: "Dusty air", type: "road", category: "dust",
      locations: ["near building site", "along road", "by new development"] },
    { title: "Garbage not collected", condition: "Overflowing bins", type: "road", category: "garbage",
      locations: ["near office block", "by parking", "along walkway"] },
  ],
  "kilimani": [
    // Infrastructure
    { title: "Power outage", condition: "No power", type: "power", category: "electricity", experiential: true,
      locations: ["in Kilimani area", "near Ring Road", "along Argwings Kodhek"] },
    { title: "Water disruption", condition: "No water", type: "power", category: "water", experiential: true,
      locations: ["in Kilimani estate", "near Yaya Centre", "along Dennis Pritt Road"] },
    // Livability
    { title: "Noisy construction ongoing", condition: "Noise disturbance", type: "road", category: "noise",
      locations: ["near residential area", "along main road", "by apartment complex"] },
    { title: "Blocked drainage causing smell", condition: "Bad smell", type: "road", category: "smell",
      locations: ["near junction", "along back road", "by residential entrance"] },
    { title: "Street light out", condition: "Dark stretch", type: "road", category: "lighting",
      locations: ["along quiet road", "near apartments", "by corner"] },
    // Road
    { title: "Potholes forming", condition: "Road damage", type: "road", category: "road",
      locations: ["along side street", "near junction", "by parking area"] },
  ],
  "westlands": [
    // Traffic
    { title: "Traffic jam building", condition: "Heavy traffic", type: "road", category: "road",
      locations: ["near Westgate", "along Waiyaki Way", "at Westlands roundabout"] },
    { title: "Matatus blocking lanes", condition: "Lane blocked", type: "road", category: "road",
      locations: ["near stage", "along main road", "by mall entrance"] },
    // Infrastructure
    { title: "Power fluctuation", condition: "Unstable power", type: "power", category: "electricity", experiential: true,
      locations: ["in Westlands area", "near Sarit Centre", "along Muthithi Road"] },
    // Livability
    { title: "Overcrowded walkway", condition: "Pedestrian congestion", type: "road", category: "crowding",
      locations: ["near mall entrance", "along busy street", "by bus stop"] },
    { title: "Vendors encroaching sidewalk", condition: "Walkway blocked", type: "road", category: "encroachment",
      locations: ["near shopping area", "along main street", "by junction"] },
    { title: "Garbage overflowing", condition: "Uncollected waste", type: "road", category: "garbage",
      locations: ["near eateries", "along back street", "by market area"] },
    { title: "Loud generator noise", condition: "Noisy", type: "road", category: "noise",
      locations: ["near shop", "along road", "by office block"] },
  ],
}

// Get a random signal template for a locality
function getRandomSignalForLocality(localityId: string): SignalTemplate | null {
  const templates = signalTemplatesByLocality[localityId]
  if (!templates || templates.length === 0) return null
  return templates[Math.floor(Math.random() * templates.length)]
}

// Hook for background activity simulation
export function useBackgroundSimulation(
  onAddAffected: (signalId: string) => void,
  onAddObserving: (signalId: string) => void,
  onCreateSignal: (params: {
    title: string
    condition: string
    type: "power" | "road" | "flooding"
    category: SignalCategory
    location: string
    locality: string
    progressionSpeed: ProgressionSpeed
    baseDuration: number
  }) => void,
  activeSignalIds: string[],
  followedAreas: string[]
) {
  const lastActivityRef = useRef<Record<string, number>>({})
  const autoAddsRef = useRef<Record<string, number>>({})
  const signalCreationTimeRef = useRef<Record<string, number>>({})
  const lastNewSignalRef = useRef<number>(Date.now())
  const areaLastActivityRef = useRef<Record<string, number>>({})
  
// Simulate background activity
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now()
      
      // For each active signal, simulate gradual growth
      // NEW signals get fast initial confirmations (8-15s), then slow down
      activeSignalIds.forEach(signalId => {
        const lastActivity = lastActivityRef.current[signalId] || 0
        const autoAdds = autoAddsRef.current[signalId] || 0
        const creationTime = signalCreationTimeRef.current[signalId] || now
        const timeSinceCreation = now - creationTime
        const timeSinceLastActivity = now - lastActivity
        
        // Track when signal was first seen
        if (!signalCreationTimeRef.current[signalId]) {
          signalCreationTimeRef.current[signalId] = now
        }
        
        // Check if this is a user-created or very new signal (< 60s old)
        const isNewSignal = timeSinceCreation < 60000
        const isUserSignal = signalId.startsWith("user-")
        
        let shouldAdd = false
        
        // FAST initial confirmations for new/user signals (8-15s intervals)
        if ((isNewSignal || isUserSignal) && autoAdds < 3) {
          const fastDelay = 8000 + Math.random() * 7000 // 8-15 seconds
          
          if (autoAdds === 0 && timeSinceCreation > fastDelay) {
            shouldAdd = true // First confirmation comes quickly
          } else if (autoAdds === 1 && timeSinceLastActivity > fastDelay) {
            shouldAdd = Math.random() > 0.1 // 90% chance for second
          } else if (autoAdds === 2 && timeSinceLastActivity > (10000 + Math.random() * 10000)) {
            shouldAdd = Math.random() > 0.2 // 80% chance for third (10-20s)
          }
        }
        // MODERATE growth for signals gaining traction (15-35s intervals)
        else if (autoAdds >= 3 && autoAdds < 6) {
          const moderateDelay = 15000 + Math.random() * 20000 // 15-35 seconds
          
          if (autoAdds === 3 && timeSinceLastActivity > moderateDelay) {
            shouldAdd = Math.random() > 0.35 // 65% chance
          } else if (autoAdds === 4 && timeSinceLastActivity > moderateDelay * 1.2) {
            shouldAdd = Math.random() > 0.45 // 55% chance
          } else if (autoAdds === 5 && timeSinceLastActivity > moderateDelay * 1.4) {
            shouldAdd = Math.random() > 0.55 // 45% chance
          }
        }
        // SLOW growth for mature signals (cap at believable levels)
        else if (autoAdds >= 6 && autoAdds < 12) {
          const slowDelay = 30000 + Math.random() * 30000 // 30-60 seconds
          
          if (timeSinceLastActivity > slowDelay) {
            shouldAdd = Math.random() > 0.7 // 30% chance
          }
        }
        
        if (shouldAdd) {
          // 70% affected, 30% observing (both contribute meaningfully)
          if (Math.random() > 0.3) {
            onAddAffected(signalId)
          } else {
            onAddObserving(signalId)
          }
          lastActivityRef.current[signalId] = now
          autoAddsRef.current[signalId] = autoAdds + 1
        }
      })
      
      // Create new signals (every 15-30 seconds real time for demo activity)
      const timeSinceLastNewSignal = now - lastNewSignalRef.current
      const createSignalThreshold = 15000 + Math.random() * 15000 // 15-30 seconds (high frequency for demo)
      
      if (timeSinceLastNewSignal > createSignalThreshold && followedAreas.length > 0) {
        // 20% chance to skip entirely (some natural variation)
        if (Math.random() > 0.20) {
          // Sort areas by last activity (oldest first)
          const sortedAreas = [...followedAreas].sort((a, b) => {
            const lastA = areaLastActivityRef.current[a] || 0
            const lastB = areaLastActivityRef.current[b] || 0
            return lastA - lastB
          })
          
          // 60% chance to pick the area with oldest activity, 40% random
          let selectedArea: string
          if (Math.random() > 0.4 && sortedAreas.length > 0) {
            selectedArea = sortedAreas[0]
          } else {
            selectedArea = followedAreas[Math.floor(Math.random() * followedAreas.length)]
          }
          
          const template = getRandomSignalForLocality(selectedArea)
          if (template) {
            const randomLocation = template.locations[Math.floor(Math.random() * template.locations.length)]
            
            onCreateSignal({
              title: `${template.title} ${randomLocation}`,
              condition: template.condition,
              type: template.type,
              category: template.category,
              location: randomLocation,
              locality: selectedArea,
              progressionSpeed: getRandomProgressionSpeed(),
              baseDuration: getRandomBaseDuration(),
            })
            
            areaLastActivityRef.current[selectedArea] = now
          }
        }
        
        lastNewSignalRef.current = now
      }
    }, 3000) // Check every 3 seconds for more responsive updates
    
    return () => clearInterval(interval)
  }, [activeSignalIds, followedAreas, onAddAffected, onAddObserving, onCreateSignal])
}

// Hook for time-based UI updates
export function useTimeUpdate(interval: number = 1000) {
  const updateRef = useRef<() => void>(() => {})
  
  useEffect(() => {
    const timer = setInterval(() => {
      updateRef.current()
    }, interval)
    
    return () => clearInterval(timer)
  }, [interval])
  
  const setUpdateCallback = useCallback((callback: () => void) => {
    updateRef.current = callback
  }, [])
  
  return { setUpdateCallback }
}
