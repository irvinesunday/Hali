"use client"

import { useState, useEffect, useCallback, useMemo } from "react"
import { type Issue } from "@/components/issue-card"
import { 
  getLifecycleInfo, 
  getSimulatedDuration, 
  calculatePriorityScore,
  shouldShowOfficialUpdate,
  getSimulatedLastCheckedText,
  getRandomProgressionSpeed,
  getRandomBaseDuration,
  isExperientialSignal,
  type LifecycleStage,
  type ProgressionSpeed,
} from "./use-simulation"

const STORAGE_KEY = "hali-app-state"

// Location to locality mapping
const locationToLocality: Record<string, string> = {
  "capital centre": "south-b",
  "south b": "south-b",
  "nyayo": "south-b",
  "stadium": "south-b",
  "langata": "south-b",
  "nairobi west": "nairobi-west",
  "community centre": "nairobi-west",
  "lusaka": "nairobi-west",
  "uhuru": "nairobi-west",
  "plainsview": "nairobi-west",
  "cfao": "nairobi-west",
  "industrial area": "industrial-area",
  "enterprise road": "industrial-area",
  "upper hill": "upper-hill",
  "kilimani": "kilimani",
  "ring road": "kilimani",
  "westlands": "westlands",
  "parklands": "westlands",
  "lavington": "kilimani",
  "ngong road": "kilimani",
  "mombasa road": "south-b",
}

// Infer locality from location text
export function inferLocality(locationText: string, defaultLocality: string = "nairobi-west"): string {
  const lower = locationText.toLowerCase()
  
  for (const [keyword, locality] of Object.entries(locationToLocality)) {
    if (lower.includes(keyword)) {
      return locality
    }
  }
  
  return defaultLocality
}

// Mock signals - the base data that always exists
// Using createdAt timestamps for lifecycle simulation
const mockSignalBaseTime = Date.now() - 30000 // Start 30s ago (simulated: ~6 min)

export const mockSignals: Issue[] = [
  {
    id: "mock-1",
    title: "Power outage affecting South B near Plainsview Rd",
    condition: "No power",
    affectedCount: 37,
    observingCount: 5,
    timeAgo: "Reported 45 min ago",
    duration: "~45 min",
    type: "power",
    category: "electricity", // Explicit category
    location: "South B — Plainsview Rd near XYZ",
    isLive: true,
    possibleRestoration: false,
    activityLevel: "steady",
    urgency: "standard",
    lastUpdated: "just now",
    createdAt: mockSignalBaseTime - 180000, // ~3 real min ago = ~36 simulated min
    hasOfficialUpdate: true,
  },
  {
    id: "mock-2",
    title: "Deep potholes slowing traffic at Lusaka Rd / Uhuru Hwy",
    condition: "Difficult to pass",
    affectedCount: 52,
    observingCount: 12,
    timeAgo: "Reported 2 hrs ago",
    duration: "~2 hrs",
    type: "road",
    category: "road", // Explicit category
    location: "Lusaka Rd / Uhuru Hwy intersection",
    isLive: true,
    activityLevel: "increasing",
    urgency: "elevated",
    lastUpdated: "2 min ago",
    createdAt: mockSignalBaseTime - 300000, // ~5 real min ago = ~60 simulated min
    hasOfficialUpdate: true,
  },
  {
    id: "mock-3",
    title: "Flooding making road impassable near Nyayo Stadium roundabout",
    condition: "Impassable",
    affectedCount: 21,
    observingCount: 8,
    timeAgo: "Reported 1 hr ago",
    duration: "~1 hr",
    type: "flooding",
    category: "flooding", // Explicit category
    location: "Nyayo Stadium roundabout",
    isLive: true,
    activityLevel: "recent",
    urgency: "elevated",
    lastUpdated: "5 min ago",
    createdAt: mockSignalBaseTime - 120000, // ~2 real min ago = ~24 simulated min
    hasOfficialUpdate: true,
  },
  {
    id: "mock-4",
    title: "Water supply disruption in Kilimani area",
    condition: "No water",
    affectedCount: 15,
    observingCount: 3,
    timeAgo: "Reported 30 min ago",
    duration: "~30 min",
    type: "power", // Icon type (uses Zap for utility services)
    category: "water", // WATER category - uses Nairobi Water
    location: "Kilimani — Ring Road",
    isLive: true,
    activityLevel: "recent",
    urgency: "standard",
    lastUpdated: "10 min ago",
    createdAt: mockSignalBaseTime - 60000, // ~1 real min ago = ~12 simulated min
    hasOfficialUpdate: false,
  },
]

// Map signals to localities
export const mockSignalsByLocality: Record<string, string[]> = {
  "nairobi-west": ["mock-1", "mock-2"],
  "south-b": ["mock-3"],
  "industrial-area": [],
  "upper-hill": [],
  "kilimani": ["mock-4"],
  "westlands": [],
}

// Signal categories
type SignalCategory = "electricity" | "water" | "road" | "flooding" | "garbage"

// User-created signal structure for storage
interface StoredSignal {
  id: string
  title: string
  condition: string
  affectedCount: number
  observingCount: number
  type: "power" | "road" | "flooding"
  category: SignalCategory // semantic category - determines institution
  location: string
  locality: string
  createdAt: number // timestamp
  sourceType: "citizen"
  createdByUser: boolean // flag to indicate user created this signal
  progressionSpeed: ProgressionSpeed // how fast this signal progresses through lifecycle
  baseDuration: number // randomized starting duration in simulated minutes
}

// User participation state per signal
interface SignalParticipation {
  status: "affected" | "observing"
  timestamp: number
}

// Restoration response state
interface RestorationResponse {
  response: "restored" | "still-affected" | "not-sure"
  timestamp: number
}

interface AppState {
  selectedLocality: string
  isSignedIn: boolean
  profileName: string
  followedAreas: string[]
  signalParticipation: Record<string, SignalParticipation> // signalId -> participation state
  observingCounts: Record<string, number> // signalId -> observing count boost
  affectedCounts: Record<string, number> // signalId -> affected count boost
  userSignals: StoredSignal[] // user-created signals
  lastUpdate: number // for triggering re-renders
  lastCheckedByArea: Record<string, number> // areaId -> timestamp of last check
  restorationResponses: Record<string, RestorationResponse> // signalId -> restoration response
}

const defaultState: AppState = {
  selectedLocality: "nairobi-west",
  isSignedIn: false,
  profileName: "You",
  followedAreas: ["nairobi-west", "south-b", "industrial-area"],
  signalParticipation: {},
  observingCounts: {},
  affectedCounts: {},
  userSignals: [],
  lastUpdate: Date.now(),
  lastCheckedByArea: {},
  restorationResponses: {},
}

export function useAppState() {
  const [state, setState] = useState<AppState>(defaultState)
  const [isHydrated, setIsHydrated] = useState(false)

  // Load state from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY)
      if (stored) {
        const parsed = JSON.parse(stored) as Partial<AppState>
        setState({
          ...defaultState,
          ...parsed,
          lastUpdate: Date.now(),
        })
      }
    } catch {
      // If localStorage fails, use defaults
    }
    setIsHydrated(true)
  }, [])

  // Save state to localStorage on changes (after hydration)
  useEffect(() => {
    if (isHydrated) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
      } catch {
        // If localStorage fails, silently continue
      }
    }
  }, [state, isHydrated])

  // Periodic update for time-based changes
  useEffect(() => {
    const interval = setInterval(() => {
      setState(prev => ({ ...prev, lastUpdate: Date.now() }))
    }, 2000) // Update every 2 seconds for smooth lifecycle transitions
    
    return () => clearInterval(interval)
  }, [])

  // Auto-check followed areas periodically to keep "Last checked" fresh
  useEffect(() => {
    const checkInterval = setInterval(() => {
      setState(prev => {
        // Update last checked for a random followed area every 10-20 seconds
        if (prev.followedAreas.length === 0) return prev
        
        const now = Date.now()
        const newLastChecked = { ...prev.lastCheckedByArea }
        
        // Find the area that was checked longest ago
        let oldestArea = prev.followedAreas[0]
        let oldestTime = newLastChecked[oldestArea] || 0
        
        for (const areaId of prev.followedAreas) {
          const lastChecked = newLastChecked[areaId] || 0
          if (lastChecked < oldestTime) {
            oldestTime = lastChecked
            oldestArea = areaId
          }
        }
        
        // Update the oldest area's check time
        newLastChecked[oldestArea] = now
        
        return {
          ...prev,
          lastCheckedByArea: newLastChecked,
        }
      })
    }, 12000) // Check an area every 12 seconds (~1-2 simulated minutes)
    
    return () => clearInterval(checkInterval)
  }, [])

  const setSelectedLocality = useCallback((locality: string) => {
    setState(prev => ({ ...prev, selectedLocality: locality }))
  }, [])

  const signIn = useCallback(() => {
    setState(prev => ({
      ...prev,
      isSignedIn: true,
      profileName: "John Doe",
    }))
  }, [])

  const signOut = useCallback(() => {
    setState(prev => ({
      ...prev,
      isSignedIn: false,
      profileName: "You",
    }))
  }, [])

  const addFollowedArea = useCallback((areaId: string) => {
    setState(prev => {
      if (prev.followedAreas.includes(areaId)) return prev
      return { ...prev, followedAreas: [...prev.followedAreas, areaId] }
    })
  }, [])

  const removeFollowedArea = useCallback((areaId: string) => {
    setState(prev => ({
      ...prev,
      followedAreas: prev.followedAreas.filter(a => a !== areaId),
    }))
  }, [])

  // Participate in a signal (affected or observing) - with toggle support
  const participateInSignal = useCallback((signalId: string, status: "affected" | "observing") => {
    setState(prev => {
      const currentParticipation = prev.signalParticipation[signalId]
      const newState = { ...prev }
      
      // If same status, this is a toggle-off (opt-out)
      if (currentParticipation?.status === status) {
        // Decrement the count
        if (status === "affected") {
          newState.affectedCounts = {
            ...prev.affectedCounts,
            [signalId]: Math.max(0, (prev.affectedCounts[signalId] || 0) - 1),
          }
        } else {
          newState.observingCounts = {
            ...prev.observingCounts,
            [signalId]: Math.max(0, (prev.observingCounts[signalId] || 0) - 1),
          }
        }
        
        // Remove participation record
        const { [signalId]: _, ...restParticipation } = prev.signalParticipation
        newState.signalParticipation = restParticipation
        
        return newState
      }
      
      // If switching from one status to another, decrement the old count
      if (currentParticipation) {
        if (currentParticipation.status === "affected") {
          newState.affectedCounts = {
            ...prev.affectedCounts,
            [signalId]: Math.max(0, (prev.affectedCounts[signalId] || 0) - 1),
          }
        } else {
          newState.observingCounts = {
            ...prev.observingCounts,
            [signalId]: Math.max(0, (prev.observingCounts[signalId] || 0) - 1),
          }
        }
      }
      
      // Increment the new status count
      if (status === "affected") {
        newState.affectedCounts = {
          ...newState.affectedCounts,
          [signalId]: (newState.affectedCounts[signalId] || 0) + 1,
        }
      } else {
        newState.observingCounts = {
          ...newState.observingCounts,
          [signalId]: (newState.observingCounts[signalId] || 0) + 1,
        }
      }
      
      // Update participation record
      newState.signalParticipation = {
        ...prev.signalParticipation,
        [signalId]: { status, timestamp: Date.now() },
      }
      
      return newState
    })
  }, [])

  // Get user's participation status for a signal
  const getParticipationStatus = useCallback((signalId: string): "affected" | "observing" | null => {
    return state.signalParticipation[signalId]?.status || null
  }, [state.signalParticipation])

  // Remove participation from a signal (opt-out)
  const removeParticipation = useCallback((signalId: string) => {
    setState(prev => {
      const currentParticipation = prev.signalParticipation[signalId]
      if (!currentParticipation) return prev
      
      const newState = { ...prev }
      
      // Decrement the appropriate count
      if (currentParticipation.status === "affected") {
        newState.affectedCounts = {
          ...prev.affectedCounts,
          [signalId]: Math.max(0, (prev.affectedCounts[signalId] || 0) - 1),
        }
      } else {
        newState.observingCounts = {
          ...prev.observingCounts,
          [signalId]: Math.max(0, (prev.observingCounts[signalId] || 0) - 1),
        }
      }
      
      // Remove participation record
      const { [signalId]: _, ...restParticipation } = prev.signalParticipation
      newState.signalParticipation = restParticipation
      
      return newState
    })
  }, [])

  // Add affected count (for background simulation)
  const addAffectedToSignal = useCallback((signalId: string) => {
    setState(prev => ({
      ...prev,
      affectedCounts: {
        ...prev.affectedCounts,
        [signalId]: (prev.affectedCounts[signalId] || 0) + 1,
      },
    }))
  }, [])

  // Add observing count (for background simulation)
  const addObservingToSignal = useCallback((signalId: string) => {
    setState(prev => ({
      ...prev,
      observingCounts: {
        ...prev.observingCounts,
        [signalId]: (prev.observingCounts[signalId] || 0) + 1,
      },
    }))
  }, [])

  // Legacy: for backward compatibility
  const joinSignal = useCallback((signalId: string) => {
    participateInSignal(signalId, "affected")
  }, [participateInSignal])

  const getSignalBoost = useCallback((signalId: string) => {
    return state.affectedCounts[signalId] || 0
  }, [state.affectedCounts])

  // Infer category from type and condition/title
  const inferCategory = (type: "power" | "road" | "flooding", condition: string, title: string): SignalCategory => {
    const lowerCondition = condition.toLowerCase()
    const lowerTitle = title.toLowerCase()
    
    // Check for water-related keywords
    if (lowerCondition.includes("water") || lowerCondition.includes("pressure") ||
        lowerTitle.includes("water") || lowerTitle.includes("supply")) {
      return "water"
    }
    
    // Check for garbage-related keywords
    if (lowerCondition.includes("waste") || lowerCondition.includes("garbage") ||
        lowerTitle.includes("waste") || lowerTitle.includes("garbage")) {
      return "garbage"
    }
    
    // Map type to category
    if (type === "power") return "electricity"
    if (type === "road") return "road"
    if (type === "flooding") return "flooding"
    
    return "electricity" // default
  }

  // Create a new user signal
  const createSignal = useCallback((params: {
    title: string
    condition: string
    type: "power" | "road" | "flooding"
    location: string
    locality: string
  }): Issue => {
    const now = Date.now()
    const signalId = `user-${now}-${Math.random().toString(36).substr(2, 9)}`
    const progressionSpeed = getRandomProgressionSpeed()
    const baseDuration = getRandomBaseDuration()
    const category = inferCategory(params.type, params.condition, params.title)
    
    const newSignal: StoredSignal = {
      id: signalId,
      title: params.title,
      condition: params.condition,
      affectedCount: 1, // Creator is automatically counted as affected
      observingCount: 0,
      type: params.type,
      category,
      location: params.location,
      locality: params.locality,
      createdAt: now,
      sourceType: "citizen",
      createdByUser: true,
      progressionSpeed,
      baseDuration,
    }

    setState(prev => ({
      ...prev,
      userSignals: [newSignal, ...prev.userSignals],
    }))

    // Get lifecycle info for the new signal
    const lifecycle = getLifecycleInfo(now, 1, progressionSpeed, signalId)

    // Convert to Issue format for return
    return {
      id: newSignal.id,
      title: newSignal.title,
      condition: newSignal.condition,
      affectedCount: newSignal.affectedCount,
      observingCount: 0,
      timeAgo: "Just reported",
      duration: null,
      type: newSignal.type,
      category,
      location: newSignal.location,
      isLive: lifecycle.showLive,
      activityLevel: "recent",
      urgency: "standard",
      lastUpdated: "just now",
      createdByUser: true,
      createdAt: now,
      lifecycleStage: lifecycle.stage,
      lifecycleLabel: lifecycle.label,
      hasOfficialUpdate: false,
      isExperiential: isExperientialSignal(params.type),
    }
  }, [])

  // Create signal for background simulation (not created by user)
  const createBackgroundSignal = useCallback((params: {
    title: string
    condition: string
    type: "power" | "road" | "flooding"
    category: SignalCategory
    location: string
    locality: string
    progressionSpeed: ProgressionSpeed
    baseDuration: number
  }) => {
    const now = Date.now()
    const newSignal: StoredSignal = {
      id: `bg-${now}-${Math.random().toString(36).substr(2, 9)}`,
      title: params.title,
      condition: params.condition,
      affectedCount: 1,
      observingCount: 0,
      type: params.type,
      category: params.category,
      location: params.location,
      locality: params.locality,
      createdAt: now,
      sourceType: "citizen",
      createdByUser: false, // Not created by user
      progressionSpeed: params.progressionSpeed,
      baseDuration: params.baseDuration,
    }

    setState(prev => ({
      ...prev,
      userSignals: [newSignal, ...prev.userSignals],
    }))
  }, [])

  // Get all signals for a locality with lifecycle and priority
  const getSignalsForLocality = useCallback((localityId: string): Issue[] => {
    const now = state.lastUpdate // Use lastUpdate to trigger recalculation
    
    // Get mock signals for this locality
    const mockIds = mockSignalsByLocality[localityId] || []
    const localityMockSignals = mockSignals.filter(s => mockIds.includes(s.id))
    
    // Get user signals for this locality
    const localityUserSignals = state.userSignals
      .filter(s => s.locality === localityId)
      .map(stored => {
        const affectedBoost = state.affectedCounts[stored.id] || 0
        const totalAffected = stored.affectedCount + affectedBoost
        const observingCount = (stored.observingCount || 0) + (state.observingCounts[stored.id] || 0)
        const lifecycle = getLifecycleInfo(
          stored.createdAt, 
          totalAffected, 
          stored.progressionSpeed || "normal",
          stored.id,
          observingCount // Pass observing count to lifecycle calculation
        )
        const duration = getSimulatedDuration(stored.createdAt, stored.baseDuration)
        const userParticipation = state.signalParticipation[stored.id]?.status || null
        const hasOfficialUpdate = shouldShowOfficialUpdate(stored.id, stored.createdAt)
        
        const issue: Issue = {
          id: stored.id,
          title: stored.title,
          condition: stored.condition,
          affectedCount: totalAffected,
          observingCount,
          userParticipation,
          timeAgo: duration ? `Ongoing for ${duration}` : "Just reported",
          duration,
          type: stored.type,
          category: stored.category,
          location: stored.location,
          isLive: lifecycle.showLive,
          activityLevel: lifecycle.stage === "growing" ? "increasing" : 
                        lifecycle.stage === "steady" ? "steady" : "recent",
          urgency: lifecycle.stage === "growing" ? "elevated" : "standard",
          lastUpdated: "just now",
          createdByUser: stored.createdByUser,
          createdAt: stored.createdAt,
          lifecycleStage: lifecycle.stage,
          lifecycleLabel: lifecycle.label,
          liveIntensity: lifecycle.liveIntensity,
          shouldFade: lifecycle.shouldFade,
          hasOfficialUpdate,
          isExperiential: isExperientialSignal(stored.type),
          officialStage: lifecycle.officialStage,
        }
        
        return issue
      })
      // Filter out resolved/hidden signals
      .filter(issue => !issue.shouldFade || issue.lifecycleStage !== "resolved")

    // Process mock signals with lifecycle info
const processedMockSignals = localityMockSignals.map(s => {
      const createdAt = (s as Issue & { createdAt?: number }).createdAt || (Date.now() - 180000)
      const affectedBoost = state.affectedCounts[s.id] || 0
      const totalAffected = s.affectedCount + affectedBoost
      const observingCount = (s.observingCount || 0) + (state.observingCounts[s.id] || 0)
      // Mock signals use "normal" progression speed, pass observingCount for activity calculation
      const lifecycle = getLifecycleInfo(createdAt, totalAffected, "normal", s.id, observingCount)
      const userParticipation = state.signalParticipation[s.id]?.status || null
      const hasOfficialUpdate = shouldShowOfficialUpdate(s.id, createdAt)
      
      return {
        ...s,
        affectedCount: totalAffected,
        observingCount,
        userParticipation,
        createdByUser: false,
        createdAt,
        lifecycleStage: lifecycle.stage,
        lifecycleLabel: lifecycle.label,
        isLive: lifecycle.showLive,
        liveIntensity: lifecycle.liveIntensity,
        shouldFade: lifecycle.shouldFade,
        hasOfficialUpdate,
        isExperiential: isExperientialSignal(s.type),
        officialStage: lifecycle.officialStage,
      }
    }).filter(issue => !issue.shouldFade || issue.lifecycleStage !== "resolved")

    // Combine all signals
    const allSignals = [...localityUserSignals, ...processedMockSignals]
    
// Sort by priority score (higher = first)
    // Include observingCount so both types of participation affect ordering
    return allSignals.sort((a, b) => {
      const scoreA = calculatePriorityScore({
        createdAt: a.createdAt!,
        affectedCount: a.affectedCount,
        observingCount: a.observingCount || 0,
        lifecycleStage: a.lifecycleStage,
      })
      const scoreB = calculatePriorityScore({
        createdAt: b.createdAt!,
        affectedCount: b.affectedCount,
        observingCount: b.observingCount || 0,
        lifecycleStage: b.lifecycleStage,
      })
      return scoreB - scoreA
    })
  }, [state.userSignals, state.affectedCounts, state.observingCounts, state.signalParticipation, state.lastUpdate])

  // Get all signals (for matching in report modal)
  const getAllSignals = useCallback((): Issue[] => {
    const allLocalities = Object.keys(mockSignalsByLocality)
    const allSignals: Issue[] = []
    
    allLocalities.forEach(localityId => {
      allSignals.push(...getSignalsForLocality(localityId))
    })
    
    // Add signals from user-created signals in other localities
    const userSignalLocalities = new Set(state.userSignals.map(s => s.locality))
    userSignalLocalities.forEach(localityId => {
      if (!allLocalities.includes(localityId)) {
        allSignals.push(...getSignalsForLocality(localityId))
      }
    })
    
    return allSignals
  }, [getSignalsForLocality, state.userSignals])

  // Get signal count for a locality (excluding hidden/resolved)
  const getSignalCountForLocality = useCallback((localityId: string): number => {
    return getSignalsForLocality(localityId).length
  }, [getSignalsForLocality])

  // Get active signal IDs for background simulation
  const getActiveSignalIds = useCallback((): string[] => {
    const allSignals = getAllSignals()
    return allSignals.map(s => s.id)
  }, [getAllSignals])

  // Mark an area as "checked" (when user views it)
  const markAreaChecked = useCallback((areaId: string) => {
    setState(prev => ({
      ...prev,
      lastCheckedByArea: {
        ...prev.lastCheckedByArea,
        [areaId]: Date.now(),
      },
    }))
  }, [])

  // Get last checked text for an area
  const getLastCheckedText = useCallback((areaId: string): string => {
    const lastChecked = state.lastCheckedByArea[areaId]
    if (!lastChecked) return "Not checked yet"
    return `Last checked ${getSimulatedLastCheckedText(lastChecked)}`
  }, [state.lastCheckedByArea])

  // Set restoration response for a signal (persisted)
  const setRestorationResponse = useCallback((signalId: string, response: "restored" | "still-affected" | "not-sure") => {
    setState(prev => ({
      ...prev,
      restorationResponses: {
        ...prev.restorationResponses,
        [signalId]: { response, timestamp: Date.now() },
      },
    }))
  }, [])

  // Get restoration response for a signal
  const getRestorationResponse = useCallback((signalId: string): "restored" | "still-affected" | "not-sure" | null => {
    return state.restorationResponses[signalId]?.response || null
  }, [state.restorationResponses])

  // Reset demo data - clears all signals and returns to initial state
  const resetDemoData = useCallback(() => {
    // Clear localStorage
    try {
      localStorage.removeItem(STORAGE_KEY)
    } catch {
      // Silently continue
    }
    
    // Reset to default state
    setState({
      ...defaultState,
      lastUpdate: Date.now(),
    })
  }, [])

  return {
    ...state,
    isHydrated,
    setSelectedLocality,
    signIn,
    signOut,
    addFollowedArea,
    removeFollowedArea,
    joinSignal,
    getSignalBoost,
    participateInSignal,
    removeParticipation,
    getParticipationStatus,
    addAffectedToSignal,
    addObservingToSignal,
    createSignal,
    createBackgroundSignal,
    getSignalsForLocality,
    getAllSignals,
    getSignalCountForLocality,
    getActiveSignalIds,
    markAreaChecked,
    getLastCheckedText,
    setRestorationResponse,
    getRestorationResponse,
    resetDemoData,
  }
}
