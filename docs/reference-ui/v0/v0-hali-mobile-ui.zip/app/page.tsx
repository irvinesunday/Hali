"use client"

import { useState, useEffect, useRef } from "react"
import { HomeScreen } from "@/components/home-screen"
import { IssueDetail } from "@/components/issue-detail"
import { Dashboard } from "@/components/dashboard"
import { AreasScreen } from "@/components/areas-screen"
import { ProfileScreen } from "@/components/profile-screen"
import { BottomNav, type NavTab } from "@/components/bottom-nav"
import { FloatingActionButton } from "@/components/floating-action-button"
import { ReportModal } from "@/components/report-modal"
import { type Issue } from "@/components/issue-card"
import { type Locality } from "@/components/locality-selector"
import { useAppState, inferLocality } from "@/hooks/use-app-state"
import { useBackgroundSimulation } from "@/hooks/use-simulation"
import { cn } from "@/lib/utils"

type Screen = "main" | "detail" | "dashboard"

export default function HaliApp() {
  const [currentScreen, setCurrentScreen] = useState<Screen>("main")
  const [activeTab, setActiveTab] = useState<NavTab>("home")
  const [selectedIssue, setSelectedIssue] = useState<Issue | null>(null)
  const [isTransitioning, setIsTransitioning] = useState(false)
  const [isReportModalOpen, setIsReportModalOpen] = useState(false)

  // Shared app state with localStorage persistence
  const {
    selectedLocality,
    isSignedIn,
    profileName,
    followedAreas,
    isHydrated,
    setSelectedLocality,
    signIn,
    signOut,
    addFollowedArea,
    removeFollowedArea,
    joinSignal,
    getSignalBoost,
    participateInSignal,
    removeParticipation,
    getParticipationStatus,
    addAffectedToSignal,
    addObservingToSignal,
    createSignal,
    createBackgroundSignal,
    getSignalsForLocality,
    getAllSignals,
    getSignalCountForLocality,
    getActiveSignalIds,
    markAreaChecked,
    getLastCheckedText,
    setRestorationResponse,
    getRestorationResponse,
    resetDemoData,
  } = useAppState()

  // Mark current area as checked on initial load
  const initialCheckDone = useRef(false)
  useEffect(() => {
    if (isHydrated && !initialCheckDone.current) {
      markAreaChecked(selectedLocality)
      initialCheckDone.current = true
    }
  }, [isHydrated, selectedLocality, markAreaChecked])

  // Background simulation for dynamic activity
  useBackgroundSimulation(
    addAffectedToSignal,
    addObservingToSignal,
    createBackgroundSignal,
    getActiveSignalIds(),
    followedAreas
  )

  const handleSelectIssue = (issue: Issue) => {
    setIsTransitioning(true)
    setSelectedIssue(issue)
    setTimeout(() => {
      setCurrentScreen("detail")
      setIsTransitioning(false)
    }, 150)
  }

  const handleBack = () => {
    setCurrentScreen("main")
    setSelectedIssue(null)
  }

  const handleOpenDashboard = () => {
    setIsTransitioning(true)
    setTimeout(() => {
      setCurrentScreen("dashboard")
      setIsTransitioning(false)
    }, 100)
  }

  const handleTabChange = (tab: NavTab) => {
    if (currentScreen !== "main") {
      setCurrentScreen("main")
      setSelectedIssue(null)
    }
    setActiveTab(tab)
  }

  const handleReportSignal = () => {
    setIsReportModalOpen(true)
  }

  const handleLocalityChange = (locality: Locality) => {
    setSelectedLocality(locality.id)
    markAreaChecked(locality.id) // Mark as checked when switching
  }

  const handleNavigateToArea = (areaId: string) => {
    // Switch to home tab and set the locality
    setSelectedLocality(areaId)
    markAreaChecked(areaId) // Mark as checked when navigating
    setActiveTab("home")
    if (currentScreen !== "main") {
      setCurrentScreen("main")
      setSelectedIssue(null)
    }
  }

  const handleJoinSignal = (issue: Issue) => {
    // Persist the join and navigate to the signal detail
    joinSignal(issue.id)
    setIsReportModalOpen(false)
    handleSelectIssue(issue)
  }

  const handleCreateSignal = (params: {
    title: string
    condition: string
    type: "power" | "road" | "flooding"
    location: string
  }) => {
    // Infer locality from location
    const locality = inferLocality(params.location, selectedLocality)
    
    // Create the signal in global state
    const newSignal = createSignal({
      ...params,
      locality,
    })
    
    // Close modal and navigate to the new signal
    setIsReportModalOpen(false)
    
    // If the new signal's locality matches current view, navigate to it
    // Otherwise, switch to that locality first
    if (locality !== selectedLocality) {
      setSelectedLocality(locality)
    }
    
    handleSelectIssue(newSignal)
  }

  const handleSignIn = () => {
    signIn()
  }

  const handleSignOut = () => {
    signOut()
  }

  // Show FAB on Home, Your Areas, and Signal Detail screens
  const showFAB = 
    (currentScreen === "main" && (activeTab === "home" || activeTab === "areas")) ||
    currentScreen === "detail"

  const showNavigation = currentScreen === "main"

  // Show loading state while hydrating from localStorage
  if (!isHydrated) {
    return (
      <div className="max-w-md mx-auto min-h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 rounded-full border-2 border-primary border-t-transparent animate-spin" />
      </div>
    )
  }

  return (
    <div className="max-w-md mx-auto min-h-screen bg-background relative overflow-hidden">
      {/* Main Tab Screens */}
      {currentScreen === "main" && (
        <div className={cn(
          "transition-all duration-300 ease-out",
          isTransitioning && "scale-[0.98] opacity-80"
        )}>
          {activeTab === "home" && (
            <HomeScreen 
              onSelectIssue={handleSelectIssue} 
              currentLocalityId={selectedLocality}
              onLocalityChange={handleLocalityChange}
              followedAreas={followedAreas}
              getSignalsForLocality={getSignalsForLocality}
              getSignalCountForLocality={getSignalCountForLocality}
              getLastCheckedText={getLastCheckedText}
            />
          )}
          {activeTab === "areas" && (
            <AreasScreen 
              onNavigateToArea={handleNavigateToArea}
              currentLocalityId={selectedLocality}
              isSignedIn={isSignedIn}
              followedAreas={followedAreas}
              onAddArea={addFollowedArea}
              onRemoveArea={removeFollowedArea}
              getSignalCountForLocality={getSignalCountForLocality}
              getLastCheckedText={getLastCheckedText}
            />
          )}
          {activeTab === "profile" && (
            <ProfileScreen 
              onNavigateToArea={handleNavigateToArea}
              isSignedIn={isSignedIn}
              profileName={profileName}
              onSignIn={handleSignIn}
              onSignOut={handleSignOut}
              followedAreas={followedAreas}
              onRemoveArea={removeFollowedArea}
              getSignalCountForLocality={getSignalCountForLocality}
              getLastCheckedText={getLastCheckedText}
              onResetDemo={resetDemoData}
            />
          )}
        </div>
      )}
      
      {/* Detail Screen */}
      {currentScreen === "detail" && selectedIssue && (
        <IssueDetail 
          issue={selectedIssue} 
          onBack={handleBack}
          onParticipate={participateInSignal}
          onRemoveParticipation={removeParticipation}
          getParticipationStatus={getParticipationStatus}
          onRestorationResponse={setRestorationResponse}
          getRestorationResponse={getRestorationResponse}
        />
      )}
      
      {/* Dashboard Screen */}
      {currentScreen === "dashboard" && (
        <Dashboard onBack={handleBack} />
      )}

      {/* Floating Action Button */}
      {showFAB && (
        <FloatingActionButton 
          onClick={handleReportSignal} 
          className={currentScreen === "detail" ? "bottom-6" : undefined}
        />
      )}

      {/* Bottom Navigation */}
      {showNavigation && (
        <BottomNav activeTab={activeTab} onTabChange={handleTabChange} />
      )}

      {/* Report Modal */}
      <ReportModal 
        isOpen={isReportModalOpen} 
        onClose={() => setIsReportModalOpen(false)}
        onJoinSignal={handleJoinSignal}
        onCreateSignal={handleCreateSignal}
        existingSignals={getAllSignals()}
        currentLocality={selectedLocality}
      />
    </div>
  )
}
