"use client"

import { Plus } from "lucide-react"
import { cn } from "@/lib/utils"

interface FloatingActionButtonProps {
  onClick: () => void
  className?: string
}

export function FloatingActionButton({ onClick, className }: FloatingActionButtonProps) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "fixed bottom-20 right-4 z-40 w-14 h-14 rounded-full",
        "bg-primary text-primary-foreground shadow-lg",
        "flex items-center justify-center",
        "transition-all duration-200 ease-out",
        "hover:bg-primary/90 hover:shadow-xl hover:scale-105",
        "active:scale-90 active:shadow-md",
        "animate-in fade-in zoom-in-75 duration-300",
        "animate-breathe",
        className
      )}
      aria-label="Report new signal"
    >
      <Plus className="w-6 h-6" strokeWidth={2.5} />
    </button>
  )
}
