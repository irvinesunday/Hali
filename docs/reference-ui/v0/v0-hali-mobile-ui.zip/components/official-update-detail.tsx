"use client"

import { X, Building2, Clock, MapPin, ExternalLink } from "lucide-react"
import { cn } from "@/lib/utils"

export interface OfficialUpdateData {
  source: string
  message: string
  fullMessage?: string
  updatedAgo?: string
  affectedAreas?: string[]
  expectedResolution?: string
  link?: string
}

interface OfficialUpdateDetailProps {
  isOpen: boolean
  onClose: () => void
  update: OfficialUpdateData | null
}

export function OfficialUpdateDetail({ isOpen, onClose, update }: OfficialUpdateDetailProps) {
  if (!isOpen || !update) return null

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose()
    }
  }

  return (
    <div 
      className="fixed inset-0 z-50 flex items-end justify-center animate-modal-backdrop"
      onClick={handleBackdropClick}
    >
      {/* Backdrop - pointer-events-none so clicks pass through to parent */}
      <div className="absolute inset-0 bg-foreground/20 backdrop-blur-sm pointer-events-none" />
      
      {/* Detail Panel - positioned above bottom nav, stops propagation */}
      <div 
        className="relative w-full max-w-md mx-4 mb-20 bg-card rounded-2xl shadow-xl animate-modal-content max-h-[70vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border/50 flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
              <Building2 className="w-4 h-4 text-muted-foreground" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm font-semibold text-foreground">{update.source}</h3>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground/70">
                Official Update
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-muted transition-colors active:scale-90 flex-shrink-0"
          >
            <X className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>
        
        {/* Content - scrollable */}
        <div className="p-4 space-y-4 overflow-y-auto flex-1">
          {/* Main Message */}
          <p className="text-base text-foreground leading-relaxed break-words">
            {update.fullMessage || update.message}
          </p>
          
          {/* Metadata */}
          <div className="space-y-3 pt-2">
            {/* Updated Time */}
            {update.updatedAgo && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="w-3.5 h-3.5 flex-shrink-0" />
                <span>Updated {update.updatedAgo}</span>
              </div>
            )}
            
            {/* Affected Areas */}
            {update.affectedAreas && update.affectedAreas.length > 0 && (
              <div className="flex items-start gap-2 text-sm text-muted-foreground">
                <MapPin className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" />
                <span className="break-words">Affected: {update.affectedAreas.join(", ")}</span>
              </div>
            )}
            
            {/* Expected Resolution */}
            {update.expectedResolution && (
              <div className="pt-3 mt-3 border-t border-border/50">
                <p className="text-xs text-muted-foreground/70 uppercase tracking-wider mb-1.5">
                  Expected Resolution
                </p>
                <p className="text-sm text-foreground">{update.expectedResolution}</p>
              </div>
            )}
          </div>
          
          {/* External Link */}
          {update.link && (
            <a 
              href={update.link}
              target="_blank"
              rel="noopener noreferrer"
              className={cn(
                "flex items-center gap-2 text-sm text-primary",
                "hover:underline transition-colors"
              )}
            >
              <ExternalLink className="w-3.5 h-3.5 flex-shrink-0" />
              View more details
            </a>
          )}
        </div>
      </div>
    </div>
  )
}
