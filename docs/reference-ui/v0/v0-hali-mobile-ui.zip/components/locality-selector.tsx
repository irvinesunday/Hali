"use client"

import { MapPin, Check, X } from "lucide-react"
import { cn } from "@/lib/utils"

export interface Locality {
  id: string
  name: string
  subtext?: string
  signalCount: number
}

interface LocalitySelectorProps {
  isOpen: boolean
  onClose: () => void
  localities: Locality[]
  currentLocality: Locality
  onSelect: (locality: Locality) => void
}

export function LocalitySelector({ 
  isOpen, 
  onClose, 
  localities, 
  currentLocality, 
  onSelect 
}: LocalitySelectorProps) {
  if (!isOpen) return null

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose()
    }
  }

  const handleSelect = (locality: Locality) => {
    onSelect(locality)
    onClose()
  }

  return (
    <div 
      className="fixed inset-0 z-50 flex items-start justify-center pt-20 animate-modal-backdrop"
      onClick={handleBackdropClick}
    >
      {/* Backdrop - pointer-events-none so clicks pass through to parent */}
      <div className="absolute inset-0 bg-foreground/10 backdrop-blur-sm pointer-events-none" />
      
      {/* Selector Content - stops propagation */}
      <div 
        className="relative w-full max-w-sm mx-4 bg-card rounded-xl shadow-xl animate-modal-content overflow-hidden border border-border/50"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-border/50">
          <h3 className="text-sm font-medium text-foreground">Switch Area</h3>
          <button
            onClick={onClose}
            className="w-7 h-7 flex items-center justify-center rounded-full hover:bg-muted transition-colors active:scale-90"
          >
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>
        
        {/* Localities List */}
        <div className="py-1">
          {localities.map((locality) => {
            const isCurrent = locality.id === currentLocality.id
            return (
              <button
                key={locality.id}
                onClick={() => handleSelect(locality)}
                className={cn(
                  "w-full flex items-center gap-3 px-4 py-3 text-left",
                  "transition-colors duration-150",
                  isCurrent ? "bg-primary/5" : "hover:bg-muted/50 active:bg-muted"
                )}
              >
                <div className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0",
                  isCurrent ? "bg-primary/10" : "bg-muted"
                )}>
                  <MapPin className={cn(
                    "w-4 h-4",
                    isCurrent ? "text-primary" : "text-muted-foreground"
                  )} />
                </div>
                
                <div className="flex-1 min-w-0">
                  <span className={cn(
                    "text-sm block",
                    isCurrent ? "font-medium text-primary" : "text-foreground"
                  )}>
                    {locality.name}
                  </span>
                  {locality.signalCount > 0 ? (
                    <span className="text-xs text-muted-foreground">
                      {locality.signalCount} active signal{locality.signalCount > 1 ? "s" : ""}
                    </span>
                  ) : (
                    <span className="text-xs text-muted-foreground/60">
                      Currently calm
                    </span>
                  )}
                </div>
                
                {isCurrent && (
                  <Check className="w-4 h-4 text-primary flex-shrink-0" />
                )}
              </button>
            )
          })}
        </div>
      </div>
    </div>
  )
}
