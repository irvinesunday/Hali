"use client"

import { useState, useMemo } from "react"
import { MapPin, ChevronDown } from "lucide-react"
import { IssueCard, type Issue } from "@/components/issue-card"
import { OfficialUpdate, type OfficialUpdateData } from "@/components/official-update"
import { LocalitySelector, type Locality } from "@/components/locality-selector"
import { OfficialUpdateDetail } from "@/components/official-update-detail"

// Generate official updates based on active signals in the area
function generateOfficialUpdatesForSignals(signals: Issue[]): OfficialUpdateData[] {
  const updates: OfficialUpdateData[] = []
  
  // Only show updates for signals with official updates
  const signalsWithOfficials = signals.filter(s => s.hasOfficialUpdate && s.officialStage && s.officialStage !== "none")
  
  for (const signal of signalsWithOfficials.slice(0, 2)) { // Max 2 official updates shown
    const category = signal.category || (signal.type === "power" ? "electricity" : signal.type)
    
    let source: string
    let message: string
    let fullMessage: string
    
    switch (category) {
      case "electricity":
        source = "Kenya Power"
        if (signal.officialStage === "dispatched") {
          message = "Teams dispatched to investigate outage"
          fullMessage = "Our technical team has been dispatched to investigate the reported power outage. We are working to identify the cause and restore supply as soon as possible."
        } else if (signal.officialStage === "on-site") {
          message = "Technicians assessing the outage"
          fullMessage = "Technicians are on site assessing the extent of the outage. We will provide updates as restoration progresses."
        } else if (signal.officialStage === "working") {
          message = "Work ongoing to restore power"
          fullMessage = "Work is ongoing to restore power supply to affected areas. We appreciate your patience."
        } else if (signal.officialStage === "restoring") {
          message = "Power restoration in progress"
          fullMessage = "Restoration is in progress. Power is returning to some areas. Full restoration expected shortly."
        } else {
          message = "Power restored to the area"
          fullMessage = "Power has been restored to the affected area. Thank you for your patience."
        }
        break
        
      case "water":
        source = "Nairobi Water"
        if (signal.officialStage === "dispatched" || signal.officialStage === "on-site") {
          message = "Teams investigating water supply issue"
          fullMessage = "Our teams have been dispatched to investigate the water supply disruption. We are working to restore normal service."
        } else if (signal.officialStage === "working" || signal.officialStage === "restoring") {
          message = "Water supply restoration underway"
          fullMessage = "Repair work is ongoing to restore water supply. Service expected to resume soon."
        } else {
          message = "Water supply restored"
          fullMessage = "Water supply has been restored to the affected area."
        }
        break
        
      case "flooding":
        source = "Nairobi County"
        if (signal.officialStage === "dispatched" || signal.officialStage === "on-site") {
          message = "Emergency response teams deployed"
          fullMessage = "Emergency response teams have been deployed to address flooding. Motorists are advised to use alternative routes."
        } else if (signal.officialStage === "working" || signal.officialStage === "restoring") {
          message = "Drainage clearing in progress"
          fullMessage = "Drainage clearing and pumping operations are underway. Water levels are receding."
        } else {
          message = "Flooding cleared"
          fullMessage = "Flooding has been cleared. Road is fully passable."
        }
        break
        
      case "garbage":
        source = "Nairobi County"
        if (signal.officialStage === "dispatched" || signal.officialStage === "on-site") {
          message = "Collection teams notified"
          fullMessage = "Waste collection teams have been notified and are on the way."
        } else if (signal.officialStage === "working" || signal.officialStage === "restoring") {
          message = "Collection in progress"
          fullMessage = "Garbage collection is ongoing in the area."
        } else {
          message = "Area cleared"
          fullMessage = "Garbage has been collected from the area."
        }
        break
        
      case "noise":
      case "encroachment":
      case "crowding":
        source = "Nairobi County"
        if (signal.officialStage === "dispatched" || signal.officialStage === "on-site") {
          message = "County officers notified"
          fullMessage = "County enforcement officers have been notified and are responding."
        } else if (signal.officialStage === "working" || signal.officialStage === "restoring") {
          message = "Being addressed"
          fullMessage = "Officers are working to resolve the issue."
        } else {
          message = "Issue addressed"
          fullMessage = "The reported issue has been addressed."
        }
        break
        
      case "road":
      default:
        source = "KURA / KeNHA"
        if (signal.officialStage === "dispatched" || signal.officialStage === "on-site") {
          message = "Road maintenance teams notified"
          fullMessage = "Road maintenance teams have been notified and are assessing the situation. Please drive with caution."
        } else if (signal.officialStage === "working" || signal.officialStage === "restoring") {
          message = "Road repairs in progress"
          fullMessage = "Repair work is in progress. Alternative routes are advised where possible."
        } else {
          message = "Road repairs complete"
          fullMessage = "Road repairs have been completed. Normal traffic has resumed."
        }
        break
    }
    
    // Generate time based on official stage
    const timeTexts: Record<string, string> = {
      dispatched: "~3 min ago",
      "on-site": "~8 min ago",
      working: "~15 min ago",
      restoring: "~20 min ago",
      restored: "~25 min ago",
    }
    
    updates.push({
      source,
      message,
      fullMessage,
      updatedAgo: timeTexts[signal.officialStage || "dispatched"] || "~5 min ago",
      affectedAreas: signal.location ? [signal.location] : ["Reported area"],
    })
  }
  
  return updates
}

// All localities data
const allLocalities: Locality[] = [
  { id: "nairobi-west", name: "Nairobi West", subtext: "South B and nearby", signalCount: 0 },
  { id: "south-b", name: "South B", subtext: "Your selected area", signalCount: 0 },
  { id: "industrial-area", name: "Industrial Area", subtext: "Currently calm", signalCount: 0 },
  { id: "upper-hill", name: "Upper Hill", subtext: "Currently calm", signalCount: 0 },
  { id: "kilimani", name: "Kilimani", subtext: "1 active signal", signalCount: 0 },
  { id: "westlands", name: "Westlands", subtext: "Currently calm", signalCount: 0 },
]

interface HomeScreenProps {
  onSelectIssue: (issue: Issue) => void
  currentLocalityId?: string
  onLocalityChange?: (locality: Locality) => void
  followedAreas?: string[]
  getSignalsForLocality: (localityId: string) => Issue[]
  getSignalCountForLocality: (localityId: string) => number
  getLastCheckedText?: (areaId: string) => string
}

export function HomeScreen({ 
  onSelectIssue, 
  currentLocalityId = "nairobi-west",
  onLocalityChange,
  followedAreas = ["nairobi-west", "south-b", "industrial-area"],
  getSignalsForLocality,
  getSignalCountForLocality,
  getLastCheckedText = () => "Not checked yet",
}: HomeScreenProps) {
  const [isLocalitySelectorOpen, setIsLocalitySelectorOpen] = useState(false)
  const [selectedOfficialUpdate, setSelectedOfficialUpdate] = useState<OfficialUpdateData | null>(null)
  
  // Build localities with dynamic signal counts
  const localities = useMemo(() => {
    return allLocalities
      .filter(l => followedAreas.includes(l.id))
      .map(l => {
        const count = getSignalCountForLocality(l.id)
        let subtext: string
        if (count === 0) {
          subtext = "Currently calm"
        } else if (count === 1) {
          subtext = "1 active signal"
        } else if (count >= 3) {
          subtext = "Elevated activity"
        } else {
          subtext = `${count} active signals`
        }
        return {
          ...l,
          signalCount: count,
          subtext,
        }
      })
  }, [followedAreas, getSignalCountForLocality])
  
  const currentLocality = localities.find(l => l.id === currentLocalityId) || localities[0] || allLocalities[0]
  
  // Get signals from unified state
  const activeIssues = getSignalsForLocality(currentLocalityId)
  
  // Generate official updates based on active signals (reactive to signal activity)
  const officialUpdates = useMemo(() => {
    return generateOfficialUpdatesForSignals(activeIssues)
  }, [activeIssues])

  const handleLocalitySelect = (locality: Locality) => {
    onLocalityChange?.(locality)
  }

  return (
    <div className="min-h-screen bg-background pb-24 animate-in fade-in duration-300">
      <header className="sticky top-0 z-10 bg-background/95 backdrop-blur-sm border-b border-border/50">
        <div className="p-4 pb-3">
          <h1 className="text-2xl font-semibold text-foreground tracking-tight">Hali</h1>
          
          {/* Interactive Location Context Header */}
          <button 
            onClick={() => setIsLocalitySelectorOpen(true)}
            className="flex items-center gap-1.5 mt-2 group"
          >
            <MapPin className="w-3.5 h-3.5 text-primary" />
            <span className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">
              {currentLocality.name}
            </span>
            <ChevronDown className="w-3.5 h-3.5 text-muted-foreground/60 group-hover:text-primary transition-colors" />
          </button>
          <p className="text-xs text-muted-foreground/70 mt-0.5 ml-5">
            {currentLocality.subtext}
          </p>
        </div>
      </header>

      <main className="p-4 pb-8 space-y-6">
        <section>
          <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-3">Active Now</h2>
          {activeIssues.length > 0 ? (
            <div className="space-y-3">
              {activeIssues.map((issue) => (
                <div 
                  key={issue.id}
                  className="transition-all duration-300 ease-out"
                >
                  <IssueCard 
                    issue={issue} 
                    onClick={() => onSelectIssue(issue)}
                  />
                </div>
              ))}
            </div>
          ) : (
            <div className="py-8 text-center animate-in fade-in duration-300">
              <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-emerald-50 flex items-center justify-center">
                <MapPin className="w-5 h-5 text-emerald-600" />
              </div>
              <p className="text-sm font-medium text-foreground">All clear in {currentLocality.name}</p>
              <p className="text-xs text-muted-foreground mt-1">
                {getLastCheckedText(currentLocalityId)}
              </p>
              <p className="text-xs text-muted-foreground/60 mt-2">
                Monitoring for new reports...
              </p>
            </div>
          )}
        </section>

        {officialUpdates.length > 0 && (
          <section className="mt-8 pt-4 border-t border-border/30">
            <h2 className="text-[10px] font-normal text-muted-foreground/70 uppercase tracking-wider mb-2.5">Official Updates</h2>
            <div className="space-y-1.5">
              {officialUpdates.map((update, index) => (
                <OfficialUpdate 
                  key={index}
                  source={update.source}
                  message={update.message}
                  onClick={() => setSelectedOfficialUpdate(update)}
                />
              ))}
            </div>
          </section>
        )}
      </main>

      {/* Locality Selector */}
      <LocalitySelector
        isOpen={isLocalitySelectorOpen}
        onClose={() => setIsLocalitySelectorOpen(false)}
        localities={localities}
        currentLocality={currentLocality}
        onSelect={handleLocalitySelect}
      />

      {/* Official Update Detail */}
      <OfficialUpdateDetail
        isOpen={selectedOfficialUpdate !== null}
        onClose={() => setSelectedOfficialUpdate(null)}
        update={selectedOfficialUpdate}
      />
    </div>
  )
}
