"use client"

import { useState, useMemo } from "react"
import { MapPin, ChevronRight, Smartphone, X, Plus, Check } from "lucide-react"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"

// All possible areas in the system (base data)
const allAreaBaseData: Record<string, { id: string; name: string }> = {
  "nairobi-west": { id: "nairobi-west", name: "Nairobi West" },
  "south-b": { id: "south-b", name: "South B" },
  "industrial-area": { id: "industrial-area", name: "Industrial Area" },
  "upper-hill": { id: "upper-hill", name: "Upper Hill" },
  "kilimani": { id: "kilimani", name: "Kilimani" },
  "westlands": { id: "westlands", name: "Westlands" },
}

interface AreasScreenProps {
  onNavigateToArea?: (areaId: string) => void
  currentLocalityId?: string
  isSignedIn?: boolean
  followedAreas?: string[]
  onAddArea?: (areaId: string) => void
  onRemoveArea?: (areaId: string) => void
  getSignalCountForLocality: (localityId: string) => number
  getLastCheckedText?: (areaId: string) => string
}

export function AreasScreen({ 
  onNavigateToArea, 
  currentLocalityId, 
  isSignedIn = false,
  followedAreas = ["nairobi-west", "south-b", "industrial-area"],
  onAddArea,
  onRemoveArea,
  getSignalCountForLocality,
  getLastCheckedText = () => "Not checked yet"
}: AreasScreenProps) {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [justAdded, setJustAdded] = useState<string | null>(null)
  const [areaToUnfollow, setAreaToUnfollow] = useState<string | null>(null)
  const [unfollowFeedback, setUnfollowFeedback] = useState<string | null>(null)

  // Build area objects with dynamic signal counts and last checked
  const followedAreaObjects = useMemo(() => {
    return followedAreas
      .map(id => {
        const base = allAreaBaseData[id]
        if (!base) return null
        const count = getSignalCountForLocality(id)
        const lastChecked = getLastCheckedText(id)
        
        // Status text based on signal count
        let status: string
        if (count === 0) {
          status = "Currently calm"
        } else if (count === 1) {
          status = "1 active signal"
        } else if (count >= 3) {
          status = "Elevated activity"
        } else {
          status = `${count} active signals`
        }
        
        return {
          id: base.id,
          name: base.name,
          status,
          signalCount: count,
          isCalm: count === 0,
          lastChecked,
        }
      })
      .filter(Boolean) as Array<{
        id: string
        name: string
        status: string
        signalCount: number
        isCalm: boolean
        lastChecked: string
      }>
  }, [followedAreas, getSignalCountForLocality, getLastCheckedText])

  // Get available areas to add (not already followed)
  const availableAreas = useMemo(() => {
    return Object.values(allAreaBaseData)
      .filter(area => !followedAreas.includes(area.id))
      .map(base => {
        const count = getSignalCountForLocality(base.id)
        return {
          id: base.id,
          name: base.name,
          status: count === 0 ? "Currently calm" : count === 1 ? "1 active signal" : `${count} active signals`,
          signalCount: count,
          isCalm: count === 0,
        }
      })
  }, [followedAreas, getSignalCountForLocality])

  const handleAddArea = (areaId: string) => {
    onAddArea?.(areaId)
    setJustAdded(areaId)
    setTimeout(() => {
      setIsAddModalOpen(false)
      setJustAdded(null)
    }, 500)
  }

  const handleUnfollowArea = (areaId: string, areaName: string) => {
    onRemoveArea?.(areaId)
    setAreaToUnfollow(null)
    setUnfollowFeedback(`You've unfollowed ${areaName}`)
    setTimeout(() => setUnfollowFeedback(null), 2500)
  }

  return (
    <div className="min-h-screen bg-background pb-24 animate-in fade-in duration-300">
      <header className="sticky top-0 z-10 bg-background/95 backdrop-blur-sm border-b border-border/50">
        <div className="p-4 pb-3">
          <h1 className="text-2xl font-semibold text-foreground tracking-tight">Your Areas</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Tap to view signals in each area</p>
        </div>
      </header>

      <main className="p-4 space-y-3">
        {followedAreaObjects.map((area, index) => {
          const isCurrent = area.id === currentLocalityId
          const isBeingUnfollowed = areaToUnfollow === area.id
          return (
            <Card
              key={area.id}
              className={cn(
                "p-4 transition-all duration-200",
                "border-border/50 shadow-sm",
                "animate-in fade-in slide-in-from-bottom-2",
                isCurrent && "ring-1 ring-primary/30"
              )}
              style={{ animationDelay: `${index * 75}ms`, animationFillMode: "both" }}
            >
              <div className="flex items-center gap-3">
                <button
                  onClick={() => onNavigateToArea?.(area.id)}
                  className={cn(
                    "w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0",
                    "hover:scale-105 active:scale-95 transition-transform",
                    area.isCalm ? "bg-muted" : "bg-primary/10"
                  )}
                >
                  <MapPin className={cn(
                    "w-5 h-5",
                    area.isCalm ? "text-muted-foreground" : "text-primary"
                  )} />
                </button>
                
                <button
                  onClick={() => onNavigateToArea?.(area.id)}
                  className="flex-1 min-w-0 text-left hover:opacity-80 transition-opacity"
                >
                  <div className="flex items-center gap-2">
                    <h3 className="font-medium text-foreground">{area.name}</h3>
                    {isCurrent && (
                      <span className="text-[10px] text-primary font-medium uppercase tracking-wide">
                        Current
                      </span>
                    )}
                  </div>
                  <p className={cn(
                    "text-sm mt-0.5",
                    area.isCalm ? "text-muted-foreground" : 
                    area.signalCount >= 3 ? "text-amber-600" : "text-primary"
                  )}>
                    {area.status}
                  </p>
                  <p className="text-[10px] text-muted-foreground/60 mt-0.5">
                    {area.lastChecked}
                  </p>
                </button>
                
                {/* Following toggle */}
                <button
                  onClick={() => setAreaToUnfollow(isBeingUnfollowed ? null : area.id)}
                  className={cn(
                    "px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-200",
                    isBeingUnfollowed 
                      ? "bg-destructive/10 text-destructive border border-destructive/30"
                      : "bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20"
                  )}
                >
                  {isBeingUnfollowed ? "Unfollow?" : (
                    <span className="flex items-center gap-1">
                      <Check className="w-3 h-3" />
                      Following
                    </span>
                  )}
                </button>
              </div>
              
              {/* Unfollow confirmation */}
              {isBeingUnfollowed && (
                <div className="mt-3 pt-3 border-t border-border/50 flex gap-2 animate-in fade-in slide-in-from-top-2 duration-200">
                  <button
                    onClick={() => handleUnfollowArea(area.id, area.name)}
                    className="flex-1 py-2 text-sm font-medium text-destructive bg-destructive/10 rounded-lg hover:bg-destructive/20 transition-colors"
                  >
                    Yes, unfollow
                  </button>
                  <button
                    onClick={() => setAreaToUnfollow(null)}
                    className="flex-1 py-2 text-sm font-medium text-muted-foreground bg-muted rounded-lg hover:bg-muted/80 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              )}
            </Card>
          )
        })}

        <div className="pt-4">
          <button 
            onClick={() => setIsAddModalOpen(true)}
            disabled={availableAreas.length === 0}
            className={cn(
              "w-full py-3 text-sm font-medium transition-all",
              availableAreas.length > 0 
                ? "text-primary hover:underline" 
                : "text-muted-foreground/50 cursor-not-allowed"
            )}
          >
            + Add another area
          </button>
        </div>
        
        {/* Device Storage Notice - only show when not signed in */}
        {!isSignedIn && (
          <>
            <div 
              className="flex items-center gap-2 justify-center pt-3 animate-in fade-in duration-500"
              style={{ animationDelay: "300ms", animationFillMode: "both" }}
            >
              <Smartphone className="w-3.5 h-3.5 text-muted-foreground/50" />
              <span className="text-xs text-muted-foreground/60">
                Saved on this device
              </span>
            </div>
            
            {/* Sync Hint */}
            <div 
              className="text-center animate-in fade-in duration-500"
              style={{ animationDelay: "400ms", animationFillMode: "both" }}
            >
              <button className="text-xs text-primary/70 hover:text-primary hover:underline transition-colors">
                Sign in to access your areas across devices
              </button>
            </div>
          </>
        )}
        
        {/* Show synced message when signed in */}
        {isSignedIn && (
          <div 
            className="flex items-center gap-2 justify-center pt-3 animate-in fade-in duration-500"
            style={{ animationDelay: "300ms", animationFillMode: "both" }}
          >
            <span className="text-xs text-muted-foreground/60">
              Synced to your account
            </span>
          </div>
        )}
      </main>

      {/* Unfollow Feedback Toast */}
      {unfollowFeedback && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="px-4 py-2.5 rounded-full bg-foreground text-background text-sm font-medium shadow-lg">
            {unfollowFeedback}
          </div>
        </div>
      )}

      {/* Add Area Modal */}
      {isAddModalOpen && (
        <div 
          className="fixed inset-0 z-50 flex items-end justify-center animate-modal-backdrop"
          onClick={() => setIsAddModalOpen(false)}
        >
          {/* Backdrop - pointer-events-none so clicks pass through to parent */}
          <div className="absolute inset-0 bg-foreground/20 backdrop-blur-sm pointer-events-none" />
          
          {/* Modal content - stops propagation */}
          <div 
            className="relative w-full max-w-md mx-4 mb-20 bg-card rounded-2xl shadow-xl animate-modal-content max-h-[60vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-border/50 flex-shrink-0">
              <div>
                <h3 className="text-base font-semibold text-foreground">Add an area</h3>
                <p className="text-xs text-muted-foreground mt-0.5">Select an area to follow</p>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-muted transition-colors active:scale-90"
              >
                <X className="w-5 h-5 text-muted-foreground" />
              </button>
            </div>
            
            {/* Area List */}
            <div className="p-2 overflow-y-auto flex-1">
              {availableAreas.length > 0 ? (
                availableAreas.map((area) => (
                  <button
                    key={area.id}
                    onClick={() => handleAddArea(area.id)}
                    disabled={justAdded === area.id}
                    className={cn(
                      "w-full flex items-center gap-3 p-3 rounded-xl transition-all duration-200",
                      "hover:bg-muted active:scale-[0.98]",
                      justAdded === area.id && "bg-primary/10"
                    )}
                  >
                    <div className={cn(
                      "w-10 h-10 rounded-full flex items-center justify-center",
                      area.isCalm ? "bg-muted" : "bg-primary/10"
                    )}>
                      {justAdded === area.id ? (
                        <Check className="w-5 h-5 text-primary" />
                      ) : (
                        <Plus className="w-5 h-5 text-muted-foreground" />
                      )}
                    </div>
                    <div className="flex-1 text-left">
                      <h4 className="font-medium text-foreground">{area.name}</h4>
                      <p className={cn(
                        "text-sm",
                        area.isCalm ? "text-muted-foreground" : "text-primary"
                      )}>
                        {area.status}
                      </p>
                    </div>
                  </button>
                ))
              ) : (
                <div className="p-8 text-center">
                  <p className="text-sm text-muted-foreground">
                    {"You're following all available areas"}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
