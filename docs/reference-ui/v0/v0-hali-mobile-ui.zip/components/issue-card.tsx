"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Zap, AlertTriangle, Droplets, Clock, Users, TrendingUp } from "lucide-react"
import { cn } from "@/lib/utils"

// Signal categories - the semantic meaning of the signal (expanded for livability)
export type SignalCategory = "electricity" | "water" | "road" | "flooding" | "garbage" | "noise" | "smell" | "dust" | "lighting" | "safety" | "crowding" | "encroachment"

// Icon types - for display purposes only
export type SignalIconType = "power" | "road" | "flooding"

export interface Issue {
  id: string
  title: string
  condition: string
  affectedCount: number
  observingCount?: number // number of people observing this signal
  userParticipation?: "affected" | "observing" | null // current user's participation status
  timeAgo: string
  duration: string | null // null for "just reported" signals (< 1 min)
  type: SignalIconType // icon type for display
  category?: SignalCategory // semantic category - determines institution and text
  location?: string
  isLive?: boolean
  possibleRestoration?: boolean
  activityLevel?: "steady" | "increasing" | "recent"
  urgency?: "standard" | "elevated"
  lastUpdated?: string
  createdByUser?: boolean // true if user created this signal
  // Lifecycle properties
  createdAt?: number // timestamp for lifecycle calculations
  lifecycleStage?: "unconfirmed" | "growing" | "steady" | "stabilizing" | "possible-restoration" | "resolved"
  lifecycleLabel?: string // e.g., "Unconfirmed report", "Reports coming in"
  liveIntensity?: "strong" | "soft" | "dim" | "none"
  shouldFade?: boolean // true if signal is in resolution stage
  hasOfficialUpdate?: boolean // true if official update exists
  isExperiential?: boolean // true for electricity/water - no "observing" option
  officialStage?: "none" | "dispatched" | "on-site" | "working" | "restoring" | "restored"
}

interface IssueCardProps {
  issue: Issue
  onClick?: () => void
  isHighlighted?: boolean
}

const typeIcons = {
  power: Zap,
  road: AlertTriangle,
  flooding: Droplets,
}

const conditionColors: Record<string, string> = {
  // Infrastructure
  "No power": "bg-amber-50 text-amber-700 border-amber-200",
  "Power outage": "bg-amber-50 text-amber-700 border-amber-200",
  "Unstable power": "bg-yellow-50 text-yellow-700 border-yellow-200",
  "Power going on/off": "bg-yellow-50 text-yellow-700 border-yellow-200",
  "No water": "bg-amber-50 text-amber-700 border-amber-200",
  "Low pressure": "bg-yellow-50 text-yellow-700 border-yellow-200",
  "Weak pressure": "bg-yellow-50 text-yellow-700 border-yellow-200",
  // Road/Traffic
  "Difficult to pass": "bg-orange-50 text-orange-700 border-orange-200",
  "Impassable": "bg-red-50 text-red-700 border-red-200",
  "Multiple potholes": "bg-orange-50 text-orange-700 border-orange-200",
  "Lane blocked": "bg-orange-50 text-orange-700 border-orange-200",
  "Traffic blocked": "bg-red-50 text-red-700 border-red-200",
  "Slow moving": "bg-orange-50 text-orange-700 border-orange-200",
  "Poor road condition": "bg-orange-50 text-orange-700 border-orange-200",
  "Partially blocked": "bg-orange-50 text-orange-700 border-orange-200",
  "Heavy traffic": "bg-orange-50 text-orange-700 border-orange-200",
  "Road blocked": "bg-red-50 text-red-700 border-red-200",
  "Road damage": "bg-orange-50 text-orange-700 border-orange-200",
  "Road narrowed": "bg-yellow-50 text-yellow-700 border-yellow-200",
  // Flooding
  "Water on road": "bg-sky-50 text-sky-700 border-sky-200",
  "Partially flooded": "bg-sky-50 text-sky-700 border-sky-200",
  // Garbage/Waste
  "Uncollected waste": "bg-yellow-50 text-yellow-700 border-yellow-200",
  "Dumped waste": "bg-yellow-50 text-yellow-700 border-yellow-200",
  "Overflowing bins": "bg-yellow-50 text-yellow-700 border-yellow-200",
  // Smell/Air
  "Sewage smell": "bg-amber-50 text-amber-700 border-amber-200",
  "Bad smell": "bg-amber-50 text-amber-700 border-amber-200",
  "Air pollution": "bg-slate-50 text-slate-700 border-slate-200",
  // Noise
  "Noise disturbance": "bg-violet-50 text-violet-700 border-violet-200",
  "Noisy construction": "bg-violet-50 text-violet-700 border-violet-200",
  "Noise late night": "bg-violet-50 text-violet-700 border-violet-200",
  "Noisy": "bg-violet-50 text-violet-700 border-violet-200",
  // Dust
  "Very dusty": "bg-stone-50 text-stone-700 border-stone-200",
  "Dusty air": "bg-stone-50 text-stone-700 border-stone-200",
  // Lighting/Safety
  "Dark area": "bg-slate-100 text-slate-700 border-slate-300",
  "Dark stretch": "bg-slate-100 text-slate-700 border-slate-300",
  "No street lights": "bg-slate-100 text-slate-700 border-slate-300",
  // Crowding/Encroachment
  "Sidewalk blocked": "bg-orange-50 text-orange-700 border-orange-200",
  "Walkway blocked": "bg-orange-50 text-orange-700 border-orange-200",
  "Pedestrian congestion": "bg-yellow-50 text-yellow-700 border-yellow-200",
  "Very crowded": "bg-yellow-50 text-yellow-700 border-yellow-200",
  // Restoration
  "Possible Restoration": "bg-emerald-50 text-emerald-700 border-emerald-200",
  "Restoration Reported": "bg-emerald-50 text-emerald-700 border-emerald-200",
}

const activityText = {
  steady: "Steady reports",
  increasing: "Reports increasing",
  recent: "Recently reported",
}

export function IssueCard({ issue, onClick, isHighlighted }: IssueCardProps) {
  const [isPressed, setIsPressed] = useState(false)
  const Icon = typeIcons[issue.type]
  const conditionStyle = conditionColors[issue.condition as keyof typeof conditionColors] || "bg-muted text-muted-foreground"
  
  const isElevated = issue.urgency === "elevated" || issue.condition === "Impassable"
  const isIncreasing = issue.activityLevel === "increasing"

  return (
    <Card 
      className={cn(
        "cursor-pointer shadow-sm",
        "transition-all duration-200 ease-out",
        "hover:shadow-md hover:-translate-y-0.5 hover:border-primary/20",
        isPressed && "scale-[0.97] shadow-lg shadow-primary/10 border-primary/30",
        !isPressed && "active:scale-[0.98]",
        isHighlighted && "ring-2 ring-primary/30 shadow-md shadow-primary/10",
        isElevated ? "border-border/70 shadow-md" : "border-border/50",
        issue.shouldFade && "opacity-60"
      )}
      onClick={onClick}
      onPointerDown={() => setIsPressed(true)}
      onPointerUp={() => setIsPressed(false)}
      onPointerLeave={() => setIsPressed(false)}
    >
      <CardContent className="p-4">
        <div className="flex gap-3">
          <div className="flex-shrink-0 mt-0.5">
            <div className={cn(
              "w-10 h-10 rounded-full flex items-center justify-center",
              "transition-transform duration-200",
              isPressed && "scale-110",
              isElevated ? "bg-primary/15" : "bg-primary/10"
            )}>
              <Icon className={cn(
                "w-5 h-5",
                isElevated ? "text-primary" : "text-primary/80"
              )} />
            </div>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <h3 className={cn(
                "leading-snug text-balance",
                isElevated ? "font-semibold text-foreground" : "font-medium text-foreground"
              )}>
                {issue.title}
              </h3>
              {issue.isLive && (
                <span className={cn(
                  "flex-shrink-0 flex items-center gap-1 text-[10px] font-medium uppercase tracking-wide",
                  issue.liveIntensity === "strong" && "text-primary",
                  issue.liveIntensity === "soft" && "text-primary/70",
                  issue.liveIntensity === "dim" && "text-primary/50",
                  !issue.liveIntensity && "text-primary/70", // fallback
                )}>
                  <span className={cn(
                    "w-1.5 h-1.5 rounded-full",
                    issue.liveIntensity === "strong" && "bg-primary animate-pulse-soft",
                    issue.liveIntensity === "soft" && "bg-primary/70 animate-pulse-soft",
                    issue.liveIntensity === "dim" && "bg-primary/50",
                    !issue.liveIntensity && "bg-primary/70 animate-pulse-soft", // fallback
                  )} />
                  Live
                </span>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-2 mt-2">
              <span className={cn(
                "text-xs px-2 py-0.5 rounded-full border font-medium",
                conditionStyle
              )}>
                {issue.condition}
              </span>
            </div>
            <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5" />
                {issue.affectedCount === 1 ? (
                  <span className="text-muted-foreground/70 italic">Unconfirmed report</span>
                ) : (
                  <>
                    <span className={cn(
                      "font-semibold tabular-nums",
                      isElevated ? "text-foreground" : "text-foreground"
                    )}>{issue.affectedCount}</span>
                    <span>affected</span>
                  </>
                )}
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                {issue.duration ? `Ongoing for ${issue.duration}` : "Just reported"}
              </span>
            </div>
            
            {/* Activity context layer - show lifecycle label */}
            <div className="flex items-center gap-2 mt-1.5">
              {issue.lifecycleLabel ? (
                <span className={cn(
                  "flex items-center gap-1 text-[10px]",
                  issue.lifecycleStage === "growing" && "text-primary/80 font-medium",
                  issue.lifecycleStage === "unconfirmed" && "text-muted-foreground/70 italic",
                  issue.lifecycleStage === "steady" && "text-muted-foreground/70",
                  issue.lifecycleStage === "stabilizing" && "text-muted-foreground/60",
                  issue.lifecycleStage === "possible-restoration" && "text-emerald-600/70",
                )}>
                  {issue.lifecycleStage === "growing" && <TrendingUp className="w-3 h-3" />}
                  {issue.lifecycleLabel}
                </span>
              ) : issue.activityLevel ? (
                <span className={cn(
                  "flex items-center gap-1 text-[10px]",
                  isIncreasing ? "text-primary/80 font-medium" : "text-muted-foreground/70"
                )}>
                  {isIncreasing && <TrendingUp className="w-3 h-3" />}
                  {activityText[issue.activityLevel]}
                </span>
              ) : null}
              {issue.lastUpdated && (
                <>
                  {(issue.lifecycleLabel || issue.activityLevel) && <span className="text-muted-foreground/40">·</span>}
                  <span className="text-[10px] text-muted-foreground/70">
                    Updated {issue.lastUpdated}
                  </span>
                </>
              )}
              {!issue.lifecycleLabel && !issue.activityLevel && !issue.lastUpdated && (
                <span className="text-[10px] text-muted-foreground/70">
                  Based on nearby reports
                </span>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
