import { Building2 } from "lucide-react"
import { cn } from "@/lib/utils"

export interface OfficialUpdateData {
  source: string
  message: string
  fullMessage?: string
  updatedAgo?: string
  affectedAreas?: string[]
  expectedResolution?: string
  link?: string
}

interface OfficialUpdateProps {
  source: string
  message: string
  onClick?: () => void
}

export function OfficialUpdate({ source, message, onClick }: OfficialUpdateProps) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full flex items-start gap-2.5 px-3 py-2.5 rounded-md text-left",
        "bg-muted/40 border-l border-muted-foreground/20",
        "transition-all duration-200",
        "hover:bg-muted/60 hover:border-muted-foreground/30",
        "active:scale-[0.99]"
      )}
    >
      <div className="flex-shrink-0 mt-px">
        <Building2 className="w-3.5 h-3.5 text-muted-foreground/50" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-[13px] text-muted-foreground leading-snug">
          <span className="font-medium text-foreground/80">{source}</span>
          <span className="mx-1.5 text-muted-foreground/40">·</span>
          <span>{message}</span>
        </p>
      </div>
    </button>
  )
}
