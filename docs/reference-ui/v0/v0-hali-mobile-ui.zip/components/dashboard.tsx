"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, AlertCircle, CheckCircle, Activity, X, MapPin, Users, Clock, Check } from "lucide-react"
import { cn } from "@/lib/utils"

interface DashboardIssue {
  id: string
  title: string
  status: "critical" | "active" | "resolved"
  affectedCount: number
  location: string
  timeline: string[]
}

const dashboardIssues: DashboardIssue[] = [
  {
    id: "1",
    title: "South B Power Outage",
    status: "critical",
    affectedCount: 37,
    location: "South B — Plainsview Rd",
    timeline: ["Reported at 2:15 PM", "Investigation started at 2:30 PM", "Crew dispatched at 2:45 PM"],
  },
  {
    id: "2",
    title: "Lusaka Rd Potholes",
    status: "active",
    affectedCount: 52,
    location: "Lusaka Rd / Uhuru Hwy",
    timeline: ["Reported at 10:00 AM", "Marked for repair"],
  },
  {
    id: "3",
    title: "Nyayo Flooding",
    status: "active",
    affectedCount: 21,
    location: "Nyayo Stadium roundabout",
    timeline: ["Reported at 1:00 PM", "Response teams deployed at 1:30 PM"],
  },
]

const statusColors = {
  critical: "bg-red-50 text-red-700 border-red-200",
  active: "bg-amber-50 text-amber-700 border-amber-200",
  resolved: "bg-emerald-50 text-emerald-700 border-emerald-200",
}

interface DashboardProps {
  onBack: () => void
}

export function Dashboard({ onBack }: DashboardProps) {
  const [selectedIssue, setSelectedIssue] = useState<DashboardIssue | null>(null)
  const [updatePosted, setUpdatePosted] = useState(false)

  const handlePostUpdate = () => {
    setUpdatePosted(true)
    setTimeout(() => setUpdatePosted(false), 3000)
  }

  return (
    <div className="min-h-screen bg-background animate-slide-in-right">
      <header className="sticky top-0 z-10 bg-background/95 backdrop-blur-sm border-b border-border/50">
        <div className="flex items-center gap-3 p-4">
          <button 
            onClick={onBack}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-muted transition-all duration-200 active:scale-90"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </button>
          <div>
            <h1 className="text-lg font-semibold text-foreground">Nairobi Operations Dashboard</h1>
            <p className="text-xs text-muted-foreground">Real-time civic monitoring</p>
          </div>
        </div>
      </header>

      <main className="p-4 pb-8 space-y-6">
        <section className="grid grid-cols-3 gap-3">
          <Card className="border-border/50">
            <CardContent className="p-4 text-center">
              <div className="w-10 h-10 mx-auto rounded-full bg-primary/10 flex items-center justify-center mb-2">
                <Activity className="w-5 h-5 text-primary" />
              </div>
              <p className="text-2xl font-semibold text-foreground">24</p>
              <p className="text-xs text-muted-foreground">Active Signals</p>
            </CardContent>
          </Card>
          <Card className="border-border/50">
            <CardContent className="p-4 text-center">
              <div className="w-10 h-10 mx-auto rounded-full bg-red-50 flex items-center justify-center mb-2">
                <AlertCircle className="w-5 h-5 text-red-600" />
              </div>
              <p className="text-2xl font-semibold text-foreground">3</p>
              <p className="text-xs text-muted-foreground">Critical Issues</p>
            </CardContent>
          </Card>
          <Card className="border-border/50">
            <CardContent className="p-4 text-center">
              <div className="w-10 h-10 mx-auto rounded-full bg-emerald-50 flex items-center justify-center mb-2">
                <CheckCircle className="w-5 h-5 text-emerald-600" />
              </div>
              <p className="text-2xl font-semibold text-foreground">12</p>
              <p className="text-xs text-muted-foreground">Resolved Today</p>
            </CardContent>
          </Card>
        </section>

        <section>
          <h2 className="text-sm font-medium text-muted-foreground mb-3">Active Issues</h2>
          <div className="space-y-2">
            {dashboardIssues.map((issue) => (
              <button
                key={issue.id}
                onClick={() => setSelectedIssue(issue)}
                className={cn(
                  "w-full text-left p-4 rounded-xl border transition-all duration-200",
                  "bg-card hover:shadow-sm hover:-translate-y-0.5",
                  "active:scale-[0.98] active:translate-y-0",
                  selectedIssue?.id === issue.id ? "border-primary shadow-sm" : "border-border/50"
                )}
              >
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-foreground">{issue.title}</h3>
                  <span className={cn(
                    "text-xs px-2 py-0.5 rounded-full border font-medium capitalize",
                    statusColors[issue.status]
                  )}>
                    {issue.status}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground mt-1">{issue.location}</p>
              </button>
            ))}
          </div>
        </section>

        {selectedIssue && (
          <section className="animate-expand-down">
            <Card className="border-primary/30 shadow-sm">
              <CardContent className="p-4 space-y-4">
                <div className="flex items-start justify-between">
                  <h3 className="font-semibold text-foreground">{selectedIssue.title}</h3>
                  <button 
                    onClick={() => setSelectedIssue(null)}
                    className="text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-muted-foreground" />
                    <span className="text-foreground">{selectedIssue.location}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Users className="w-4 h-4 text-muted-foreground" />
                    <span className="text-foreground">{selectedIssue.affectedCount} affected</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-border/50">
                  <h4 className="text-xs font-medium text-muted-foreground mb-2">Timeline</h4>
                  <div className="space-y-2">
                    {selectedIssue.timeline.map((event, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm">
                        <Clock className="w-3.5 h-3.5 text-muted-foreground" />
                        <span className="text-foreground">{event}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <Button 
                  onClick={handlePostUpdate}
                  className="w-full transition-all duration-200 active:scale-[0.98]"
                  disabled={updatePosted}
                >
                  {updatePosted ? (
                    <span className="flex items-center gap-2 animate-fade-up">
                      <Check className="w-4 h-4" />
                      Update Posted
                    </span>
                  ) : (
                    "Post Update"
                  )}
                </Button>
              </CardContent>
            </Card>
          </section>
        )}
      </main>
    </div>
  )
}
