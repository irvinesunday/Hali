"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Zap, AlertTriangle, Droplets, MapPin, Clock, Users, Check, HelpCircle, TrendingUp } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Issue } from "./issue-card"
import { OfficialUpdateDetail, type OfficialUpdateData } from "./official-update-detail"
import { getOfficialMessage, getOfficialTimeText, type OfficialStage } from "@/hooks/use-simulation"

const typeIcons = {
  power: Zap,
  road: AlertTriangle,
  flooding: Droplets,
}

const conditionColors: Record<string, string> = {
  // Infrastructure
  "No power": "bg-amber-50 text-amber-700 border-amber-200",
  "Power outage": "bg-amber-50 text-amber-700 border-amber-200",
  "Unstable power": "bg-yellow-50 text-yellow-700 border-yellow-200",
  "Power going on/off": "bg-yellow-50 text-yellow-700 border-yellow-200",
  "No water": "bg-amber-50 text-amber-700 border-amber-200",
  "Low pressure": "bg-yellow-50 text-yellow-700 border-yellow-200",
  "Weak pressure": "bg-yellow-50 text-yellow-700 border-yellow-200",
  // Road/Traffic
  "Difficult to pass": "bg-orange-50 text-orange-700 border-orange-200",
  "Impassable": "bg-red-50 text-red-700 border-red-200",
  "Multiple potholes": "bg-orange-50 text-orange-700 border-orange-200",
  "Lane blocked": "bg-orange-50 text-orange-700 border-orange-200",
  "Traffic blocked": "bg-red-50 text-red-700 border-red-200",
  "Slow moving": "bg-orange-50 text-orange-700 border-orange-200",
  "Poor road condition": "bg-orange-50 text-orange-700 border-orange-200",
  "Partially blocked": "bg-orange-50 text-orange-700 border-orange-200",
  "Heavy traffic": "bg-orange-50 text-orange-700 border-orange-200",
  "Road blocked": "bg-red-50 text-red-700 border-red-200",
  "Road damage": "bg-orange-50 text-orange-700 border-orange-200",
  "Road narrowed": "bg-yellow-50 text-yellow-700 border-yellow-200",
  // Flooding
  "Water on road": "bg-sky-50 text-sky-700 border-sky-200",
  "Partially flooded": "bg-sky-50 text-sky-700 border-sky-200",
  // Garbage/Waste
  "Uncollected waste": "bg-yellow-50 text-yellow-700 border-yellow-200",
  "Dumped waste": "bg-yellow-50 text-yellow-700 border-yellow-200",
  "Overflowing bins": "bg-yellow-50 text-yellow-700 border-yellow-200",
  // Smell/Air
  "Sewage smell": "bg-amber-50 text-amber-700 border-amber-200",
  "Bad smell": "bg-amber-50 text-amber-700 border-amber-200",
  "Air pollution": "bg-slate-50 text-slate-700 border-slate-200",
  // Noise
  "Noise disturbance": "bg-violet-50 text-violet-700 border-violet-200",
  "Noisy construction": "bg-violet-50 text-violet-700 border-violet-200",
  "Noise late night": "bg-violet-50 text-violet-700 border-violet-200",
  "Noisy": "bg-violet-50 text-violet-700 border-violet-200",
  // Dust
  "Very dusty": "bg-stone-50 text-stone-700 border-stone-200",
  "Dusty air": "bg-stone-50 text-stone-700 border-stone-200",
  // Lighting/Safety
  "Dark area": "bg-slate-100 text-slate-700 border-slate-300",
  "Dark stretch": "bg-slate-100 text-slate-700 border-slate-300",
  "No street lights": "bg-slate-100 text-slate-700 border-slate-300",
  // Crowding/Encroachment
  "Sidewalk blocked": "bg-orange-50 text-orange-700 border-orange-200",
  "Walkway blocked": "bg-orange-50 text-orange-700 border-orange-200",
  "Pedestrian congestion": "bg-yellow-50 text-yellow-700 border-yellow-200",
  "Very crowded": "bg-yellow-50 text-yellow-700 border-yellow-200",
  // Restoration
  "Possible Restoration": "bg-emerald-50 text-emerald-700 border-emerald-200",
  "Restoration Reported": "bg-emerald-50 text-emerald-700 border-emerald-200",
}

const activityText = {
  steady: "Steady reports",
  increasing: "Reports increasing",
  recent: "Recently reported",
}

// Category → Institution mapping (expanded for livability signals)
const categoryToInstitution: Record<string, string> = {
  electricity: "Kenya Power",
  water: "Nairobi Water",
  road: "KURA / KeNHA",
  flooding: "Nairobi County",
  garbage: "Nairobi County",
  noise: "Nairobi County",
  smell: "NEMA / Nairobi County",
  dust: "NEMA / KeNHA",
  lighting: "Kenya Power / County",
  safety: "Nairobi County",
  crowding: "Nairobi County",
  encroachment: "Nairobi County",
}

// Category → "What people are reporting" text (expanded)
const categoryReportingText: Record<string, string> = {
  electricity: "Homes and nearby shops currently without electricity",
  water: "Homes and shops currently without water supply",
  road: "Road condition affecting traffic flow and vehicle passage",
  flooding: "Floodwater affecting the road and making passage difficult",
  garbage: "Uncollected garbage piling up in the area",
  noise: "Noise disturbance affecting residents in the area",
  smell: "Unpleasant smell affecting air quality in the area",
  dust: "Excessive dust affecting air quality and visibility",
  lighting: "Inadequate street lighting creating safety concerns",
  safety: "Safety concern reported by residents in the area",
  crowding: "Overcrowding causing inconvenience in the area",
  encroachment: "Sidewalk or public space encroachment reported",
}

// Fallback for legacy type-based lookup
const typeToCategory: Record<string, string> = {
  power: "electricity", // default, but could be water
  road: "road",
  flooding: "flooding",
}

// Get category from issue (handles legacy signals)
function getIssueCategory(issue: { category?: string; type: string; condition?: string; title?: string }): string {
  // If category is explicitly set, use it
  if (issue.category) return issue.category
  
  // Infer category from condition/title for water signals
  const condition = issue.condition?.toLowerCase() || ""
  const title = issue.title?.toLowerCase() || ""
  
  if (condition.includes("water") || condition.includes("pressure") || 
      title.includes("water") || title.includes("supply")) {
    return "water"
  }
  
  // Default to type-based mapping
  return typeToCategory[issue.type] || "electricity"
}

// Get institution for an issue
function getInstitution(issue: { category?: string; type: string; condition?: string; title?: string }): string {
  const category = getIssueCategory(issue)
  return categoryToInstitution[category] || "Kenya Power"
}

// Get reporting text for an issue
function getReportingText(issue: { category?: string; type: string; condition?: string; title?: string }): string {
  const category = getIssueCategory(issue)
  return categoryReportingText[category] || "Issue reported in the area"
}

// Category-aware official messages (expanded for livability)
const categoryOfficialMessages: Record<string, Record<string, string>> = {
  electricity: {
    dispatched: "Teams have been dispatched to assess the situation.",
    "on-site": "Technicians are on site assessing the extent of the outage.",
    working: "Work is ongoing to restore power supply to affected areas.",
    restoring: "Restoration is in progress. Power returning to some areas.",
    restored: "Power has been restored to the affected area.",
  },
  water: {
    dispatched: "Nairobi Water teams have been dispatched to assess the situation.",
    "on-site": "Technicians are on site investigating the water supply issue.",
    working: "Repair work is ongoing to restore water supply.",
    restoring: "Water supply restoration is in progress.",
    restored: "Water supply has been restored to the affected area.",
  },
  road: {
    dispatched: "Road maintenance teams have been notified and are en route.",
    "on-site": "Teams are on site evaluating road conditions.",
    working: "Repair work is in progress. Please use alternative routes.",
    restoring: "Road repairs nearing completion. Lane partially open.",
    restored: "Road repairs complete. Normal traffic resumed.",
  },
  flooding: {
    dispatched: "Emergency response teams have been dispatched to the area.",
    "on-site": "Response teams are on site assessing water levels.",
    working: "Drainage clearing and pumping operations are underway.",
    restoring: "Water levels receding. Road becoming passable.",
    restored: "Flooding cleared. Road fully passable.",
  },
  garbage: {
    dispatched: "Waste collection teams have been notified.",
    "on-site": "Collection crews are assessing the situation.",
    working: "Garbage collection is in progress.",
    restoring: "Collection nearing completion.",
    restored: "Garbage has been collected from the area.",
  },
  noise: {
    dispatched: "County enforcement officers have been notified.",
    "on-site": "Officers are investigating the noise complaint.",
    working: "Addressing the noise disturbance.",
    restoring: "Situation being resolved.",
    restored: "Noise issue has been addressed.",
  },
  smell: {
    dispatched: "Environmental officers have been notified.",
    "on-site": "Inspectors are investigating the source.",
    working: "Working to address the cause.",
    restoring: "Issue being resolved.",
    restored: "Smell issue has been addressed.",
  },
  lighting: {
    dispatched: "Maintenance team has been notified.",
    "on-site": "Technicians are assessing the lights.",
    working: "Repair work in progress.",
    restoring: "Lights being restored.",
    restored: "Street lights have been repaired.",
  },
  dust: {
    dispatched: "Authorities have been notified.",
    "on-site": "Assessing dust mitigation options.",
    working: "Working on dust control measures.",
    restoring: "Measures being implemented.",
    restored: "Dust issue has been addressed.",
  },
  crowding: {
    dispatched: "County enforcement notified.",
    "on-site": "Officers assessing the situation.",
    working: "Working to ease congestion.",
    restoring: "Situation improving.",
    restored: "Crowding has been addressed.",
  },
  encroachment: {
    dispatched: "County enforcement notified.",
    "on-site": "Officers on site.",
    working: "Addressing the encroachment.",
    restoring: "Area being cleared.",
    restored: "Encroachment has been addressed.",
  },
}

// Get category-aware official message
function getCategoryOfficialMessage(stage: OfficialStage, category: string): string {
  const messages = categoryOfficialMessages[category] || categoryOfficialMessages.electricity
  return messages[stage] || ""
}

// Check if this is an experiential signal type (electricity/water - no observing option)
// Uses both type and category to determine - livability signals are mostly observable
function isExperientialType(type: "power" | "road" | "flooding", category?: string): boolean {
  // Electricity and water are experiential - you're either affected or not
  if (category === "electricity" || category === "water") return true
  // Legacy: power type without category
  if (type === "power" && !category) return true
  // Everything else (road, flooding, garbage, noise, smell, dust, etc.) can be observed
  return false
}

interface IssueDetailProps {
  issue: Issue
  onBack: () => void
  onParticipate?: (signalId: string, status: "affected" | "observing") => void
  onRemoveParticipation?: (signalId: string) => void
  getParticipationStatus?: (signalId: string) => "affected" | "observing" | null
  onRestorationResponse?: (signalId: string, response: "restored" | "still-affected" | "not-sure") => void
  getRestorationResponse?: (signalId: string) => "restored" | "still-affected" | "not-sure" | null
}

function AnimatedCount({ value, shouldAnimate }: { value: number; shouldAnimate: boolean }) {
  const [displayValue, setDisplayValue] = useState(value)
  const [isPop, setIsPop] = useState(false)
  const prevValue = useRef(value)

  useEffect(() => {
    if (value !== prevValue.current) {
      setIsPop(true)
      const popTimer = setTimeout(() => setIsPop(false), 300)
      prevValue.current = value
      return () => clearTimeout(popTimer)
    }
  }, [value])

  useEffect(() => {
    if (displayValue !== value) {
      const timer = setTimeout(() => {
        setDisplayValue(prev => {
          if (prev < value) return prev + 1
          if (prev > value) return prev - 1
          return value
        })
      }, 50)
      return () => clearTimeout(timer)
    }
  }, [displayValue, value])

  return (
    <span className={cn(
      "tabular-nums inline-block transition-transform",
      isPop && shouldAnimate && "animate-count-pop"
    )}>
      {displayValue}
    </span>
  )
}

export function IssueDetail({ 
  issue, 
  onBack, 
  onParticipate, 
  onRemoveParticipation, 
  getParticipationStatus,
  onRestorationResponse,
  getRestorationResponse,
}: IssueDetailProps) {
  // Initialize from global state if available
  const initialStatus = getParticipationStatus?.(issue.id) ?? issue.userParticipation ?? null
  const initialRestorationResponse = getRestorationResponse?.(issue.id) ?? null
  const [affectedCount, setAffectedCount] = useState(issue.affectedCount)
  const [observingCount, setObservingCount] = useState(issue.observingCount || 0)
  const [userStatus, setUserStatus] = useState<"affected" | "observing" | null>(initialStatus)
  const [showConfirmation, setShowConfirmation] = useState(false)
  const [isHighlighted, setIsHighlighted] = useState(false)
  const [restorationResponse, setRestorationResponse] = useState<"restored" | "still-affected" | "not-sure" | null>(initialRestorationResponse)
  const [shouldAnimateCount, setShouldAnimateCount] = useState(false)
  const [sectionsVisible, setSectionsVisible] = useState(false)
  const [selectedOfficialUpdate, setSelectedOfficialUpdate] = useState<OfficialUpdateData | null>(null)

  const Icon = typeIcons[issue.type]
  const conditionStyle = conditionColors[issue.condition as keyof typeof conditionColors] || "bg-muted text-muted-foreground"
  
  // Get category-aware details
  const officialSource = getInstitution(issue)
  const reportingText = getReportingText(issue)

  // Stagger section animations on mount
  useEffect(() => {
    const timer = setTimeout(() => setSectionsVisible(true), 100)
    return () => clearTimeout(timer)
  }, [])

  const [removedFeedback, setRemovedFeedback] = useState(false)

  const handleAffected = () => {
    // Toggle behavior: if already affected, remove participation
    if (userStatus === "affected") {
      setAffectedCount(prev => Math.max(0, prev - 1))
      setUserStatus(null)
      setShowConfirmation(false)
      setRemovedFeedback(true)
      onRemoveParticipation?.(issue.id)
      setTimeout(() => setRemovedFeedback(false), 2500)
      return
    }
    
    setShouldAnimateCount(true)
    
    // If previously observing, decrement that count
    if (userStatus === "observing") {
      setObservingCount(prev => Math.max(0, prev - 1))
    }
    
    setAffectedCount(prev => prev + 1)
    setUserStatus("affected")
    setShowConfirmation(true)
    setIsHighlighted(true)
    
    // Persist to global state
    onParticipate?.(issue.id, "affected")
    
    setTimeout(() => setIsHighlighted(false), 2000)
    // Auto-dismiss confirmation after 2.5 seconds
    setTimeout(() => setShowConfirmation(false), 2500)
  }

  const handleObserving = () => {
    // Toggle behavior: if already observing, remove participation
    if (userStatus === "observing") {
      setObservingCount(prev => Math.max(0, prev - 1))
      setUserStatus(null)
      setShowConfirmation(false)
      setRemovedFeedback(true)
      onRemoveParticipation?.(issue.id)
      setTimeout(() => setRemovedFeedback(false), 2500)
      return
    }
    
    // If previously affected, decrement that count
    if (userStatus === "affected") {
      setAffectedCount(prev => Math.max(0, prev - 1))
    }
    
    setObservingCount(prev => prev + 1)
    setUserStatus("observing")
    setShowConfirmation(true)
    
    // Persist to global state
    onParticipate?.(issue.id, "observing")
    
    // Auto-dismiss confirmation after 2.5 seconds
    setTimeout(() => setShowConfirmation(false), 2500)
  }

  const handleRestorationResponse = (response: "restored" | "still-affected" | "not-sure") => {
    setRestorationResponse(response)
    // Persist to global state
    onRestorationResponse?.(issue.id, response)
    if (response === "restored") {
      setUserStatus(null)
    }
  }

  // Determine if restoration section should show based on official stage or signal lifecycle
  const officialSaysRestored = issue.officialStage === "restored" || issue.officialStage === "restoring"
  const signalSaysRestoring = issue.lifecycleStage === "possible-restoration" || issue.lifecycleStage === "resolved"
  const showRestorationCheck = issue.possibleRestoration || officialSaysRestored || signalSaysRestoring || issue.type === "power" || issue.type === "flooding"
  // Show restoration prompt when official says restored OR signal is in restoration phase
  const hasConfirmedRestoration = issue.possibleRestoration || officialSaysRestored || signalSaysRestoring

  return (
    <div className="min-h-screen bg-background animate-slide-in-right">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background/95 backdrop-blur-sm border-b border-border/50">
        <div className="flex items-center gap-3 p-4">
          <button 
            onClick={onBack}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-muted transition-all duration-200 active:scale-90"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </button>
          <span className="text-sm font-medium text-muted-foreground">Signal Details</span>
          {issue.isLive && (
            <span className={cn(
              "ml-auto flex items-center gap-1.5 text-[10px] font-medium uppercase tracking-wide",
              issue.liveIntensity === "strong" && "text-primary",
              issue.liveIntensity === "soft" && "text-primary/70",
              issue.liveIntensity === "dim" && "text-primary/50",
              !issue.liveIntensity && "text-primary/70", // fallback
            )}>
              <span className={cn(
                "w-2 h-2 rounded-full",
                issue.liveIntensity === "strong" && "bg-primary animate-pulse-soft",
                issue.liveIntensity === "soft" && "bg-primary/70 animate-pulse-soft",
                issue.liveIntensity === "dim" && "bg-primary/50",
                !issue.liveIntensity && "bg-primary/70 animate-pulse-soft", // fallback
              )} />
              Live
            </span>
          )}
        </div>
      </header>

      <main className="p-4 pb-8 space-y-6">
        {/* 1. TOP SUMMARY SECTION */}
        <section 
          className={cn(
            "space-y-4 p-4 -mx-4 transition-all duration-500 ease-out",
            isHighlighted && "bg-primary/5",
            sectionsVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2"
          )}
        >
          <div className={cn(
            "w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center",
            "transition-transform duration-300",
            isHighlighted && "scale-110"
          )}>
            <Icon className="w-7 h-7 text-primary" />
          </div>
          
          <h1 className="text-xl font-semibold text-foreground leading-snug text-balance">
            {issue.title}
          </h1>

          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="w-4 h-4" />
            <span>{issue.location || "Location unspecified"}</span>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <span className={cn(
              "text-sm px-3 py-1 rounded-full border font-medium transition-all duration-300",
              hasConfirmedRestoration ? "bg-emerald-50 text-emerald-700 border-emerald-200" : conditionStyle
            )}>
              {issue.officialStage === "restored" 
                ? "Restoration Reported" 
                : hasConfirmedRestoration 
                  ? "Possible Restoration" 
                  : issue.condition}
            </span>
          </div>

          <div className="flex items-center gap-6 pt-2">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-muted-foreground" />
              <span className="text-lg font-semibold text-foreground">
                <AnimatedCount value={affectedCount} shouldAnimate={shouldAnimateCount} />
              </span>
              <span className="text-sm text-muted-foreground">affected</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">
                {issue.duration ? `Ongoing for ${issue.duration}` : "Just reported"}
              </span>
            </div>
          </div>
          {/* Activity context - show lifecycle label */}
          <div className="flex items-center gap-2">
            {issue.lifecycleLabel ? (
              <span className={cn(
                "flex items-center gap-1 text-xs",
                issue.lifecycleStage === "growing" && "text-primary font-medium",
                issue.lifecycleStage === "unconfirmed" && "text-muted-foreground/70 italic",
                issue.lifecycleStage === "steady" && "text-muted-foreground/70",
                issue.lifecycleStage === "stabilizing" && "text-muted-foreground/60",
                issue.lifecycleStage === "possible-restoration" && "text-emerald-600/70",
              )}>
                {issue.lifecycleStage === "growing" && <TrendingUp className="w-3 h-3" />}
                {issue.lifecycleLabel}
              </span>
            ) : issue.activityLevel ? (
              <span className={cn(
                "flex items-center gap-1 text-xs",
                issue.activityLevel === "increasing" ? "text-primary font-medium" : "text-muted-foreground/70"
              )}>
                {issue.activityLevel === "increasing" && <TrendingUp className="w-3 h-3" />}
                {activityText[issue.activityLevel]}
              </span>
            ) : null}
            {issue.lastUpdated && (
              <>
                {(issue.lifecycleLabel || issue.activityLevel) && <span className="text-muted-foreground/40">·</span>}
                <span className="text-xs text-muted-foreground/70">
                  Updated {issue.lastUpdated}
                </span>
              </>
            )}
            {!issue.lifecycleLabel && !issue.activityLevel && !issue.lastUpdated && (
              <span className="text-xs text-muted-foreground/70">
                Based on nearby reports
              </span>
            )}
          </div>
        </section>

        {/* 2. PARTICIPATION ACTIONS */}
        {!hasConfirmedRestoration && (
          <section 
            className={cn(
              "space-y-3 transition-all duration-500 ease-out delay-75",
              sectionsVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2"
            )}
          >
            {/* Show "You reported this" for creator instead of participation buttons */}
            {issue.createdByUser ? (
              <div className="p-4 rounded-xl bg-primary/5 border border-primary/20">
                <p className="text-sm text-center text-primary font-medium flex items-center justify-center gap-2">
                  <Check className="w-4 h-4" />
                  {"You reported this"}
                </p>
                <p className="text-xs text-center text-muted-foreground mt-1">
                  {"You're automatically marked as affected"}
                </p>
              </div>
            ) : (
              <>
                <Button 
                  onClick={handleAffected}
                  className={cn(
                    "w-full h-12 text-base font-medium transition-all duration-300",
                    userStatus === "affected" && "bg-primary/90 shadow-lg shadow-primary/20"
                  )}
                >
                  {userStatus === "affected" ? (
                    <span className="flex items-center gap-2">
                      <Check className="w-5 h-5" />
                      {"I'm Affected"}
                      <span className="text-xs opacity-70">(tap to remove)</span>
                    </span>
                  ) : (
                    "I'm Affected"
                  )}
                </Button>
                
                {/* Only show "Observing" button for non-experiential signals (road, flooding) */}
                {!isExperientialType(issue.type, issue.category) && (
                  <Button 
                    onClick={handleObserving}
                    variant="outline"
                    className={cn(
                      "w-full h-12 text-base font-medium transition-all duration-300",
                      userStatus === "observing" && "border-primary text-primary bg-primary/5"
                    )}
                  >
                    {userStatus === "observing" ? (
                      <span className="flex items-center gap-2">
                        <Check className="w-5 h-5" />
                        {"I'm Observing"}
                        <span className="text-xs opacity-70">(tap to remove)</span>
                      </span>
                    ) : (
                      "I'm Observing"
                    )}
                  </Button>
                )}

                {/* Microcopy hint - only show when user hasn't participated yet */}
                {!userStatus && (
                  <p className="text-[10px] text-muted-foreground/60 text-center pt-1">
                    {isExperientialType(issue.type, issue.category) 
                      ? "Let others know if this is affecting you"
                      : "Affected = this is directly impacting you · Observing = you can see it happening"
                    }
                  </p>
                )}

                {showConfirmation && (
                  <div className="animate-fade-up space-y-2 pt-1 transition-opacity duration-500">
                    <p className="text-sm text-center text-primary font-medium">
                      {userStatus === "affected" ? "You've added your voice" : "Thanks for the update"}
                    </p>
                    {userStatus === "affected" && (
                      <button className="block mx-auto text-xs text-muted-foreground hover:text-foreground transition-colors underline underline-offset-2">
                        Add further context
                      </button>
                    )}
                  </div>
                )}

                {removedFeedback && (
                  <div className="animate-fade-up pt-1 transition-opacity duration-500">
                    <p className="text-sm text-center text-muted-foreground">
                      {"You've removed your update"}
                    </p>
                  </div>
                )}
              </>
            )}
          </section>
        )}

        {/* 3. SITUATION DETAILS */}
        <section 
          className={cn(
            "space-y-4 pt-2 transition-all duration-500 ease-out delay-100",
            sectionsVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2"
          )}
        >
          <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
            Situation Details
          </h2>
          <div className="space-y-3 p-4 rounded-xl bg-muted/30 border border-border/50">
            <div className="space-y-1">
              <span className="text-xs text-muted-foreground">What people are reporting</span>
              <p className="text-sm text-foreground">{reportingText}</p>
            </div>
            <div className="h-px bg-border/50" />
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <span className="text-xs text-muted-foreground">Current condition</span>
                <p className="text-sm font-medium text-foreground">{issue.condition}</p>
              </div>
              <div className="space-y-1">
                <span className="text-xs text-muted-foreground">Started</span>
                <p className="text-sm text-foreground">Around {issue.duration} ago</p>
              </div>
            </div>
            <div className="h-px bg-border/50" />
            <div className="space-y-1">
              <span className="text-xs text-muted-foreground">Location</span>
              <p className="text-sm text-foreground">{issue.location || "Location unspecified"}</p>
            </div>
          </div>
        </section>

        {/* 4. OFFICIAL UPDATE SECTION */}
        <section 
          className={cn(
            "space-y-3 transition-all duration-500 ease-out delay-150",
            sectionsVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2"
          )}
        >
          <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
            Official Update
          </h2>
          {issue.hasOfficialUpdate && issue.officialStage && issue.officialStage !== "none" ? (
            (() => {
              const category = getIssueCategory(issue)
              const officialMessage = getCategoryOfficialMessage(issue.officialStage as OfficialStage, category)
              const officialTime = getOfficialTimeText(issue.officialStage as OfficialStage)
              return (
                <button
                  onClick={() => setSelectedOfficialUpdate({
                    source: officialSource,
                    message: officialMessage,
                    fullMessage: officialMessage,
                    updatedAgo: officialTime,
                    affectedAreas: [issue.location || "Reported area"],
                  })}
                  className="w-full text-left p-4 rounded-xl bg-primary/[0.03] border-l-2 border-primary/30 hover:bg-primary/[0.06] transition-colors duration-200 active:scale-[0.99]"
                >
                  <div className="flex items-start gap-3">
                    <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center mt-0.5">
                      <span className="text-xs font-semibold text-primary">
                        {officialSource.charAt(0)}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm font-medium text-foreground">
                          {officialSource}
                        </span>
                        <span className="text-[10px] text-muted-foreground">
                          Updated {officialTime}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {officialMessage}
                      </p>
                    </div>
                  </div>
                </button>
              )
            })()
          ) : (
            <div className="p-4 rounded-xl bg-muted/30 border border-border/50">
              <p className="text-sm text-muted-foreground text-center">
                No official update yet
              </p>
              <p className="text-xs text-muted-foreground/60 text-center mt-1">
                Some issues may not receive an official response
              </p>
            </div>
          )}
        </section>

        {/* 5. RESTORATION STATUS SECTION */}
        {showRestorationCheck && (
          <section 
            className={cn(
              "space-y-3 transition-all duration-500 ease-out delay-200",
              sectionsVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2"
            )}
          >
            <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
              Restoration Status
            </h2>
            
            {!hasConfirmedRestoration && !restorationResponse && (
              <div className="p-4 rounded-xl bg-muted/30 border border-border/50">
                <p className="text-sm text-muted-foreground text-center">
                  No restoration confirmed yet
                </p>
              </div>
            )}

            {hasConfirmedRestoration && !restorationResponse && (
              <div className="animate-expand-down">
                <div className="p-4 rounded-xl bg-emerald-50/50 border border-emerald-200/50 space-y-4">
                  <div className="flex items-center gap-2">
                    <HelpCircle className="w-4 h-4 text-emerald-600" />
                    <p className="text-sm font-medium text-emerald-800">
                      {officialSaysRestored 
                        ? "Officials report service restored. Has it been restored for you?"
                        : "Has service been restored for you?"
                      }
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleRestorationResponse("restored")}
                      className="border-emerald-300 text-emerald-700 hover:bg-emerald-100 flex-1 transition-all duration-200 active:scale-95"
                    >
                      Yes, Restored
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleRestorationResponse("still-affected")}
                      className="border-emerald-300 text-emerald-700 hover:bg-emerald-100 flex-1 transition-all duration-200 active:scale-95"
                    >
                      No, Still affected
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleRestorationResponse("not-sure")}
                      className="border-emerald-300 text-emerald-700 hover:bg-emerald-100 flex-1 transition-all duration-200 active:scale-95"
                    >
                      Not sure
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {restorationResponse && (
              <div className="animate-fade-up p-4 rounded-xl bg-emerald-50/50 border border-emerald-200/30">
                <p className="text-sm text-emerald-700 text-center">
                  {restorationResponse === "restored" 
                    ? "Thanks! Your feedback helps confirm restoration."
                    : restorationResponse === "still-affected"
                    ? "Noted. We'll keep monitoring this signal."
                    : "Thanks for your feedback."}
                </p>
              </div>
            )}
          </section>
        )}
      </main>

      {/* Official Update Detail Modal */}
      <OfficialUpdateDetail
        isOpen={selectedOfficialUpdate !== null}
        onClose={() => setSelectedOfficialUpdate(null)}
        update={selectedOfficialUpdate}
      />
    </div>
  )
}
