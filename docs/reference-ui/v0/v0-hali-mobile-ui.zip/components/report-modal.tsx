"use client"

import { useState, useEffect, useMemo, useRef } from "react"
import { X, Zap, AlertTriangle, Droplets, Users, Clock, TrendingUp, ChevronLeft, Check, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { type Issue } from "@/components/issue-card"
import { cn } from "@/lib/utils"

interface ReportModalProps {
  isOpen: boolean
  onClose: () => void
  onJoinSignal?: (issue: Issue) => void
  onCreateSignal?: (params: {
    title: string
    condition: string
    type: "power" | "road" | "flooding"
    location: string
  }) => void
  existingSignals?: Issue[]
  currentLocality?: string
}

// NLP interpretation result
interface Interpretation {
  category: "electricity" | "road" | "flooding" | "water" | "environment" | "accidents" | null
  condition: string | null
  location: string | null
}

// Category keyword mappings - order matters for priority
const categoryPatterns: Array<{ 
  category: Interpretation["category"]
  keywords: string[]
  conditions: { pattern: RegExp | string; label: string }[]
}> = [
  {
    category: "electricity",
    keywords: ["electricity", "power", "blackout", "no power", "lights off", "transformer", "outage"],
    conditions: [
      { pattern: /no (power|electricity)/i, label: "No power" },
      { pattern: "blackout", label: "Blackout" },
      { pattern: "lights off", label: "No power" },
      { pattern: "transformer", label: "Transformer issue" },
    ],
  },
  {
    category: "water",
    keywords: ["no water", "water supply", "burst pipe", "leakage", "sewer overflow", "water disruption"],
    conditions: [
      { pattern: /no water/i, label: "No water" },
      { pattern: "burst pipe", label: "Burst pipe" },
      { pattern: "leakage", label: "Water leakage" },
      { pattern: "sewer", label: "Sewer issue" },
    ],
  },
  {
    category: "flooding",
    keywords: ["flood", "flooding", "floodwater", "water on the road", "impassable due to water"],
    conditions: [
      { pattern: "impassable", label: "Impassable" },
      { pattern: /flood/i, label: "Flooding" },
      { pattern: "water on the road", label: "Flooding" },
    ],
  },
  {
    category: "accidents",
    keywords: ["accident", "crash", "collision", "hit", "overturn", "overturned"],
    conditions: [
      { pattern: /accident/i, label: "Road accident" },
      { pattern: /crash/i, label: "Vehicle crash" },
      { pattern: /collision/i, label: "Collision" },
      { pattern: /overturn/i, label: "Vehicle overturned" },
    ],
  },
  {
    category: "road",
    keywords: ["pothole", "potholes", "road closure", "blocked road", "traffic blockage", "lane blocked", "matatu", "matatus blocking", "traffic"],
    conditions: [
      { pattern: /pothole/i, label: "Potholes" },
      { pattern: "road closure", label: "Road closed" },
      { pattern: /blocked|blockage/i, label: "Road blocked" },
      { pattern: "impassable", label: "Impassable" },
      { pattern: "difficult", label: "Difficult to pass" },
      { pattern: /matatu/i, label: "Traffic obstruction" },
      { pattern: /traffic/i, label: "Traffic issue" },
    ],
  },
  {
    category: "environment",
    keywords: ["garbage", "trash", "waste piling", "illegal dumping", "dirty drainage", "dumping", "rubbish"],
    conditions: [
      { pattern: /garbage|trash|rubbish/i, label: "Garbage piling up" },
      { pattern: /dumping/i, label: "Illegal dumping" },
      { pattern: /waste/i, label: "Waste piling up" },
      { pattern: /dirty drainage/i, label: "Dirty drainage" },
    ],
  },
]

// Known location landmarks
const knownLocations = [
  "south b", "nairobi west", "capital centre", "plainsview", "lusaka rd", 
  "uhuru hwy", "nyayo", "stadium", "roundabout", "industrial area", "kilimani", 
  "westlands", "upper hill", "community centre", "mombasa road", "langata",
  "kibera", "lavington", "parklands", "ngong road", "ring road"
]

// Location preposition patterns to strip
const locationPrepositions = ["near", "at", "around", "in", "along", "on"]

// Words that should never be part of extracted location
const nonLocationWords = [
  "flooding", "flood", "power", "electricity", "pothole", "potholes", "garbage", 
  "trash", "water", "there", "there's", "the", "a", "an", "is", "are", "has", "been",
  "no", "outage", "blackout", "blocked", "closure", "disruption"
]

// Default empty signals array (signals are now passed in from unified state)
const defaultSignals: Issue[] = []

const typeIcons = {
  power: Zap,
  road: AlertTriangle,
  flooding: Droplets,
}

const typeColors = {
  power: "bg-amber-100 text-amber-600",
  road: "bg-orange-100 text-orange-600",
  flooding: "bg-blue-100 text-blue-600",
}

// Simulate NLP interpretation based on user text
function interpretText(text: string): Interpretation {
  const lower = text.toLowerCase()
  
  let category: Interpretation["category"] = null
  let condition: string | null = null
  let location: string | null = null
  
  // 1. DETECT CATEGORY using keyword patterns
  for (const catPattern of categoryPatterns) {
    const hasKeyword = catPattern.keywords.some(kw => lower.includes(kw))
    if (hasKeyword) {
      category = catPattern.category
      
      // Find matching condition
      for (const condRule of catPattern.conditions) {
        const matches = typeof condRule.pattern === "string" 
          ? lower.includes(condRule.pattern)
          : condRule.pattern.test(lower)
        if (matches) {
          condition = condRule.label
          break
        }
      }
      
      // Default condition if none matched
      if (!condition) {
        condition = catPattern.conditions[0]?.label || capitalizeFirst(catPattern.category || "")
      }
      break
    }
  }
  
  // 2. EXTRACT LOCATION - find known landmarks first
  const foundLocations: string[] = []
  
  for (const loc of knownLocations) {
    if (lower.includes(loc)) {
      foundLocations.push(loc)
    }
  }
  
  if (foundLocations.length > 0) {
    // Sort by specificity (longer names first)
    foundLocations.sort((a, b) => b.length - a.length)
    
    if (foundLocations.length === 1) {
      location = capitalizeLocation(foundLocations[0])
    } else if (foundLocations.length === 2) {
      // Check if they're describing an intersection/junction
      const loc1 = capitalizeLocation(foundLocations[0])
      const loc2 = capitalizeLocation(foundLocations[1])
      
      // If both are roads/highways, format as junction
      if ((loc1.toLowerCase().includes("rd") || loc1.toLowerCase().includes("hwy") || loc1.toLowerCase().includes("road")) &&
          (loc2.toLowerCase().includes("rd") || loc2.toLowerCase().includes("hwy") || loc2.toLowerCase().includes("road"))) {
        location = `${loc1} / ${loc2} junction`
      } else {
        // One is a general area, one is more specific
        location = `${loc2} near ${loc1}`
      }
    } else {
      // Take the most specific (longest) location
      location = capitalizeLocation(foundLocations[0])
    }
  } else {
    // Fallback: try to extract location after prepositions
    location = extractLocationAfterPreposition(text)
  }
  
  return { category, condition, location }
}

// Capitalize a location string properly
function capitalizeLocation(loc: string): string {
  return loc
    .split(" ")
    .map(word => {
      // Keep abbreviations uppercase
      if (word === "rd" || word === "hwy") return word.charAt(0).toUpperCase() + word.slice(1)
      return word.charAt(0).toUpperCase() + word.slice(1)
    })
    .join(" ")
}

// Capitalize first letter
function capitalizeFirst(str: string): string {
  return str.charAt(0).toUpperCase() + str.slice(1)
}

// Get display label for category
function getCategoryLabel(category: Interpretation["category"]): string {
  switch (category) {
    case "electricity": return "Electricity"
    case "road": return "Roads / Traffic"
    case "flooding": return "Flooding"
    case "water": return "Water"
    case "environment": return "Environment"
    case "accidents": return "Accidents"
    default: return category || "General issue"
  }
}

// Extract location after prepositions like "at", "near", "in"
function extractLocationAfterPreposition(text: string): string | null {
  const lower = text.toLowerCase()
  
  for (const prep of locationPrepositions) {
    const pattern = new RegExp(`\\b${prep}\\s+([\\w\\s]+)`, "i")
    const match = lower.match(pattern)
    
    if (match && match[1]) {
      let extracted = match[1].trim()
      
      // Clean up: remove non-location words from start
      const words = extracted.split(/\s+/)
      const cleanWords: string[] = []
      
      for (const word of words) {
        const cleanWord = word.replace(/[^a-z]/gi, "").toLowerCase()
        
        // Skip non-location words
        if (nonLocationWords.includes(cleanWord)) continue
        
        // Stop at common sentence endings
        if (cleanWord === "and" || cleanWord === "but" || cleanWord === "or") break
        
        // Skip very short words that aren't likely part of location
        if (cleanWord.length < 2) continue
        
        cleanWords.push(word)
        
        // Stop after collecting enough words (max 5 for a location)
        if (cleanWords.length >= 5) break
      }
      
      if (cleanWords.length > 0) {
        const result = cleanWords.join(" ")
        // Clean up any trailing punctuation
        const cleaned = result.replace(/[.,;:!?]+$/, "").trim()
        
        if (cleaned.length >= 3) {
          return capitalizeLocation(cleaned)
        }
      }
    }
  }
  
  return null
}

// Find matching signal based on interpretation and text
function findMatchingSignal(text: string, interpretation: Interpretation, signals: Issue[]): Issue | null {
  const lower = text.toLowerCase()
  
  // Strong keyword matching
  for (const signal of signals) {
    const signalLower = signal.title.toLowerCase()
    
    // Check for category match
    let categoryMatch = false
    if (interpretation.category === "electricity" && signal.type === "power") categoryMatch = true
    if (interpretation.category === "road" && signal.type === "road") categoryMatch = true
    if (interpretation.category === "flooding" && signal.type === "flooding") categoryMatch = true
    
    if (!categoryMatch) continue
    
    // Check for location overlap
    const locationKeywords = ["south b", "plainsview", "lusaka", "uhuru", "nyayo", "capital"]
    let locationMatch = false
    for (const kw of locationKeywords) {
      if (lower.includes(kw) && signalLower.includes(kw)) {
        locationMatch = true
        break
      }
    }
    
    if (locationMatch) return signal
    
    // Fallback: if category matches and location isn't specified, suggest the signal
    if (categoryMatch && !interpretation.location) return signal
  }
  
  return null
}

type ModalStep = "input" | "confirm-new" | "joining" | "observing-confirm" | "add-context" | "created"

// Quick context suggestions
const contextChips = [
  "Started recently",
  "Ongoing for hours",
  "Happens often",
  "Worse at night",
  "Improving",
]

export function ReportModal({ isOpen, onClose, onJoinSignal, onCreateSignal, existingSignals = defaultSignals, currentLocality = "nairobi-west" }: ReportModalProps) {
  const [description, setDescription] = useState("")
  const [step, setStep] = useState<ModalStep>("input")
  const [interpretation, setInterpretation] = useState<Interpretation | null>(null)
  const [matchedSignal, setMatchedSignal] = useState<Issue | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [furtherContext, setFurtherContext] = useState("")
  const [joinedSignalForContext, setJoinedSignalForContext] = useState<Issue | null>(null)

  // Reset state when modal opens/closes
  useEffect(() => {
    if (!isOpen) {
      const timer = setTimeout(() => {
        setDescription("")
        setStep("input")
        setInterpretation(null)
        setMatchedSignal(null)
        setIsAnalyzing(false)
        setFurtherContext("")
        setJoinedSignalForContext(null)
      }, 200)
      return () => clearTimeout(timer)
    }
  }, [isOpen])

  // Stable NLP state machine - prevents ALL flicker by:
  // 1. Never showing "Understanding..." while user is typing
  // 2. Only transitioning after full debounce period
  // 3. Keeping previous results visible until new ones are ready
  // 4. Requiring meaningful text before any processing
  
  const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const analyzeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const lastProcessedText = useRef<string>("")
  
  // Check if text has enough meaningful content for NLP
  const hasEnoughContent = (text: string): boolean => {
    if (text.length < 15) return false
    
    // Check if text ends with incomplete location preposition
    const trimmed = text.trim().toLowerCase()
    const incompletePatterns = [
      /\bat$/,      // ends with "at"
      /\bin$/,      // ends with "in"
      /\bnear$/,    // ends with "near"
      /\balong$/,   // ends with "along"
      /\bon$/,      // ends with "on"
      /\baround$/,  // ends with "around"
    ]
    
    for (const pattern of incompletePatterns) {
      if (pattern.test(trimmed)) return false
    }
    
    return true
  }
  
  useEffect(() => {
    // Don't process if not in input step
    if (step !== "input") {
      return
    }
    
    // Clear timers on every keystroke
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current)
      debounceTimerRef.current = null
    }
    if (analyzeTimerRef.current) {
      clearTimeout(analyzeTimerRef.current)
      analyzeTimerRef.current = null
    }
    
    // If text is too short, clear results and stop
    if (description.length <= 15) {
      setInterpretation(null)
      setMatchedSignal(null)
      setIsAnalyzing(false)
      lastProcessedText.current = ""
      return
    }
    
    // If text hasn't changed meaningfully, don't reprocess
    if (description === lastProcessedText.current) {
      return
    }
    
    // DON'T show analyzing state while typing - only after debounce
    // This is the key fix: we keep whatever state we had before
    
    // After 800ms of no typing AND if text is complete enough, process
    debounceTimerRef.current = setTimeout(() => {
      // Double-check we have meaningful content before showing "Understanding..."
      if (!hasEnoughContent(description)) {
        return
      }
      
      // Now show analyzing state
      setIsAnalyzing(true)
      
      // Process after brief "Understanding..." display (350ms)
      analyzeTimerRef.current = setTimeout(() => {
        const interp = interpretText(description)
        
        // Batch all state updates together to prevent flicker
        setInterpretation(interp)
        setMatchedSignal(interp.category 
          ? findMatchingSignal(description, interp, existingSignals) 
          : null
        )
        setIsAnalyzing(false)
        lastProcessedText.current = description
      }, 350)
    }, 800) // Longer debounce for stability
    
    return () => {
      if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current)
      if (analyzeTimerRef.current) clearTimeout(analyzeTimerRef.current)
    }
  }, [description, existingSignals, step])

  const handleAffected = () => {
    if (!matchedSignal) return
    setStep("joining")
    
    const updatedSignal = {
      ...matchedSignal,
      affectedCount: matchedSignal.affectedCount + 1,
    }
    
    // Store the signal for the context step
    setJoinedSignalForContext(updatedSignal)
    
    // Show confirmation briefly, then transition to context step
    setTimeout(() => {
      setStep("add-context")
    }, 1000)
  }

  const handleObserving = () => {
    if (!matchedSignal) return
    setStep("observing-confirm")
    
    // Lower weight - don't increase affected count, but still register participation
    const updatedSignal = {
      ...matchedSignal,
      // Could track observing count separately in a real app
    }
    
    // Show confirmation briefly, then navigate directly to signal
    setTimeout(() => {
      onJoinSignal?.(matchedSignal)
    }, 1000)
  }

  const handleSubmitContext = () => {
    // In a real app, this would save the context to the backend
    // Structure: { signalId, context, timestamp, contextType }
    if (joinedSignalForContext) {
      onJoinSignal?.(joinedSignalForContext)
    }
  }

  const handleSkipContext = () => {
    if (joinedSignalForContext) {
      onJoinSignal?.(joinedSignalForContext)
    }
  }

  const handleChipSelect = (chip: string) => {
    setFurtherContext(chip)
  }

  const handleCreateNew = () => {
    setStep("confirm-new")
  }

  const handleConfirmCreate = () => {
    if (!interpretation) return
    
    // Build the signal title
    const title = description.length > 80 
      ? description.slice(0, 77) + "..."
      : description
    
    // Map category to type
    const typeMap: Record<string, "power" | "road" | "flooding"> = {
      electricity: "power",
      road: "road",
      flooding: "flooding",
      water: "power", // using power for water as fallback
      environment: "road", // using road for environment as fallback
      accidents: "road", // accidents map to road type
    }
    
    const type = typeMap[interpretation.category || "road"] || "road"
    
    setStep("created")
    
    // Actually create the signal after brief confirmation
    setTimeout(() => {
      onCreateSignal?.({
        title,
        condition: interpretation.condition || "Reported",
        type,
        location: interpretation.location || currentLocality,
      })
    }, 1200)
  }

  const handleBackToInput = () => {
    setStep("input")
  }

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose()
    }
  }

  // Determine what category icon to show
  const categoryIcon = useMemo(() => {
    if (!interpretation?.category) return null
    switch (interpretation.category) {
      case "electricity": return { Icon: Zap, color: "text-amber-600", bg: "bg-amber-100" }
      case "road": return { Icon: AlertTriangle, color: "text-orange-600", bg: "bg-orange-100" }
      case "flooding": return { Icon: Droplets, color: "text-blue-600", bg: "bg-blue-100" }
      case "water": return { Icon: Droplets, color: "text-cyan-600", bg: "bg-cyan-100" }
      case "environment": return { Icon: Trash2, color: "text-green-600", bg: "bg-green-100" }
      case "accidents": return { Icon: AlertTriangle, color: "text-red-600", bg: "bg-red-100" }
      default: return null
    }
  }, [interpretation])

  if (!isOpen) return null

  const MatchedIcon = matchedSignal ? typeIcons[matchedSignal.type] : null
  const matchedColor = matchedSignal ? typeColors[matchedSignal.type] : ""

  return (
    <div 
      className="fixed inset-0 z-50 flex items-end justify-center animate-modal-backdrop"
      onClick={handleBackdropClick}
    >
      {/* Backdrop - pointer-events-none so clicks pass through to parent */}
      <div className="absolute inset-0 bg-foreground/20 backdrop-blur-sm pointer-events-none" />
      
      {/* Modal Content - stops propagation naturally */}
      <div 
        className="relative w-full max-w-md mx-4 mb-4 bg-card rounded-2xl shadow-xl animate-modal-content overflow-hidden max-h-[85vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border/50 flex-shrink-0">
          {step === "confirm-new" ? (
            <button
              onClick={handleBackToInput}
              className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-muted transition-colors active:scale-90"
            >
              <ChevronLeft className="w-5 h-5 text-muted-foreground" />
            </button>
          ) : (
            <h2 className="text-lg font-semibold text-foreground">
              {step === "input" ? "What's happening?" : 
               step === "joining" ? "" : 
               step === "add-context" ? "" : 
               ""}
            </h2>
          )}
          {step === "confirm-new" && (
            <h2 className="text-lg font-semibold text-foreground flex-1 text-center mr-8">
              Confirm signal
            </h2>
          )}
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-muted transition-colors active:scale-90"
          >
            <X className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>
        
        {/* Body - scrollable */}
        <div className="p-4 space-y-4 overflow-y-auto flex-1">
          {/* Step: Input */}
          {step === "input" && (
            <>
              {/* Primary Text Input */}
              <div className="space-y-2">
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value.slice(0, 150))}
                  placeholder="Describe what's happening... (keep it short and clear)"
                  maxLength={150}
                  className={cn(
                    "w-full h-28 p-4 text-base rounded-xl resize-none",
                    "bg-muted/50 border border-border/50",
                    "placeholder:text-muted-foreground/50",
                    "focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/50",
                    "transition-all duration-200"
                  )}
                  autoFocus
                />
                
                {/* Helper text and character counter */}
                <div className="flex items-center justify-between px-1">
                  <p className="text-xs text-muted-foreground/60">
                    {description.length === 0 
                      ? "Describe what's happening..." 
                      : "Be specific: what's happening and where?"}
                  </p>
                  <span className="text-xs text-muted-foreground/50">
                    {description.length} / 150
                  </span>
                </div>
              </div>
              
              {/* Analyzing indicator - shown in a stable container */}
              {isAnalyzing && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground py-1">
                  <div className="w-3 h-3 rounded-full border-2 border-primary border-t-transparent animate-spin" />
                  <span>Understanding...</span>
                </div>
              )}
              
              {/* NLP Interpretation Display - no animation to prevent flicker */}
              {interpretation && (interpretation.category || interpretation.location) && !isAnalyzing && (
                <div className="space-y-2 pt-1 transition-opacity duration-200">
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs">
                    {interpretation.category && (
                      <span className="flex items-center gap-1.5">
                        <span className="text-muted-foreground/70">Suggested category:</span>
                        <span className="text-primary font-medium capitalize">
                          {getCategoryLabel(interpretation.category)}
                        </span>
                      </span>
                    )}
                    {interpretation.condition && (
                      <span className="flex items-center gap-1.5">
                        <span className="text-muted-foreground/50">·</span>
                        <span className="text-muted-foreground/70">Condition:</span>
                        <span className="text-primary font-medium">{interpretation.condition}</span>
                      </span>
                    )}
                  </div>
                  {interpretation.location && (
                    <div className="flex items-center gap-1.5 text-xs">
                      <span className="text-muted-foreground/70">Location:</span>
                      <span className="text-foreground font-medium">{interpretation.location}</span>
                    </div>
                  )}
                </div>
              )}
              
              {/* Match Suggestion Block - smooth transition instead of animation */}
              {matchedSignal && !isAnalyzing && MatchedIcon && (
                <div className="space-y-3 pt-2 transition-opacity duration-200">
                  <p className="text-xs text-muted-foreground font-medium">
                    This looks similar to
                  </p>
                  
                  {/* Compact Signal Preview */}
                  <Card className="p-3 border-primary/20 bg-primary/[0.03]">
                    <div className="flex items-start gap-3">
                      <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0", matchedColor)}>
                        <MatchedIcon className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-medium text-foreground leading-snug">
                          {matchedSignal.title}
                        </h4>
                        <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                          <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
                            {matchedSignal.condition}
                          </span>
                          <span className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Users className="w-3 h-3" />
                            {matchedSignal.affectedCount} affected
                          </span>
                          <span className="text-xs text-muted-foreground/70">
                            · {matchedSignal.duration}
                          </span>
                        </div>
                        <p className="text-[10px] text-muted-foreground/60 mt-1.5">
                          Based on nearby reports
                        </p>
                      </div>
                    </div>
                  </Card>
                  
                  {/* Participation Actions */}
                  <div className="space-y-2 pt-1">
                    <div className="flex gap-2">
                      <Button 
                        onClick={handleAffected}
                        className="flex-1 h-11 text-sm font-medium transition-all duration-200 active:scale-[0.98]"
                      >
                        {"I'm affected"}
                      </Button>
                      <Button 
                        onClick={handleObserving}
                        variant="outline"
                        className="flex-1 h-11 text-sm font-medium transition-all duration-200 active:scale-[0.98]"
                      >
                        {"I'm observing"}
                      </Button>
                    </div>
                    <Button 
                      onClick={handleCreateNew}
                      variant="ghost"
                      className="w-full h-9 text-xs text-muted-foreground hover:text-foreground transition-all duration-200 active:scale-[0.98]"
                    >
                      Create new signal instead
                    </Button>
                    {/* Microcopy hint */}
                    <p className="text-[10px] text-muted-foreground/60 text-center pt-1">
                      Affected = this is directly impacting you · Observing = you can see it happening
                    </p>
                  </div>
                </div>
              )}
              
              {/* No Match State - smooth transition */}
              {interpretation?.category && !matchedSignal && !isAnalyzing && (
                <div className="space-y-3 pt-2 transition-opacity duration-200">
                  <p className="text-xs text-muted-foreground">
                    No similar active signal found
                  </p>
                  <Button 
                    onClick={handleCreateNew}
                    className="w-full h-11 text-sm font-medium transition-all duration-200 active:scale-[0.98]"
                  >
                    Create new signal
                  </Button>
                </div>
              )}
            </>
          )}
          
          {/* Step: Confirm New Signal */}
          {step === "confirm-new" && interpretation && (
            <div className="animate-fade-up space-y-4">
              <p className="text-sm text-muted-foreground">
                Review the signal before creating:
              </p>
              
              {/* Structured Preview */}
              <Card className="p-4 space-y-3">
                {categoryIcon && (
                  <div className="flex items-center gap-3">
                    <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center", categoryIcon.bg)}>
                      <categoryIcon.Icon className={cn("w-5 h-5", categoryIcon.color)} />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground/70 uppercase tracking-wider">Category</p>
                      <p className="text-sm font-medium text-foreground">
                        {getCategoryLabel(interpretation.category)}
                      </p>
                    </div>
                  </div>
                )}
                
                {interpretation.condition && (
                  <div className="flex items-center justify-between py-2 border-t border-border/50">
                    <span className="text-xs text-muted-foreground">Condition</span>
                    <span className="text-sm font-medium text-foreground">{interpretation.condition}</span>
                  </div>
                )}
                
                {interpretation.location && (
                  <div className="flex items-center justify-between py-2 border-t border-border/50">
                    <span className="text-xs text-muted-foreground">Location</span>
                    <span className="text-sm font-medium text-foreground">{interpretation.location}</span>
                  </div>
                )}
                
                <div className="pt-2 border-t border-border/50">
                  <p className="text-xs text-muted-foreground/70 mb-1">Your description</p>
                  <p className="text-sm text-foreground leading-relaxed">{description}</p>
                </div>
              </Card>
              
              {/* Actions */}
              <div className="flex gap-2 pt-2">
                <Button 
                  onClick={handleConfirmCreate}
                  className="flex-1 h-11 text-sm font-medium transition-all duration-200 active:scale-[0.98]"
                >
                  Confirm signal
                </Button>
                <Button 
                  onClick={handleBackToInput}
                  variant="outline"
                  className="flex-1 h-11 text-sm font-medium transition-all duration-200 active:scale-[0.98]"
                >
                  Back
                </Button>
              </div>
            </div>
          )}
          
          {/* Step: Joining Signal (Affected) */}
          {step === "joining" && (
            <div className="animate-fade-up py-8 text-center">
              <div className="flex items-center justify-center gap-2 text-primary">
                <TrendingUp className="w-5 h-5" />
                <p className="text-base font-medium">{"You've added your voice"}</p>
              </div>
            </div>
          )}

          {/* Step: Observing Confirmation */}
          {step === "observing-confirm" && (
            <div className="animate-fade-up py-8 text-center">
              <div className="flex items-center justify-center gap-2 text-primary">
                <Check className="w-5 h-5" />
                <p className="text-base font-medium">Thanks for the update</p>
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Taking you there now...
              </p>
            </div>
          )}

          {/* Step: Add Further Context (optional) */}
          {step === "add-context" && (
            <div className="animate-fade-up space-y-4">
              {/* Title and subtitle */}
              <div className="text-center pb-2">
                <h3 className="text-base font-medium text-foreground">
                  Add more detail
                  <span className="text-muted-foreground font-normal ml-1">(optional)</span>
                </h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Help others understand this better
                </p>
              </div>

              {/* Text input */}
              <textarea
                value={furtherContext}
                onChange={(e) => setFurtherContext(e.target.value.slice(0, 150))}
                placeholder="Add a bit more detail... (optional, 150 characters max)"
                className={cn(
                  "w-full h-20 p-3 text-sm rounded-xl resize-none",
                  "bg-muted/50 border border-border/50",
                  "placeholder:text-muted-foreground/50",
                  "focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/50",
                  "transition-all duration-200"
                )}
                autoFocus
              />
              
              {/* Character count */}
              <div className="flex justify-end">
                <span className={cn(
                  "text-xs",
                  furtherContext.length > 140 ? "text-amber-500" : "text-muted-foreground/50"
                )}>
                  {furtherContext.length}/150
                </span>
              </div>

              {/* Quick context chips */}
              <div className="space-y-2">
                <p className="text-xs text-muted-foreground/70">Quick suggestions</p>
                <div className="flex flex-wrap gap-2">
                  {contextChips.map((chip) => (
                    <button
                      key={chip}
                      onClick={() => handleChipSelect(chip)}
                      className={cn(
                        "px-3 py-1.5 text-xs rounded-full border transition-all duration-200",
                        "hover:border-primary/50 hover:bg-primary/5",
                        "active:scale-95",
                        furtherContext === chip 
                          ? "border-primary bg-primary/10 text-primary font-medium" 
                          : "border-border/50 text-muted-foreground"
                      )}
                    >
                      {chip}
                    </button>
                  ))}
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex gap-2 pt-3">
                <Button 
                  onClick={handleSubmitContext}
                  className="flex-1 h-11 text-sm font-medium transition-all duration-200 active:scale-[0.98]"
                >
                  {furtherContext.trim() ? "Submit context" : "Continue"}
                </Button>
                <Button 
                  onClick={handleSkipContext}
                  variant="outline"
                  className="flex-1 h-11 text-sm font-medium transition-all duration-200 active:scale-[0.98]"
                >
                  Skip
                </Button>
              </div>
            </div>
          )}
          
          {/* Step: Created */}
          {step === "created" && (
            <div className="animate-fade-up py-8 text-center">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
                <Check className="w-6 h-6 text-primary" />
              </div>
              <p className="text-base font-medium text-foreground">Signal created</p>
              <p className="text-sm text-muted-foreground mt-1">
                Others nearby will see this
              </p>
            </div>
          )}
        </div>
        
        {/* Footer - Only show Report button when no suggestion and no match */}
        {step === "input" && !matchedSignal && !interpretation?.category && !isAnalyzing && (
          <div className="p-4 pt-0 flex-shrink-0">
            <Button 
              onClick={handleCreateNew}
              className="w-full h-12 text-base font-medium transition-all duration-200 active:scale-[0.98]"
              disabled={description.trim().length < 10}
            >
              Report
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
