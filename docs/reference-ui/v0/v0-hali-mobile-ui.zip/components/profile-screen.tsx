"use client"

import { useState, useMemo } from "react"
import { User, MapPin, Settings, ChevronRight, LogIn, LogOut, Check, RotateCcw } from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

// Full areas data for display (base names only)
const allAreasData: Record<string, { name: string }> = {
  "nairobi-west": { name: "Nairobi West" },
  "south-b": { name: "South B" },
  "industrial-area": { name: "Industrial Area" },
  "upper-hill": { name: "Upper Hill" },
  "kilimani": { name: "Kilimani" },
  "westlands": { name: "Westlands" },
}

interface ProfileScreenProps {
  onNavigateToArea?: (areaId: string) => void
  isSignedIn?: boolean
  profileName?: string
  onSignIn?: () => void
  onSignOut?: () => void
  followedAreas?: string[]
  onRemoveArea?: (areaId: string) => void
  getSignalCountForLocality?: (localityId: string) => number
  getLastCheckedText?: (areaId: string) => string
  onResetDemo?: () => void
}

export function ProfileScreen({ 
  onNavigateToArea, 
  isSignedIn = false,
  profileName = "You",
  onSignIn,
  onSignOut,
  followedAreas = ["nairobi-west", "south-b", "industrial-area"],
  onRemoveArea,
  getSignalCountForLocality = () => 0,
  getLastCheckedText = () => "Not checked yet",
  onResetDemo
}: ProfileScreenProps) {
  const [areaToUnfollow, setAreaToUnfollow] = useState<string | null>(null)
  const [unfollowFeedback, setUnfollowFeedback] = useState<string | null>(null)
  const [showResetConfirm, setShowResetConfirm] = useState(false)
  const [resetFeedback, setResetFeedback] = useState(false)

  const handleUnfollowArea = (areaId: string, areaName: string) => {
    onRemoveArea?.(areaId)
    setAreaToUnfollow(null)
    setUnfollowFeedback(`You've unfollowed ${areaName}`)
    setTimeout(() => setUnfollowFeedback(null), 2500)
  }

  const handleResetDemo = () => {
    onResetDemo?.()
    setShowResetConfirm(false)
    setResetFeedback(true)
    setTimeout(() => setResetFeedback(false), 2500)
  }

  // Map followed area IDs to their display data with dynamic counts
  const displayAreas = useMemo(() => {
    return followedAreas
      .map(id => {
        const base = allAreasData[id]
        if (!base) return null
        const signalCount = getSignalCountForLocality(id)
        return {
          id,
          name: base.name,
          signalCount,
          lastChecked: getLastCheckedText(id),
        }
      })
      .filter(Boolean) as Array<{ id: string; name: string; signalCount: number; lastChecked: string }>
  }, [followedAreas, getSignalCountForLocality, getLastCheckedText])

  return (
    <div className="min-h-screen bg-background pb-24 animate-in fade-in duration-300">
      <header className="sticky top-0 z-10 bg-background/95 backdrop-blur-sm border-b border-border/50">
        <div className="p-4 pb-3">
          <h1 className="text-2xl font-semibold text-foreground tracking-tight">Profile</h1>
        </div>
      </header>

      <main className="p-4 space-y-6">
        {/* User Info */}
        <Card className="p-5 border-border/50 shadow-sm animate-in fade-in slide-in-from-bottom-2 duration-300">
          <div className="flex items-center gap-4">
            <div className={cn(
              "w-14 h-14 rounded-full flex items-center justify-center",
              isSignedIn ? "bg-primary/10" : "bg-muted"
            )}>
              <User className={cn(
                "w-7 h-7",
                isSignedIn ? "text-primary" : "text-muted-foreground"
              )} />
            </div>
            <div className="flex-1">
              <h2 className="text-lg font-semibold text-foreground">
                {profileName}
              </h2>
              <p className="text-sm text-muted-foreground">
                {isSignedIn ? "Anonymous participation enabled" : "Not signed in"}
              </p>
            </div>
          </div>
          
          {/* Sign In Button for non-authenticated users */}
          {!isSignedIn && (
            <Button
              onClick={onSignIn}
              variant="outline"
              className="w-full mt-4 h-11 gap-2 transition-all duration-200 active:scale-[0.98]"
            >
              <LogIn className="w-4 h-4" />
              Sign in / Create account
            </Button>
          )}
          
          {/* Sign Out Button for authenticated users */}
          {isSignedIn && (
            <Button
              onClick={onSignOut}
              variant="ghost"
              className="w-full mt-4 h-11 gap-2 text-muted-foreground hover:text-foreground transition-all duration-200 active:scale-[0.98]"
            >
              <LogOut className="w-4 h-4" />
              Sign out
            </Button>
          )}
        </Card>

        {/* Followed Areas */}
        <section 
          className="animate-in fade-in slide-in-from-bottom-2 duration-300"
          style={{ animationDelay: "75ms", animationFillMode: "both" }}
        >
          <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-3">
            Followed Areas
          </h3>
          <p className="text-xs text-muted-foreground/70 mb-2">
            Tap to view signals
          </p>
          <Card className="divide-y divide-border/50 border-border/50 shadow-sm overflow-hidden">
            {displayAreas.map((area) => {
              const isBeingUnfollowed = areaToUnfollow === area.id
              return (
                <div key={area.id} className="p-4">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => onNavigateToArea?.(area.id)}
                      className="flex-1 flex items-start gap-3 text-left hover:opacity-80 transition-opacity"
                    >
                      <MapPin className="w-4 h-4 text-muted-foreground mt-0.5" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-foreground">{area.name}</span>
                          {area.signalCount > 0 && (
                            <span className="text-xs text-primary font-medium">
                              {area.signalCount} active
                            </span>
                          )}
                        </div>
                        <p className="text-[10px] text-muted-foreground/60 mt-0.5">
                          {area.lastChecked}
                        </p>
                      </div>
                    </button>
                    
                    {/* Following toggle */}
                    <button
                      onClick={() => setAreaToUnfollow(isBeingUnfollowed ? null : area.id)}
                      className={cn(
                        "px-2.5 py-1 rounded-full text-[10px] font-medium transition-all duration-200",
                        isBeingUnfollowed 
                          ? "bg-destructive/10 text-destructive"
                          : "bg-primary/10 text-primary hover:bg-primary/20"
                      )}
                    >
                      {isBeingUnfollowed ? "Unfollow?" : (
                        <span className="flex items-center gap-0.5">
                          <Check className="w-2.5 h-2.5" />
                          Following
                        </span>
                      )}
                    </button>
                  </div>
                  
                  {/* Unfollow confirmation */}
                  {isBeingUnfollowed && (
                    <div className="mt-3 pt-3 border-t border-border/50 flex gap-2 animate-in fade-in slide-in-from-top-2 duration-200">
                      <button
                        onClick={() => handleUnfollowArea(area.id, area.name)}
                        className="flex-1 py-1.5 text-xs font-medium text-destructive bg-destructive/10 rounded-lg hover:bg-destructive/20 transition-colors"
                      >
                        Yes, unfollow
                      </button>
                      <button
                        onClick={() => setAreaToUnfollow(null)}
                        className="flex-1 py-1.5 text-xs font-medium text-muted-foreground bg-muted rounded-lg hover:bg-muted/80 transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  )}
                </div>
              )
            })}
          </Card>
        </section>

        {/* Settings */}
        <section 
          className="animate-in fade-in slide-in-from-bottom-2 duration-300"
          style={{ animationDelay: "150ms", animationFillMode: "both" }}
        >
          <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-3">
            Settings
          </h3>
          <Card className="border-border/50 shadow-sm overflow-hidden divide-y divide-border/50">
            <button
              className={cn(
                "w-full flex items-center gap-3 p-4 text-left",
                "hover:bg-muted/50 transition-colors duration-200",
                "active:bg-muted"
              )}
            >
              <Settings className="w-4 h-4 text-muted-foreground" />
              <span className="flex-1 text-foreground">Preferences</span>
              <ChevronRight className="w-4 h-4 text-muted-foreground/50" />
            </button>
          </Card>
        </section>

        {/* Demo Controls */}
        <section 
          className="animate-in fade-in slide-in-from-bottom-2 duration-300"
          style={{ animationDelay: "200ms", animationFillMode: "both" }}
        >
          <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-3">
            Demo Controls
          </h3>
          <Card className="border-border/50 shadow-sm overflow-hidden">
            {!showResetConfirm ? (
              <button
                onClick={() => setShowResetConfirm(true)}
                className={cn(
                  "w-full flex items-center gap-3 p-4 text-left",
                  "hover:bg-muted/50 transition-colors duration-200",
                  "active:bg-muted"
                )}
              >
                <RotateCcw className="w-4 h-4 text-muted-foreground" />
                <div className="flex-1">
                  <span className="text-foreground">Reset demo data</span>
                  <p className="text-xs text-muted-foreground/60 mt-0.5">
                    Clear all signals and start fresh
                  </p>
                </div>
              </button>
            ) : (
              <div className="p-4 space-y-3 animate-in fade-in duration-200">
                <p className="text-sm text-foreground text-center">
                  Reset all demo data?
                </p>
                <p className="text-xs text-muted-foreground text-center">
                  This will clear all signals and return the app to its initial state.
                </p>
                <div className="flex gap-2">
                  <Button
                    onClick={handleResetDemo}
                    variant="destructive"
                    size="sm"
                    className="flex-1"
                  >
                    Yes, reset
                  </Button>
                  <Button
                    onClick={() => setShowResetConfirm(false)}
                    variant="outline"
                    size="sm"
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </Card>
          
          {resetFeedback && (
            <p className="text-sm text-center text-primary mt-3 animate-in fade-in duration-200">
              Demo data has been reset
            </p>
          )}
        </section>

        {/* Footer */}
        <div 
          className="text-center pt-4 animate-in fade-in duration-500"
          style={{ animationDelay: "250ms", animationFillMode: "both" }}
        >
          <p className="text-xs text-muted-foreground/60">
            Hali v1.0 — Civic awareness for your locality
          </p>
        </div>
      </main>
    </div>
  )
}
