"use client"

import { useState } from "react"
import { Search, Bell, ChevronDown, MapPin, AlertTriangle, TrendingUp, CheckCircle, MessageSquare, Zap, RefreshCw } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import { ScrollArea } from "@/components/ui/scroll-area"
import type { Institution, Notification } from "@/lib/types"
import { cn } from "@/lib/utils"

const institutions: Institution[] = [
  "Kenya Power",
  "Nairobi Water",
  "KenHA / KURA",
  "Nairobi County",
]

const areas = [
  "All Areas",
  "South B",
  "Nairobi West",
  "Industrial Area",
  "Upper Hill",
  "Kilimani",
  "Lavington",
]

interface TopbarProps {
  institution: Institution
  selectedArea: string
  onInstitutionChange: (institution: Institution) => void
  onAreaChange: (area: string) => void
  notifications: Notification[]
  onNotificationClick: (notification: Notification) => void
  onRefreshActivity: () => void
  isRefreshing?: boolean
}

export function Topbar({
  institution,
  selectedArea,
  onInstitutionChange,
  onAreaChange,
  notifications,
  onNotificationClick,
  onRefreshActivity,
  isRefreshing = false,
}: TopbarProps) {
  const [showRefreshFeedback, setShowRefreshFeedback] = useState(false)

  const handleRefresh = () => {
    onRefreshActivity()
    setShowRefreshFeedback(true)
    setTimeout(() => setShowRefreshFeedback(false), 2000)
  }
  // Get category description for the current institution
  const getCategoryDescription = () => {
    switch (institution) {
      case "Kenya Power":
        return "Power"
      case "Nairobi Water":
        return "Water"
      case "KenHA / KURA":
        return "Roads & Traffic"
      case "Nairobi County":
        return "Drainage & Waste"
      default:
        return ""
    }
  }

  const notificationCount = notifications.length

  const getNotificationIcon = (type: Notification["type"]) => {
    switch (type) {
      case "new_signal":
        return AlertTriangle
      case "growing":
        return TrendingUp
      case "needs_attention":
        return AlertTriangle
      case "restoration":
        return CheckCircle
      case "update_posted":
        return MessageSquare
      case "restored":
        return CheckCircle
      default:
        return Zap
    }
  }

  const getNotificationColor = (type: Notification["type"]) => {
    switch (type) {
      case "new_signal":
        return "text-blue-600 bg-blue-50"
      case "growing":
        return "text-amber-600 bg-amber-50"
      case "needs_attention":
        return "text-red-600 bg-red-50"
      case "restoration":
        return "text-emerald-600 bg-emerald-50"
      case "update_posted":
        return "text-primary bg-primary/10"
      case "restored":
        return "text-emerald-600 bg-emerald-50"
      default:
        return "text-slate-600 bg-slate-50"
    }
  }

  return (
    <header className="fixed left-56 right-0 top-0 z-30 flex h-16 items-center justify-between border-b border-border bg-background px-6">
      <div className="flex items-center gap-4">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="gap-2 text-base font-semibold">
              {institution}
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            {institutions.map((inst) => (
              <DropdownMenuItem
                key={inst}
                onClick={() => onInstitutionChange(inst)}
              >
                {inst}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        <div className="flex items-center gap-2 rounded-full bg-secondary px-3 py-1.5">
          <span className="text-xs text-muted-foreground">Scope:</span>
          <span className="text-xs font-medium">{getCategoryDescription()}</span>
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" className="gap-2">
              <MapPin className="h-3.5 w-3.5" />
              {selectedArea}
              <ChevronDown className="h-3.5 w-3.5" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            {areas.map((area) => (
              <DropdownMenuItem key={area} onClick={() => onAreaChange(area)}>
                {area}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="flex items-center gap-3">
        {/* Refresh feedback message */}
        {showRefreshFeedback && (
          <div className="flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1.5 text-xs font-medium text-primary animate-in fade-in slide-in-from-right-2 duration-200">
            <CheckCircle className="h-3.5 w-3.5" />
            Live activity refreshed
          </div>
        )}

        {/* Refresh button */}
        <Button
          variant="outline"
          size="sm"
          className="gap-2 text-muted-foreground hover:text-foreground"
          onClick={handleRefresh}
          disabled={isRefreshing}
        >
          <RefreshCw className={cn("h-3.5 w-3.5", isRefreshing && "animate-spin")} />
          <span className="hidden xl:inline">Refresh live activity</span>
        </Button>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search signals..."
            className="w-64 pl-9"
          />
        </div>

        <Popover>
          <PopoverTrigger asChild>
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-4 w-4" />
              {notificationCount > 0 && (
                <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-medium text-primary-foreground">
                  {notificationCount > 9 ? "9+" : notificationCount}
                </span>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent align="end" className="w-80 p-0">
            <div className="border-b border-border px-4 py-3">
              <h3 className="font-semibold">Notifications</h3>
              <p className="text-xs text-muted-foreground">
                Recent alerts for {institution}
              </p>
            </div>
            <ScrollArea className="h-80">
              {notifications.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <Bell className="mb-2 h-8 w-8 text-muted-foreground/50" />
                  <p className="text-sm text-muted-foreground">No new notifications</p>
                </div>
              ) : (
                <div className="flex flex-col">
                  {notifications.map((notification) => {
                    const Icon = getNotificationIcon(notification.type)
                    const colorClass = getNotificationColor(notification.type)
                    return (
                      <button
                        key={notification.id}
                        type="button"
                        className="flex w-full items-start gap-3 border-b border-border px-4 py-3 text-left transition-colors hover:bg-secondary/50"
                        onClick={() => onNotificationClick(notification)}
                      >
                        <div className={cn("mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full", colorClass)}>
                          <Icon className="h-3.5 w-3.5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm leading-snug">{notification.message}</p>
                          <p className="mt-1 text-xs text-muted-foreground">{notification.timestamp}</p>
                        </div>
                      </button>
                    )
                  })}
                </div>
              )}
            </ScrollArea>
          </PopoverContent>
        </Popover>
      </div>
    </header>
  )
}
