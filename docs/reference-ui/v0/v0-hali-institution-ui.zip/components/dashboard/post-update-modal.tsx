"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { ScrollArea } from "@/components/ui/scroll-area"
import type { Signal, ResponseStatus } from "@/lib/types"
import { cn } from "@/lib/utils"
import {
  X,
  Eye,
  Smartphone,
  Calendar,
  Radio,
  RotateCcw,
  CheckCircle,
  MessageSquare,
  Check,
} from "lucide-react"

interface PostUpdateModalProps {
  signal: Signal
  onClose: () => void
  onSubmit: (status: ResponseStatus, message: string, expectedResolution?: string) => void
}

interface ActionButton {
  label: string
  status: ResponseStatus
  icon: React.ElementType
  message: string
  variant?: "default" | "success"
}

export function PostUpdateModal({ signal, onClose, onSubmit }: PostUpdateModalProps) {
  const [customMessage, setCustomMessage] = useState("")
  const [expectedDate, setExpectedDate] = useState("")
  const [expectedTime, setExpectedTime] = useState("")
  const [showPreview, setShowPreview] = useState(false)
  const [completedAction, setCompletedAction] = useState<string | null>(null)

  // Generate action buttons based on current signal status
  const getActionButtons = (): ActionButton[] => {
    const buttons: ActionButton[] = []

    // Teams on Site - available unless already on site or beyond
    const onSiteOrBeyond = ["Teams on site", "Work ongoing", "Restoration in progress", "Service restored"]
    if (!onSiteOrBeyond.includes(signal.responseStatus)) {
      buttons.push({
        label: "Teams On Site",
        status: "Teams on site",
        icon: Radio,
        message: `Our team is now on site at ${signal.area} assessing the ${signal.category.toLowerCase()} situation.`,
      })
    }

    // Restoration in Progress - available unless already restoring or restored
    const restoringOrRestored = ["Restoration in progress", "Service restored"]
    if (!restoringOrRestored.includes(signal.responseStatus)) {
      buttons.push({
        label: "Restoration in Progress",
        status: "Restoration in progress",
        icon: RotateCcw,
        message: `${signal.category} restoration is underway in ${signal.area}. Service should be restored soon.`,
      })
    }

    // Service Restored - available unless already restored
    if (signal.responseStatus !== "Service restored") {
      buttons.push({
        label: "Service Restored",
        status: "Service restored",
        icon: CheckCircle,
        message: `${signal.category} service has been fully restored in ${signal.area}. Thank you for your patience.`,
        variant: "success",
      })
    }

    return buttons
  }

  const actionButtons = getActionButtons()

  const handleActionClick = (action: ActionButton) => {
    setCompletedAction(action.status)
    // Brief delay to show feedback before submitting
    setTimeout(() => {
      onSubmit(action.status, action.message)
    }, 400)
  }

  const handleCustomSubmit = () => {
    if (customMessage.trim()) {
      const resolution = expectedDate && expectedTime 
        ? `${expectedDate} at ${expectedTime}`
        : expectedDate 
          ? expectedDate 
          : undefined
      
      // Use the next logical status or keep current
      const nextStatus = getNextLogicalStatus()
      onSubmit(nextStatus, customMessage, resolution)
    }
  }

  // Determine next logical status for custom updates
  const getNextLogicalStatus = (): ResponseStatus => {
    const statusOrder: ResponseStatus[] = [
      "No official update yet",
      "Acknowledged",
      "Teams dispatched",
      "Teams on site",
      "Work ongoing",
      "Restoration in progress",
      "Service restored",
    ]
    const currentIndex = statusOrder.indexOf(signal.responseStatus)
    // For custom updates, advance one step if not at the end
    if (currentIndex < statusOrder.length - 1 && currentIndex > 0) {
      return statusOrder[currentIndex + 1]
    }
    return signal.responseStatus === "No official update yet" ? "Acknowledged" : signal.responseStatus
  }

  // Format expected resolution for display
  const formatExpectedResolution = () => {
    if (!expectedDate && !expectedTime) return null
    
    if (expectedDate && expectedTime) {
      const date = new Date(`${expectedDate}T${expectedTime}`)
      return date.toLocaleString("en-US", {
        weekday: "short",
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
      })
    }
    
    if (expectedDate) {
      const date = new Date(expectedDate)
      return date.toLocaleDateString("en-US", {
        weekday: "short",
        month: "short",
        day: "numeric",
      })
    }
    
    return expectedTime
  }

  // Get institution initials based on signal category
  const getInstitutionInfo = () => {
    switch (signal.category) {
      case "Power":
        return { initials: "KP", name: "Kenya Power" }
      case "Water":
        return { initials: "NW", name: "Nairobi Water" }
      case "Roads":
      case "Traffic":
        return { initials: "KH", name: "KenHA / KURA" }
      default:
        return { initials: "NC", name: "Nairobi County" }
    }
  }

  const institutionInfo = getInstitutionInfo()
  const formattedResolution = formatExpectedResolution()

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-background/80 backdrop-blur-sm p-4">
      <div className="flex max-h-[90vh] w-full max-w-2xl flex-col rounded-xl border border-border bg-card shadow-xl">
        {/* Fixed Header */}
        <div className="flex shrink-0 items-center justify-between border-b border-border px-6 py-4">
          <h2 className="text-lg font-semibold">Post Official Update</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Scrollable Body */}
        <ScrollArea className="flex-1 overflow-y-auto">
          <div className="p-6">
            {/* Signal context */}
            <div className="mb-6 rounded-lg bg-secondary/50 p-3">
              <p className="text-xs text-muted-foreground">Responding to signal</p>
              <p className="font-medium">{signal.title}</p>
              <p className="text-sm text-muted-foreground">{signal.area}</p>
            </div>

            {/* Quick Action Buttons */}
            {actionButtons.length > 0 && (
              <div className="mb-6">
                <Label className="mb-3 block text-sm font-medium">Quick Actions</Label>
                <div className="flex flex-wrap gap-2">
                  {actionButtons.map((action) => {
                    const isCompleted = completedAction === action.status
                    return (
                      <Button
                        key={action.status}
                        variant="outline"
                        className={cn(
                          "gap-2 transition-all",
                          action.variant === "success" && "border-emerald-200 text-emerald-700 hover:bg-emerald-50",
                          isCompleted && "border-emerald-500 bg-emerald-50 text-emerald-700"
                        )}
                        onClick={() => handleActionClick(action)}
                        disabled={completedAction !== null}
                      >
                        {isCompleted ? (
                          <Check className="h-4 w-4" />
                        ) : (
                          <action.icon className="h-4 w-4" />
                        )}
                        {action.label}
                      </Button>
                    )
                  })}
                </div>
                <p className="mt-2 text-xs text-muted-foreground">
                  Click to post a structured update and advance the response stage
                </p>
              </div>
            )}

            {/* Divider */}
            {actionButtons.length > 0 && (
              <div className="mb-6 flex items-center gap-4">
                <div className="h-px flex-1 bg-border" />
                <span className="text-xs text-muted-foreground">or post a custom update</span>
                <div className="h-px flex-1 bg-border" />
              </div>
            )}

            {/* Custom Message Section */}
            <div className="flex flex-col gap-4">
              <div className="flex flex-col gap-2">
                <Label htmlFor="message" className="flex items-center gap-2">
                  <MessageSquare className="h-4 w-4" />
                  Custom Message
                </Label>
                <Textarea
                  id="message"
                  placeholder="Provide a detailed update on the situation..."
                  value={customMessage}
                  onChange={(e) => setCustomMessage(e.target.value)}
                  rows={4}
                  className="resize-none"
                />
              </div>

              <div className="flex flex-col gap-2">
                <Label className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  Expected Resolution (optional)
                </Label>
                <div className="flex gap-3">
                  <div className="flex-1">
                    <Label htmlFor="expectedDate" className="sr-only">Date</Label>
                    <input
                      id="expectedDate"
                      type="date"
                      value={expectedDate}
                      onChange={(e) => setExpectedDate(e.target.value)}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    />
                  </div>
                  <div className="flex-1">
                    <Label htmlFor="expectedTime" className="sr-only">Time</Label>
                    <input
                      id="expectedTime"
                      type="time"
                      value={expectedTime}
                      onChange={(e) => setExpectedTime(e.target.value)}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    />
                  </div>
                </div>
              </div>

              <Button
                variant="outline"
                className="w-fit"
                onClick={() => setShowPreview(!showPreview)}
              >
                <Eye className="mr-2 h-4 w-4" />
                {showPreview ? "Hide Preview" : "Preview in Hali App"}
              </Button>

              {showPreview && (
                <Card className="border-2 border-dashed border-primary/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                      <Smartphone className="h-4 w-4" />
                      How this appears in Hali citizen app
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pb-4">
                    <div className="rounded-lg bg-background p-4">
                      <div className="mb-3 flex items-center gap-3">
                        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary">
                          <span className="text-xs font-bold text-primary-foreground">
                            {institutionInfo.initials}
                          </span>
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-medium">{institutionInfo.name}</p>
                          <p className="text-xs text-muted-foreground">Official Update</p>
                        </div>
                      </div>
                      <div className="rounded-lg bg-secondary/50 p-3">
                        <p className="mb-1.5 text-xs font-medium text-primary">
                          {getNextLogicalStatus()}
                        </p>
                        <p className="break-words text-sm leading-relaxed">
                          {customMessage || "Your message will appear here..."}
                        </p>
                        {formattedResolution && (
                          <p className="mt-2 text-xs text-muted-foreground">
                            Expected resolution: {formattedResolution}
                          </p>
                        )}
                      </div>
                      <p className="mt-2 text-xs text-muted-foreground">Just now</p>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </ScrollArea>

        {/* Fixed Footer */}
        <div className="flex shrink-0 items-center justify-end gap-3 border-t border-border px-6 py-4">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleCustomSubmit} 
            disabled={!customMessage.trim() || completedAction !== null}
          >
            Post Custom Update
          </Button>
        </div>
      </div>
    </div>
  )
}
