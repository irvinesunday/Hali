"use client"

import { useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { areas } from "@/lib/demo-data"
import { cn } from "@/lib/utils"
import type { Signal, ActivityItem, Institution, DrilldownFilterType } from "@/lib/types"
import { institutionCategories } from "@/lib/types"
import { TrendingUp, TrendingDown, MessageSquare, CheckCircle, AlertTriangle, Activity, ChevronRight } from "lucide-react"

interface OverviewProps {
  signals: Signal[]
  activityFeed: ActivityItem[]
  selectedArea: string
  institution: Institution
  onDrilldown: (filterType: DrilldownFilterType) => void
  onSelectArea: (area: string) => void
}

export function Overview({ signals, activityFeed, selectedArea, institution, onDrilldown, onSelectArea }: OverviewProps) {
  const relevantCategories = institutionCategories[institution]

  // Compute metrics from filtered signals
  const metrics = useMemo(() => {
    const activeSignals = signals.filter((s) => s.condition === "Active" || s.condition === "Elevated").length
    const growingSignals = signals.filter((s) => s.trend === "Growing").length
    const updatesPostedToday = signals.reduce((acc, s) => acc + s.updates.length, 0)
    const stabilizedToday = signals.filter((s) => s.trend === "Stable" || s.trend === "Slowing" || s.trend === "Possible restoration").length

    return {
      activeSignals,
      growingSignals,
      updatesPostedToday,
      stabilizedToday,
    }
  }, [signals])

  // Compute area statuses based on filtered signals
  const areaStatuses = useMemo(() => {
    return areas.map((area) => {
      const areaSignals = signals.filter((s) => s.area === area.name)
      const hasActive = areaSignals.some((s) => s.condition === "Active")
      const hasElevated = areaSignals.some((s) => s.condition === "Elevated")
      const activeCount = areaSignals.length

      let status: "Active" | "Elevated" | "Calm" = "Calm"
      if (hasActive) status = "Active"
      else if (hasElevated) status = "Elevated"

      const topCategory = areaSignals.length > 0 ? areaSignals[0].category : null

      return {
        ...area,
        status,
        activeSignals: activeCount,
        topCategory,
      }
    })
  }, [signals])

  // Filter to only show areas that have signals for this institution
  const relevantAreas = areaStatuses.filter(
    (area) => area.activeSignals > 0 || signals.some((s) => s.area === area.name)
  )

  // Show all areas if none have signals (fallback)
  const displayAreas = relevantAreas.length > 0 ? relevantAreas.slice(0, 6) : areaStatuses.slice(0, 6)

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">Overview</h1>
        <p className="text-sm text-muted-foreground">
          Real-time operational status for {institution}
          {selectedArea !== "All Areas" && ` in ${selectedArea}`}
        </p>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <SummaryCard
          title="Active Signals"
          value={metrics.activeSignals}
          icon={AlertTriangle}
          variant="default"
          onClick={() => onDrilldown("active")}
        />
        <SummaryCard
          title="Growing Signals"
          value={metrics.growingSignals}
          icon={TrendingUp}
          variant="warning"
          onClick={() => onDrilldown("growing")}
        />
        <SummaryCard
          title="Updates Posted Today"
          value={metrics.updatesPostedToday}
          icon={MessageSquare}
          variant="info"
          onClick={() => onDrilldown("updates-today")}
        />
        <SummaryCard
          title="Stabilized Today"
          value={metrics.stabilizedToday}
          icon={CheckCircle}
          variant="success"
          onClick={() => onDrilldown("stabilized-today")}
        />
      </div>

      <div className="grid grid-cols-3 gap-6">
        <Card className="col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-medium">
              <Activity className="h-4 w-4 text-primary" />
              Live Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            {activityFeed.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4">
                No recent activity for {institution} signals
                {selectedArea !== "All Areas" && ` in ${selectedArea}`}
              </p>
            ) : (
              <div className="flex flex-col gap-3">
                {activityFeed.slice(0, 6).map((item) => (
                  <div
                    key={item.id}
                    className="flex items-start justify-between rounded-lg border border-border/50 bg-secondary/30 p-3"
                  >
                    <div className="flex items-start gap-3">
                      <ActivityIcon type={item.type} />
                      <p className="text-sm">{item.message}</p>
                    </div>
                    <span className="shrink-0 text-xs text-muted-foreground">
                      {item.timestamp}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-medium">Areas Snapshot</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-2">
              {displayAreas.map((area) => (
                <button
                  key={area.id}
                  type="button"
                  onClick={() => onSelectArea(area.name)}
                  className="flex w-full items-center justify-between rounded-lg border border-border/50 px-3 py-2 text-left transition-all hover:border-primary/40 hover:bg-secondary/50"
                >
                  <div className="flex flex-col">
                    <span className="text-sm font-medium">{area.name}</span>
                    {area.activeSignals > 0 && (
                      <span className="text-xs text-muted-foreground">
                        {area.activeSignals} signal{area.activeSignals !== 1 ? "s" : ""}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <StatusBadge status={area.status} />
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

interface SummaryCardProps {
  title: string
  value: number
  icon: React.ElementType
  variant: "default" | "warning" | "info" | "success"
  onClick: () => void
}

function SummaryCard({ title, value, icon: Icon, variant, onClick }: SummaryCardProps) {
  const variantStyles = {
    default: "text-foreground",
    warning: "text-amber-600",
    info: "text-primary",
    success: "text-emerald-600",
  }

  return (
    <Card
      className="cursor-pointer transition-all duration-200 hover:border-primary/40 hover:shadow-md"
      onClick={onClick}
    >
      <CardContent className="flex items-center gap-4 p-5">
        <div
          className={cn(
            "flex h-10 w-10 items-center justify-center rounded-lg bg-secondary transition-colors",
            variant === "warning" && "bg-amber-50",
            variant === "info" && "bg-primary/10",
            variant === "success" && "bg-emerald-50"
          )}
        >
          <Icon className={cn("h-5 w-5", variantStyles[variant])} />
        </div>
        <div>
          <p className="text-2xl font-semibold">{value}</p>
          <p className="text-xs text-muted-foreground">{title}</p>
        </div>
      </CardContent>
    </Card>
  )
}

function ActivityIcon({ type }: { type: string }) {
  if (type === "growing") {
    return (
      <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-amber-100">
        <TrendingUp className="h-3.5 w-3.5 text-amber-600" />
      </div>
    )
  }
  if (type === "stabilizing") {
    return (
      <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-blue-100">
        <TrendingDown className="h-3.5 w-3.5 text-blue-600" />
      </div>
    )
  }
  if (type === "update") {
    return (
      <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10">
        <MessageSquare className="h-3.5 w-3.5 text-primary" />
      </div>
    )
  }
  return (
    <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-100">
      <CheckCircle className="h-3.5 w-3.5 text-emerald-600" />
    </div>
  )
}

function StatusBadge({ status }: { status: string }) {
  const statusStyles = {
    Active: "bg-red-100 text-red-700",
    Elevated: "bg-amber-100 text-amber-700",
    Calm: "bg-emerald-100 text-emerald-700",
  }

  return (
    <span
      className={cn(
        "rounded-full px-2.5 py-0.5 text-xs font-medium",
        statusStyles[status as keyof typeof statusStyles] || statusStyles.Calm
      )}
    >
      {status}
    </span>
  )
}
