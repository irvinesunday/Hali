"use client"

import { useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { areas } from "@/lib/demo-data"
import { cn } from "@/lib/utils"
import type { Signal, Institution } from "@/lib/types"
import {
  AlertTriangle,
  Clock,
  MessageSquare,
  TrendingDown,
  MapPin,
  Zap,
  CheckCircle,
  ArrowUp,
  ArrowDown,
  Target,
  CircleDot,
  Loader2,
  XCircle,
} from "lucide-react"

interface MetricsProps {
  signals: Signal[]
  selectedArea: string
  institution: Institution
}

export function Metrics({ signals, selectedArea, institution }: MetricsProps) {
  // Compute metrics from filtered signals
  const computedMetrics = useMemo(() => {
    const activeSignals = signals.filter((s) => s.condition === "Active" || s.condition === "Elevated").length
    const updatesPostedToday = signals.reduce((acc, s) => acc + s.updates.length, 0)
    const stabilizedToday = signals.filter((s) => s.trend === "Stable" || s.trend === "Slowing" || s.trend === "Possible restoration").length
    const resolvedSignals = signals.filter((s) => s.responseStatus === "Service restored").length
    const inProgressSignals = signals.filter((s) => 
      s.responseStatus !== "No official update yet" && 
      s.responseStatus !== "Service restored"
    ).length
    const unresolvedSignals = signals.filter((s) => s.responseStatus === "No official update yet").length

    // Find busiest area
    const areaCounts: Record<string, number> = {}
    signals.forEach((s) => {
      areaCounts[s.area] = (areaCounts[s.area] || 0) + 1
    })
    const busiestArea = Object.entries(areaCounts).sort(([, a], [, b]) => b - a)[0]?.[0] || "None"

    // Find top category
    const categoryCounts: Record<string, number> = {}
    signals.forEach((s) => {
      categoryCounts[s.category] = (categoryCounts[s.category] || 0) + 1
    })
    const topCategory = Object.entries(categoryCounts).sort(([, a], [, b]) => b - a)[0]?.[0] || "None"

    // Avg first response (simulated based on updates)
    const signalsWithUpdates = signals.filter((s) => s.updates.length > 0)
    const avgFirstResponse = signalsWithUpdates.length > 0 ? "28 min" : "N/A"

    // Loop Closure Rate
    const totalSignals = signals.length
    const lcr = totalSignals > 0 ? Math.round((resolvedSignals / totalSignals) * 100) : 0

    return {
      activeSignals,
      avgFirstResponse,
      updatesPostedToday,
      stabilizedToday,
      busiestArea,
      topCategory,
      resolvedSignals,
      inProgressSignals,
      unresolvedSignals,
      totalSignals,
      lcr,
    }
  }, [signals])

  // Compute signals by area for this institution
  const signalsByArea = useMemo(() => {
    const areaCounts: Record<string, number> = {}
    signals.forEach((s) => {
      areaCounts[s.area] = (areaCounts[s.area] || 0) + 1
    })

    return areas.map((area) => ({
      name: area.name,
      count: areaCounts[area.name] || 0,
    })).filter((a) => a.count > 0 || signals.some((s) => s.area === a.name))
  }, [signals])

  // Compute top categories for this institution
  const topCategories = useMemo(() => {
    const categoryCount: Record<string, number> = {}
    signals.forEach((signal) => {
      categoryCount[signal.category] = (categoryCount[signal.category] || 0) + 1
    })

    return Object.entries(categoryCount)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 5)
  }, [signals])

  const maxSignalCount = Math.max(...signalsByArea.map((a) => a.count), 1)
  const maxCategoryCount = Math.max(...topCategories.map(([, count]) => count), 1)

  // LCR trend (simulated)
  const lcrTrend = computedMetrics.lcr > 50 ? { direction: "up", value: 5 } : { direction: "down", value: 3 }

  // LCR insight text
  const getLcrInsight = () => {
    if (computedMetrics.lcr >= 80) return "Excellent resolution rate this week"
    if (computedMetrics.lcr >= 60) return "Most signals resolved within 2-4 hours"
    if (computedMetrics.lcr >= 40) return "Resolution time improving"
    if (computedMetrics.lcr >= 20) return "Loop closure improving this week"
    return "Focus on reducing unresolved signals"
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">Metrics</h1>
        <p className="text-sm text-muted-foreground">
          Operational performance summary for {institution}
          {selectedArea !== "All Areas" && ` in ${selectedArea}`}
        </p>
      </div>

      {/* Loop Closure Rate Card - Featured */}
      <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base font-medium">
            <Target className="h-5 w-5 text-primary" />
            Loop Closure Rate (LCR)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-baseline gap-2">
                <span className="text-5xl font-bold text-primary">{computedMetrics.lcr}%</span>
                <div className={cn(
                  "flex items-center gap-0.5 rounded-full px-2 py-0.5 text-xs font-medium",
                  lcrTrend.direction === "up" 
                    ? "bg-emerald-100 text-emerald-700" 
                    : "bg-red-100 text-red-700"
                )}>
                  {lcrTrend.direction === "up" ? (
                    <ArrowUp className="h-3 w-3" />
                  ) : (
                    <ArrowDown className="h-3 w-3" />
                  )}
                  {lcrTrend.value}%
                </div>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">Signals successfully resolved</p>
              <p className="mt-3 text-xs text-primary/80">{getLcrInsight()}</p>
            </div>
            
            {/* LCR Breakdown */}
            <div className="flex flex-col gap-2 text-right">
              <div className="flex items-center justify-end gap-2">
                <span className="text-sm text-muted-foreground">Total Signals</span>
                <span className="min-w-[2.5rem] rounded-md bg-secondary px-2 py-0.5 text-center text-sm font-semibold">
                  {computedMetrics.totalSignals}
                </span>
              </div>
              <div className="flex items-center justify-end gap-2">
                <CheckCircle className="h-3.5 w-3.5 text-emerald-600" />
                <span className="text-sm text-muted-foreground">Resolved</span>
                <span className="min-w-[2.5rem] rounded-md bg-emerald-50 px-2 py-0.5 text-center text-sm font-semibold text-emerald-700">
                  {computedMetrics.resolvedSignals}
                </span>
              </div>
              <div className="flex items-center justify-end gap-2">
                <Loader2 className="h-3.5 w-3.5 text-amber-600" />
                <span className="text-sm text-muted-foreground">In Progress</span>
                <span className="min-w-[2.5rem] rounded-md bg-amber-50 px-2 py-0.5 text-center text-sm font-semibold text-amber-700">
                  {computedMetrics.inProgressSignals}
                </span>
              </div>
              <div className="flex items-center justify-end gap-2">
                <XCircle className="h-3.5 w-3.5 text-slate-500" />
                <span className="text-sm text-muted-foreground">Unresolved</span>
                <span className="min-w-[2.5rem] rounded-md bg-slate-100 px-2 py-0.5 text-center text-sm font-semibold text-slate-600">
                  {computedMetrics.unresolvedSignals}
                </span>
              </div>
            </div>
          </div>

          {/* Visual progress bar */}
          <div className="mt-4">
            <div className="flex h-3 w-full overflow-hidden rounded-full bg-secondary">
              <div 
                className="bg-emerald-500 transition-all"
                style={{ width: `${(computedMetrics.resolvedSignals / Math.max(computedMetrics.totalSignals, 1)) * 100}%` }}
              />
              <div 
                className="bg-amber-400 transition-all"
                style={{ width: `${(computedMetrics.inProgressSignals / Math.max(computedMetrics.totalSignals, 1)) * 100}%` }}
              />
              <div 
                className="bg-slate-300 transition-all"
                style={{ width: `${(computedMetrics.unresolvedSignals / Math.max(computedMetrics.totalSignals, 1)) * 100}%` }}
              />
            </div>
            <div className="mt-2 flex items-center justify-center gap-4 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <CircleDot className="h-2.5 w-2.5 text-emerald-500" />
                Resolved
              </span>
              <span className="flex items-center gap-1">
                <CircleDot className="h-2.5 w-2.5 text-amber-400" />
                In Progress
              </span>
              <span className="flex items-center gap-1">
                <CircleDot className="h-2.5 w-2.5 text-slate-300" />
                Unresolved
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-3 gap-4">
        <MetricCard
          title="Active Signals Now"
          value={computedMetrics.activeSignals.toString()}
          icon={AlertTriangle}
          variant="default"
        />
        <MetricCard
          title="Avg First Response"
          value={computedMetrics.avgFirstResponse}
          icon={Clock}
          variant="info"
        />
        <MetricCard
          title="Updates Posted Today"
          value={computedMetrics.updatesPostedToday.toString()}
          icon={MessageSquare}
          variant="info"
        />
        <MetricCard
          title="Stabilized Today"
          value={computedMetrics.stabilizedToday.toString()}
          icon={TrendingDown}
          variant="success"
        />
        <MetricCard
          title="Busiest Area"
          value={computedMetrics.busiestArea}
          icon={MapPin}
          variant="warning"
        />
        <MetricCard
          title="Top Category"
          value={computedMetrics.topCategory}
          icon={Zap}
          variant="warning"
        />
      </div>

      <div className="grid grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium">
              Active Signals by Area
            </CardTitle>
          </CardHeader>
          <CardContent>
            {signalsByArea.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4">
                No active signals for {institution}
              </p>
            ) : (
              <div className="flex flex-col gap-3">
                {signalsByArea.map((area) => (
                  <div key={area.name} className="flex items-center gap-3">
                    <span className="w-28 text-sm">{area.name}</span>
                    <div className="flex-1">
                      <div className="h-6 rounded-full bg-secondary">
                        <div
                          className="h-6 rounded-full bg-primary transition-all"
                          style={{
                            width: `${Math.max((area.count / maxSignalCount) * 100, 10)}%`,
                          }}
                        />
                      </div>
                    </div>
                    <span className="w-8 text-right text-sm font-medium">
                      {area.count}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium">
              Categories This Week
            </CardTitle>
          </CardHeader>
          <CardContent>
            {topCategories.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4">
                No signals for {institution}
              </p>
            ) : (
              <div className="flex flex-col gap-3">
                {topCategories.map(([category, count]) => (
                  <div key={category} className="flex items-center gap-3">
                    <CategoryBadge category={category} />
                    <div className="flex-1">
                      <div className="h-6 rounded-full bg-secondary">
                        <div
                          className="h-6 rounded-full bg-chart-1 transition-all"
                          style={{
                            width: `${Math.max((count / maxCategoryCount) * 100, 10)}%`,
                          }}
                        />
                      </div>
                    </div>
                    <span className="w-8 text-right text-sm font-medium">{count}</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

interface MetricCardProps {
  title: string
  value: string
  icon: React.ElementType
  variant: "default" | "warning" | "info" | "success"
}

function MetricCard({ title, value, icon: Icon, variant }: MetricCardProps) {
  const variantStyles = {
    default: "text-foreground",
    warning: "text-amber-600",
    info: "text-primary",
    success: "text-emerald-600",
  }

  return (
    <Card>
      <CardContent className="flex items-center gap-4 p-5">
        <div
          className={cn(
            "flex h-10 w-10 items-center justify-center rounded-lg bg-secondary",
            variant === "warning" && "bg-amber-50",
            variant === "info" && "bg-primary/10",
            variant === "success" && "bg-emerald-50"
          )}
        >
          <Icon className={cn("h-5 w-5", variantStyles[variant])} />
        </div>
        <div>
          <p className="text-xl font-semibold">{value}</p>
          <p className="text-xs text-muted-foreground">{title}</p>
        </div>
      </CardContent>
    </Card>
  )
}

function CategoryBadge({ category }: { category: string }) {
  const colors: Record<string, string> = {
    Power: "bg-amber-100 text-amber-700",
    Water: "bg-blue-100 text-blue-700",
    Roads: "bg-slate-100 text-slate-700",
    Drainage: "bg-cyan-100 text-cyan-700",
    Waste: "bg-orange-100 text-orange-700",
    Traffic: "bg-rose-100 text-rose-700",
  }

  return (
    <span
      className={cn(
        "w-20 rounded-full px-2 py-0.5 text-center text-xs font-medium",
        colors[category] || "bg-slate-100 text-slate-700"
      )}
    >
      {category}
    </span>
  )
}
