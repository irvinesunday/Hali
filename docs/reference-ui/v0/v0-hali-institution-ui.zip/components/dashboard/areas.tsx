"use client"

import { useMemo } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { areas } from "@/lib/demo-data"
import { cn } from "@/lib/utils"
import type { Signal, Institution } from "@/lib/types"
import { Clock, AlertTriangle } from "lucide-react"

interface AreasProps {
  signals: Signal[]
  onSelectArea: (area: string) => void
  institution: Institution
}

export function Areas({ signals, onSelectArea, institution }: AreasProps) {
  // Compute area statuses based on filtered signals for this institution
  const areaStatuses = useMemo(() => {
    return areas.map((area) => {
      const areaSignals = signals.filter((s) => s.area === area.name)
      const hasActive = areaSignals.some((s) => s.condition === "Active")
      const hasElevated = areaSignals.some((s) => s.condition === "Elevated")
      const activeCount = areaSignals.length

      let status: "Active" | "Elevated" | "Calm" = "Calm"
      if (hasActive) status = "Active"
      else if (hasElevated) status = "Elevated"

      const topCategory = areaSignals.length > 0 ? areaSignals[0].category : null

      return {
        ...area,
        status,
        activeSignals: activeCount,
        topCategory,
      }
    })
  }, [signals])

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">Areas</h1>
        <p className="text-sm text-muted-foreground">
          Operational status by locality for {institution}
        </p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {areaStatuses.map((area) => (
          <Card
            key={area.id}
            className="cursor-pointer transition-all hover:border-primary/30 hover:shadow-sm"
            onClick={() => onSelectArea(area.name)}
          >
            <CardContent className="p-5">
              <div className="mb-3 flex items-center justify-between">
                <h3 className="text-lg font-semibold">{area.name}</h3>
                <StatusBadge status={area.status} />
              </div>

              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="flex items-center gap-1.5 text-muted-foreground">
                    <AlertTriangle className="h-3.5 w-3.5" />
                    Active signals
                  </span>
                  <span className="font-medium">{area.activeSignals}</span>
                </div>

                {area.topCategory && (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Top issue</span>
                    <CategoryBadge category={area.topCategory} />
                  </div>
                )}

                <div className="flex items-center justify-between text-sm">
                  <span className="flex items-center gap-1.5 text-muted-foreground">
                    <Clock className="h-3.5 w-3.5" />
                    Last updated
                  </span>
                  <span className="text-muted-foreground">{area.lastUpdated}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

function StatusBadge({ status }: { status: string }) {
  const statusStyles = {
    Active: "bg-red-100 text-red-700",
    Elevated: "bg-amber-100 text-amber-700",
    Calm: "bg-emerald-100 text-emerald-700",
  }

  return (
    <span
      className={cn(
        "rounded-full px-2.5 py-0.5 text-xs font-medium",
        statusStyles[status as keyof typeof statusStyles] || statusStyles.Calm
      )}
    >
      {status}
    </span>
  )
}

function CategoryBadge({ category }: { category: string }) {
  const colors: Record<string, string> = {
    Power: "bg-amber-100 text-amber-700",
    Water: "bg-blue-100 text-blue-700",
    Roads: "bg-slate-100 text-slate-700",
    Drainage: "bg-cyan-100 text-cyan-700",
    Waste: "bg-orange-100 text-orange-700",
    Traffic: "bg-rose-100 text-rose-700",
  }

  return (
    <span
      className={cn(
        "rounded-full px-2 py-0.5 text-xs font-medium",
        colors[category] || "bg-slate-100 text-slate-700"
      )}
    >
      {category}
    </span>
  )
}
