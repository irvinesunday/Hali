"use client"

import { useState, useMemo } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import type { Signal, SignalCategory, SignalTrend, ResponseStatus, Institution, DrilldownFilterType } from "@/lib/types"
import { institutionCategories } from "@/lib/types"
import { cn } from "@/lib/utils"
import { TrendingUp, TrendingDown, Minus, RotateCcw, Users, Clock, MapPin, X, Filter } from "lucide-react"

interface LiveSignalsProps {
  signals: Signal[]
  onSelectSignal: (signal: Signal) => void
  selectedArea: string
  institution: Institution
  drilldownFilter: DrilldownFilterType
  onClearDrilldown: () => void
}

export function LiveSignals({ signals, onSelectSignal, selectedArea, institution, drilldownFilter, onClearDrilldown }: LiveSignalsProps) {
  const [trendFilter, setTrendFilter] = useState<string>("all")
  const [statusFilter, setStatusFilter] = useState<string>("all")

  // Get categories for this institution to show in filter
  const relevantCategories = institutionCategories[institution]

  // Generate filter description based on drilldown
  const filterDescription = useMemo(() => {
    if (!drilldownFilter) return null

    const areaText = selectedArea !== "All Areas" ? ` in ${selectedArea}` : ""
    
    switch (drilldownFilter) {
      case "active":
        return `Active signals${areaText}`
      case "growing":
        return `Growing signals${areaText}`
      case "updates-today":
        return `Signals with updates posted today${areaText}`
      case "stabilized-today":
        return `Stabilized signals${areaText}`
      default:
        return null
    }
  }, [drilldownFilter, selectedArea])

  const filteredSignals = useMemo(() => {
    return signals.filter((signal) => {
      // Apply drilldown filter first
      if (drilldownFilter) {
        switch (drilldownFilter) {
          case "active":
            if (signal.condition !== "Active" && signal.condition !== "Elevated") return false
            break
          case "growing":
            if (signal.trend !== "Growing") return false
            break
          case "updates-today":
            if (signal.updates.length === 0) return false
            break
          case "stabilized-today":
            if (signal.trend !== "Stable" && signal.trend !== "Slowing" && signal.trend !== "Possible restoration") return false
            break
        }
      }

      // Apply manual filters
      if (trendFilter !== "all" && signal.trend !== trendFilter) return false
      if (statusFilter !== "all" && signal.responseStatus !== statusFilter) return false
      return true
    })
  }, [signals, trendFilter, statusFilter, drilldownFilter])

  const clearFilters = () => {
    setTrendFilter("all")
    setStatusFilter("all")
    onClearDrilldown()
  }

  const hasFilters = trendFilter !== "all" || statusFilter !== "all" || drilldownFilter !== null

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">Live Signals</h1>
        <p className="text-sm text-muted-foreground">
          {institution} signals{selectedArea !== "All Areas" ? ` in ${selectedArea}` : ""}
        </p>
      </div>

      {filterDescription && (
        <div className="flex items-center justify-between rounded-lg border border-primary/20 bg-primary/5 px-4 py-3">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium">
              Showing: <span className="text-primary">{filterDescription}</span>
            </span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="h-7 gap-1.5 text-muted-foreground hover:text-foreground"
            onClick={onClearDrilldown}
          >
            <X className="h-3.5 w-3.5" />
            Clear
          </Button>
        </div>
      )}

      <div className="flex items-center gap-3">
        <Select value={trendFilter} onValueChange={setTrendFilter}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Trend" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Trends</SelectItem>
            <SelectItem value="Growing">Growing</SelectItem>
            <SelectItem value="Stable">Stable</SelectItem>
            <SelectItem value="Slowing">Slowing</SelectItem>
            <SelectItem value="Possible restoration">Possible restoration</SelectItem>
          </SelectContent>
        </Select>

        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Response Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="No official update yet">No official update yet</SelectItem>
            <SelectItem value="Acknowledged">Acknowledged</SelectItem>
            <SelectItem value="Teams dispatched">Teams dispatched</SelectItem>
            <SelectItem value="Teams on site">Teams on site</SelectItem>
            <SelectItem value="Work ongoing">Work ongoing</SelectItem>
            <SelectItem value="Restoration in progress">Restoration in progress</SelectItem>
            <SelectItem value="Service restored">Service restored</SelectItem>
          </SelectContent>
        </Select>

        {hasFilters && (
          <Button variant="ghost" size="sm" onClick={clearFilters}>
            Clear filters
          </Button>
        )}

        <span className="ml-auto text-sm text-muted-foreground">
          {filteredSignals.length} signal{filteredSignals.length !== 1 ? "s" : ""}
        </span>
      </div>

      <div className="flex flex-col gap-3">
        {filteredSignals.map((signal) => (
          <SignalCard
            key={signal.id}
            signal={signal}
            onClick={() => onSelectSignal(signal)}
          />
        ))}

        {filteredSignals.length === 0 && (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <p className="text-muted-foreground">
                No {institution.toLowerCase()} signals
                {selectedArea !== "All Areas" ? ` in ${selectedArea}` : ""}
              </p>
              {hasFilters && (
                <Button variant="link" onClick={clearFilters}>
                  Clear all filters
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

interface SignalCardProps {
  signal: Signal
  onClick: () => void
}

function SignalCard({ signal, onClick }: SignalCardProps) {
  return (
    <Card
      className="cursor-pointer transition-all hover:border-primary/30 hover:shadow-sm"
      onClick={onClick}
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <div className="mb-2 flex items-center gap-2">
              <CategoryBadge category={signal.category} />
              <ConditionBadge condition={signal.condition} />
              <TrendBadge trend={signal.trend} />
            </div>
            <h3 className="mb-1 font-medium">{signal.title}</h3>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <MapPin className="h-3.5 w-3.5" />
                {signal.area}
              </span>
              <span className="flex items-center gap-1">
                <Users className="h-3.5 w-3.5" />
                {signal.affectedCount} affected
              </span>
              <span className="flex items-center gap-1">
                <Clock className="h-3.5 w-3.5" />
                {signal.timeActive}
              </span>
            </div>
          </div>
          <div className="text-right">
            <ResponseStatusBadge status={signal.responseStatus} />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function CategoryBadge({ category }: { category: SignalCategory }) {
  const colors: Record<SignalCategory, string> = {
    Power: "bg-amber-100 text-amber-700",
    Water: "bg-blue-100 text-blue-700",
    Roads: "bg-slate-100 text-slate-700",
    Drainage: "bg-cyan-100 text-cyan-700",
    Waste: "bg-orange-100 text-orange-700",
    Traffic: "bg-rose-100 text-rose-700",
  }

  return (
    <span className={cn("rounded-full px-2 py-0.5 text-xs font-medium", colors[category])}>
      {category}
    </span>
  )
}

function ConditionBadge({ condition }: { condition: string }) {
  const colors = {
    Active: "bg-red-100 text-red-700",
    Elevated: "bg-amber-100 text-amber-700",
    Calm: "bg-emerald-100 text-emerald-700",
  }

  return (
    <span
      className={cn(
        "rounded-full px-2 py-0.5 text-xs font-medium",
        colors[condition as keyof typeof colors]
      )}
    >
      {condition}
    </span>
  )
}

function TrendBadge({ trend }: { trend: SignalTrend }) {
  const config: Record<SignalTrend, { icon: React.ElementType; className: string }> = {
    Growing: { icon: TrendingUp, className: "text-red-600" },
    Stable: { icon: Minus, className: "text-slate-500" },
    Slowing: { icon: TrendingDown, className: "text-blue-600" },
    "Possible restoration": { icon: RotateCcw, className: "text-emerald-600" },
  }

  const { icon: Icon, className } = config[trend]

  return (
    <span className={cn("flex items-center gap-1 text-xs font-medium", className)}>
      <Icon className="h-3 w-3" />
      {trend}
    </span>
  )
}

function ResponseStatusBadge({ status }: { status: ResponseStatus }) {
  const statusColors: Record<ResponseStatus, string> = {
    "No official update yet": "bg-slate-100 text-slate-600",
    Acknowledged: "bg-blue-100 text-blue-700",
    "Teams dispatched": "bg-indigo-100 text-indigo-700",
    "Teams on site": "bg-purple-100 text-purple-700",
    "Work ongoing": "bg-amber-100 text-amber-700",
    "Restoration in progress": "bg-teal-100 text-teal-700",
    "Service restored": "bg-emerald-100 text-emerald-700",
  }

  return (
    <span
      className={cn(
        "inline-block rounded-full px-2.5 py-1 text-xs font-medium",
        statusColors[status]
      )}
    >
      {status}
    </span>
  )
}
