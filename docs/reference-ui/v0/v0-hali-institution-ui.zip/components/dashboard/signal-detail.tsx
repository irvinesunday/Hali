"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { Signal, ResponseStatus } from "@/lib/types"
import { cn } from "@/lib/utils"
import {
  X,
  MapPin,
  Users,
  Clock,
  TrendingUp,
  TrendingDown,
  Minus,
  RotateCcw,
  MessageSquare,
  CheckCircle,
  AlertCircle,
  Truck,
  Wrench,
  Eye,
  Radio,
  Check,
} from "lucide-react"
import { PostUpdateModal } from "./post-update-modal"

interface SignalDetailProps {
  signal: Signal
  onClose: () => void
  onUpdatePosted: (signalId: string, status: ResponseStatus, message: string, expectedResolution?: string) => void
}

export function SignalDetail({ signal, onClose, onUpdatePosted }: SignalDetailProps) {
  const [showPostUpdate, setShowPostUpdate] = useState(false)
  const [completedAction, setCompletedAction] = useState<string | null>(null)
  const [showFeedback, setShowFeedback] = useState(false)

  const handleQuickAction = (action: ResponseStatus) => {
    const messages: Record<ResponseStatus, string> = {
      "No official update yet": "",
      "Acknowledged": `We are aware of the ${signal.category.toLowerCase()} issue in ${signal.area} and are investigating.`,
      "Teams dispatched": `Technical teams have been dispatched to ${signal.area} to investigate the ${signal.category.toLowerCase()} issue.`,
      "Teams on site": `Our team is now on site at ${signal.area} assessing the situation.`,
      "Work ongoing": `Repair work is in progress at ${signal.area}. We are working to resolve the issue.`,
      "Restoration in progress": `${signal.category} restoration is underway in ${signal.area}. Service should be restored soon.`,
      "Service restored": `${signal.category} service has been restored in ${signal.area}. Thank you for your patience.`,
    }

    // Show feedback
    setCompletedAction(action)
    setShowFeedback(true)

    // Submit after brief delay for feedback
    setTimeout(() => {
      onUpdatePosted(signal.id, action, messages[action])
      setCompletedAction(null)
      setShowFeedback(false)
    }, 500)
  }

  const handleUpdateSubmitted = (status: ResponseStatus, message: string, expectedResolution?: string) => {
    onUpdatePosted(signal.id, status, message, expectedResolution)
    setShowPostUpdate(false)
  }

  const TrendIcon = {
    Growing: TrendingUp,
    Stable: Minus,
    Slowing: TrendingDown,
    "Possible restoration": RotateCcw,
  }[signal.trend]

  const trendColor = {
    Growing: "text-red-600",
    Stable: "text-slate-500",
    Slowing: "text-blue-600",
    "Possible restoration": "text-emerald-600",
  }[signal.trend]

  // Determine which actions to show based on current status
  const getAvailableActions = () => {
    const status = signal.responseStatus
    const actions: { label: string; status: ResponseStatus; icon: React.ElementType; variant?: string }[] = []

    if (status === "No official update yet") {
      actions.push({ label: "Acknowledge", status: "Acknowledged", icon: Eye })
    }
    if (status === "No official update yet" || status === "Acknowledged") {
      actions.push({ label: "Dispatch Teams", status: "Teams dispatched", icon: Truck })
    }
    if (status === "Teams dispatched") {
      actions.push({ label: "Teams On Site", status: "Teams on site", icon: Radio })
    }
    if (status === "Teams on site") {
      actions.push({ label: "Work Ongoing", status: "Work ongoing", icon: Wrench })
    }
    if (status === "Work ongoing" || status === "Teams on site" || status === "Teams dispatched") {
      actions.push({ label: "Restoration in Progress", status: "Restoration in progress", icon: RotateCcw })
    }
    if (status !== "Service restored") {
      actions.push({ label: "Service Restored", status: "Service restored", icon: CheckCircle, variant: "success" })
    }

    return actions
  }

  const availableActions = getAvailableActions()

  return (
    <>
      <div className="fixed inset-y-0 right-0 z-50 flex w-full max-w-xl flex-col border-l border-border bg-background shadow-xl">
        <div className="flex items-center justify-between border-b border-border px-6 py-4">
          <div className="flex items-center gap-3">
            <h2 className="text-lg font-semibold">Signal Detail</h2>
            {showFeedback && (
              <span className="flex items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-medium text-emerald-700 animate-in fade-in slide-in-from-left-2 duration-200">
                <Check className="h-3.5 w-3.5" />
                Update posted
              </span>
            )}
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          <div className="flex flex-col gap-6">
            <div>
              <div className="mb-3 flex items-center gap-2">
                <CategoryBadge category={signal.category} />
                <ConditionBadge condition={signal.condition} />
                <ResponseStatusBadge status={signal.responseStatus} />
              </div>
              <h3 className="mb-2 text-xl font-semibold">{signal.title}</h3>
              <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1">
                  <MapPin className="h-4 w-4" />
                  {signal.location}
                </span>
                <span className="flex items-center gap-1">
                  <Users className="h-4 w-4" />
                  {signal.affectedCount} affected
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  Active for {signal.timeActive}
                </span>
              </div>
            </div>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-sm font-medium">
                  <AlertCircle className="h-4 w-4 text-primary" />
                  Citizen Signal Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm">
                <p className="mb-3 text-muted-foreground">{signal.citizenSummary}</p>
                <div className="rounded-lg bg-secondary/50 p-3">
                  <p className="text-xs text-muted-foreground">Current Condition</p>
                  <p className="font-medium">{signal.description}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-sm font-medium">
                  <TrendIcon className={cn("h-4 w-4", trendColor)} />
                  Signal Trend
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <p className={cn("font-medium", trendColor)}>{signal.trend}</p>
                    <p className="text-sm text-muted-foreground">
                      {signal.recentReports} reports in the last hour
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-semibold">{signal.affectedCount}</p>
                    <p className="text-xs text-muted-foreground">Total affected</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-sm font-medium">
                  <MessageSquare className="h-4 w-4 text-primary" />
                  Official Updates
                </CardTitle>
              </CardHeader>
              <CardContent>
                {signal.updates.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No official updates yet</p>
                ) : (
                  <div className="flex flex-col gap-3">
                    {signal.updates.map((update) => (
                      <div
                        key={update.id}
                        className="rounded-lg border border-border bg-secondary/30 p-3"
                      >
                        <div className="mb-1 flex items-center justify-between">
                          <span className="text-xs font-medium text-primary">
                            {update.stage}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {update.timestamp}
                          </span>
                        </div>
                        <p className="text-sm">{update.message}</p>
                        {update.expectedResolution && (
                          <p className="mt-1 text-xs text-muted-foreground">
                            Expected resolution: {update.expectedResolution}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Response Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {availableActions.map((action) => {
                    const isCompleted = completedAction === action.status
                    return (
                      <Button
                        key={action.status}
                        size="sm"
                        variant="outline"
                        className={cn(
                          "transition-all",
                          action.variant === "success" && "border-emerald-200 text-emerald-700 hover:bg-emerald-50",
                          isCompleted && "border-emerald-500 bg-emerald-50 text-emerald-700"
                        )}
                        onClick={() => handleQuickAction(action.status)}
                        disabled={completedAction !== null}
                      >
                        {isCompleted ? (
                          <Check className="mr-1 h-3.5 w-3.5" />
                        ) : (
                          <action.icon className="mr-1 h-3.5 w-3.5" />
                        )}
                        {action.label}
                      </Button>
                    )
                  })}
                  <Button
                    size="sm"
                    onClick={() => setShowPostUpdate(true)}
                    disabled={completedAction !== null}
                  >
                    <MessageSquare className="mr-1 h-3.5 w-3.5" />
                    Post Update
                  </Button>
                </div>
                <p className="mt-3 text-xs text-muted-foreground">
                  These actions add official state in parallel. Citizen signals remain
                  visible as public lived experience.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {showPostUpdate && (
        <PostUpdateModal
          signal={signal}
          onClose={() => setShowPostUpdate(false)}
          onSubmit={handleUpdateSubmitted}
        />
      )}
    </>
  )
}

function CategoryBadge({ category }: { category: string }) {
  const colors: Record<string, string> = {
    Power: "bg-amber-100 text-amber-700",
    Water: "bg-blue-100 text-blue-700",
    Roads: "bg-slate-100 text-slate-700",
    Drainage: "bg-cyan-100 text-cyan-700",
    Waste: "bg-orange-100 text-orange-700",
    Traffic: "bg-rose-100 text-rose-700",
  }

  return (
    <span
      className={cn(
        "rounded-full px-2.5 py-0.5 text-xs font-medium",
        colors[category] || "bg-slate-100 text-slate-700"
      )}
    >
      {category}
    </span>
  )
}

function ConditionBadge({ condition }: { condition: string }) {
  const colors = {
    Active: "bg-red-100 text-red-700",
    Elevated: "bg-amber-100 text-amber-700",
    Calm: "bg-emerald-100 text-emerald-700",
  }

  return (
    <span
      className={cn(
        "rounded-full px-2.5 py-0.5 text-xs font-medium",
        colors[condition as keyof typeof colors]
      )}
    >
      {condition}
    </span>
  )
}

function ResponseStatusBadge({ status }: { status: string }) {
  const statusColors: Record<string, string> = {
    "No official update yet": "bg-slate-100 text-slate-600",
    Acknowledged: "bg-blue-100 text-blue-700",
    "Teams dispatched": "bg-indigo-100 text-indigo-700",
    "Teams on site": "bg-purple-100 text-purple-700",
    "Work ongoing": "bg-amber-100 text-amber-700",
    "Restoration in progress": "bg-teal-100 text-teal-700",
    "Service restored": "bg-emerald-100 text-emerald-700",
  }

  return (
    <span
      className={cn(
        "rounded-full px-2.5 py-0.5 text-xs font-medium",
        statusColors[status] || "bg-slate-100 text-slate-600"
      )}
    >
      {status}
    </span>
  )
}
