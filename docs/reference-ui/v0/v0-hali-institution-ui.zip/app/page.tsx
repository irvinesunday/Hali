"use client"

import { useState, useMemo, useCallback, useEffect } from "react"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Topbar } from "@/components/dashboard/topbar"
import { Overview } from "@/components/dashboard/overview"
import { LiveSignals } from "@/components/dashboard/live-signals"
import { SignalDetail } from "@/components/dashboard/signal-detail"
import { Areas } from "@/components/dashboard/areas"
import { Metrics } from "@/components/dashboard/metrics"
import { signals as initialSignals, activityFeed as initialActivityFeed, initialNotifications } from "@/lib/demo-data"
import type { Signal, ResponseStatus, Institution, ActivityItem, OfficialUpdate, DrilldownFilterType, Notification, SignalCategory } from "@/lib/types"
import { institutionCategories } from "@/lib/types"

export default function Dashboard() {
  const [activeView, setActiveView] = useState("overview")
  const [institution, setInstitution] = useState<Institution>("Kenya Power")
  const [selectedArea, setSelectedArea] = useState("All Areas")
  const [selectedSignal, setSelectedSignal] = useState<Signal | null>(null)
  const [signals, setSignals] = useState<Signal[]>(initialSignals)
  const [activityFeed, setActivityFeed] = useState<ActivityItem[]>(initialActivityFeed)
  const [notifications, setNotifications] = useState<Notification[]>(initialNotifications)
  const [drilldownFilter, setDrilldownFilter] = useState<DrilldownFilterType>(null)
  const [isRefreshing, setIsRefreshing] = useState(false)

  // Get categories relevant to the selected institution
  const relevantCategories = institutionCategories[institution]

  // Filter signals by institution scope and area
  const filteredSignals = useMemo(() => {
    return signals.filter((signal) => {
      const categoryMatch = relevantCategories.includes(signal.category)
      const areaMatch = selectedArea === "All Areas" || signal.area === selectedArea
      return categoryMatch && areaMatch
    })
  }, [signals, relevantCategories, selectedArea])

  // Filter activity feed by institution scope and area
  const filteredActivityFeed = useMemo(() => {
    return activityFeed.filter((item) => {
      const relatedSignal = filteredSignals.find((signal) =>
        item.message.toLowerCase().includes(signal.area.toLowerCase()) ||
        item.message.toLowerCase().includes(signal.category.toLowerCase())
      )
      return relatedSignal !== undefined
    })
  }, [activityFeed, filteredSignals])

  // Filter notifications by institution scope and area
  const filteredNotifications = useMemo(() => {
    return notifications.filter((notification) => {
      if (notification.category && !relevantCategories.includes(notification.category)) {
        return false
      }
      if (selectedArea !== "All Areas" && notification.area && notification.area !== selectedArea) {
        return false
      }
      return true
    })
  }, [notifications, relevantCategories, selectedArea])

  // Helper to generate a random signal title based on category
  const generateSignalTitle = useCallback((category: SignalCategory, area: string) => {
    const titles: Record<SignalCategory, string[]> = {
      Power: [
        `Power outage affecting ${area}`,
        `Voltage fluctuations reported in ${area}`,
        `Transformer issue near ${area}`,
        `Electricity supply disruption in ${area}`,
      ],
      Water: [
        `Low water pressure in ${area}`,
        `Water outage affecting ${area}`,
        `Discolored water reported in ${area}`,
        `No water supply in parts of ${area}`,
      ],
      Roads: [
        `Pothole damage on main road in ${area}`,
        `Road surface deterioration in ${area}`,
        `Traffic hazard from road damage in ${area}`,
      ],
      Traffic: [
        `Traffic signal malfunction in ${area}`,
        `Traffic congestion reported in ${area}`,
        `Road blocked near ${area}`,
      ],
      Drainage: [
        `Street flooding near ${area}`,
        `Blocked drains causing flooding in ${area}`,
        `Drainage overflow in ${area}`,
      ],
      Waste: [
        `Uncollected garbage in ${area}`,
        `Waste accumulation reported in ${area}`,
        `Illegal dumping near ${area}`,
      ],
    }
    const options = titles[category]
    return options[Math.floor(Math.random() * options.length)]
  }, [])

  // Simulate one small believable update scoped to institution and area
  const simulateOneUpdate = useCallback(() => {
    const updateType = Math.random()
    const categoryOptions = relevantCategories
    const randomCategory = categoryOptions[Math.floor(Math.random() * categoryOptions.length)]
    
    // Get signals that match current institution scope and area filter
    const scopedSignals = signals.filter((s) => {
      const categoryMatch = relevantCategories.includes(s.category)
      const areaMatch = selectedArea === "All Areas" || s.area === selectedArea
      return categoryMatch && areaMatch && s.responseStatus !== "Service restored"
    })

    if (updateType < 0.25 && scopedSignals.length > 0) {
      // Increase reports on an existing signal
      const randomSignal = scopedSignals[Math.floor(Math.random() * scopedSignals.length)]
      const increment = Math.floor(Math.random() * 12) + 2
      
      setSignals((prev) =>
        prev.map((s) =>
          s.id === randomSignal.id
            ? {
                ...s,
                affectedCount: s.affectedCount + increment,
                recentReports: s.recentReports + Math.floor(Math.random() * 3) + 1,
              }
            : s
        )
      )

      // Add activity feed item
      setActivityFeed((prev) => [
        {
          id: `act-${Date.now()}`,
          message: `${randomSignal.category} issue in ${randomSignal.area} gaining reports`,
          timestamp: "Just now",
          type: "growing",
        },
        ...prev.slice(0, 14),
      ])
    } else if (updateType < 0.5 && scopedSignals.length > 0) {
      // Move a signal to a new stage
      const eligibleSignals = scopedSignals.filter(
        (s) => s.trend === "Growing" || s.responseStatus === "Work ongoing"
      )
      if (eligibleSignals.length > 0) {
        const randomSignal = eligibleSignals[Math.floor(Math.random() * eligibleSignals.length)]
        
        setSignals((prev) =>
          prev.map((s) => {
            if (s.id === randomSignal.id) {
              if (s.trend === "Growing") {
                return { ...s, trend: "Stable" }
              } else if (s.responseStatus === "Work ongoing") {
                return { ...s, trend: "Slowing", condition: "Elevated" }
              }
            }
            return s
          })
        )

        setActivityFeed((prev) => [
          {
            id: `act-${Date.now()}`,
            message: `${randomSignal.category} issue in ${randomSignal.area} is stabilizing`,
            timestamp: "Just now",
            type: "stabilizing",
          },
          ...prev.slice(0, 14),
        ])
      }
    } else if (updateType < 0.7) {
      // Add a notification
      if (scopedSignals.length > 0) {
        const randomSignal = scopedSignals[Math.floor(Math.random() * scopedSignals.length)]
        const notifTypes: Notification["type"][] = ["growing", "needs_attention", "restoration"]
        const notifType = notifTypes[Math.floor(Math.random() * notifTypes.length)]
        
        const messages: Record<Notification["type"], string> = {
          growing: `${randomSignal.category} issue in ${randomSignal.area} gaining attention`,
          needs_attention: `${randomSignal.category} issue in ${randomSignal.area} may need response`,
          restoration: `${randomSignal.category} issue in ${randomSignal.area} showing improvement`,
          new_signal: "",
          update_posted: "",
          restored: "",
        }

        setNotifications((prev) => [
          {
            id: `notif-${Date.now()}`,
            message: messages[notifType],
            timestamp: "Just now",
            type: notifType,
            signalId: randomSignal.id,
            category: randomSignal.category,
            area: randomSignal.area,
          },
          ...prev.slice(0, 14),
        ])
      }
    } else {
      // Add a new signal (rarely)
      const areaOptions = selectedArea === "All Areas" 
        ? ["South B", "Nairobi West", "Industrial Area", "Upper Hill", "Kilimani", "Lavington"]
        : [selectedArea]
      const randomArea = areaOptions[Math.floor(Math.random() * areaOptions.length)]
      
      const newSignal: Signal = {
        id: `sig-${Date.now()}`,
        title: generateSignalTitle(randomCategory, randomArea),
        area: randomArea,
        category: randomCategory,
        condition: "Active",
        affectedCount: Math.floor(Math.random() * 100) + 20,
        trend: "Growing",
        timeActive: "5 min",
        responseStatus: "No official update yet",
        description: `New reports coming in about ${randomCategory.toLowerCase()} issues in ${randomArea}.`,
        citizenSummary: `Citizens reporting ${randomCategory.toLowerCase()} problems in the area.`,
        recentReports: Math.floor(Math.random() * 10) + 3,
        location: randomArea,
        updates: [],
      }

      setSignals((prev) => [newSignal, ...prev])
      
      setActivityFeed((prev) => [
        {
          id: `act-${Date.now()}`,
          message: `New ${randomCategory.toLowerCase()} signal emerging in ${randomArea}`,
          timestamp: "Just now",
          type: "growing",
        },
        ...prev.slice(0, 14),
      ])

      setNotifications((prev) => [
        {
          id: `notif-${Date.now()}`,
          message: `New ${randomCategory.toLowerCase()} signal in ${randomArea}`,
          timestamp: "Just now",
          type: "new_signal",
          signalId: newSignal.id,
          category: randomCategory,
          area: randomArea,
        },
        ...prev.slice(0, 14),
      ])
    }
  }, [signals, relevantCategories, selectedArea, generateSignalTitle])

  // Background live updates - every 20-40 seconds
  useEffect(() => {
    const getRandomInterval = () => Math.floor(Math.random() * 20000) + 20000 // 20-40 seconds
    
    let timeoutId: NodeJS.Timeout

    const scheduleNextUpdate = () => {
      timeoutId = setTimeout(() => {
        simulateOneUpdate()
        scheduleNextUpdate()
      }, getRandomInterval())
    }

    scheduleNextUpdate()

    return () => clearTimeout(timeoutId)
  }, [simulateOneUpdate])

  // Manual refresh handler
  const handleRefreshActivity = useCallback(() => {
    setIsRefreshing(true)
    
    // Simulate a small burst of 1-2 updates
    simulateOneUpdate()
    if (Math.random() > 0.5) {
      setTimeout(() => simulateOneUpdate(), 300)
    }
    
    setTimeout(() => setIsRefreshing(false), 500)
  }, [simulateOneUpdate])

  // Add notification helper
  const addNotification = useCallback((message: string, type: Notification["type"], signal?: Signal) => {
    const newNotification: Notification = {
      id: `notif-${Date.now()}`,
      message,
      timestamp: "Just now",
      type,
      signalId: signal?.id,
      category: signal?.category,
      area: signal?.area,
    }
    setNotifications((prev) => [newNotification, ...prev.slice(0, 19)]) // Keep max 20
  }, [])

// Keep selected signal in sync with live updates
  useEffect(() => {
    if (selectedSignal) {
      const updated = signals.find((s) => s.id === selectedSignal.id)
      if (updated && (
        updated.affectedCount !== selectedSignal.affectedCount ||
        updated.trend !== selectedSignal.trend ||
        updated.condition !== selectedSignal.condition ||
        updated.recentReports !== selectedSignal.recentReports
      )) {
        setSelectedSignal(updated)
      }
    }
  }, [signals, selectedSignal])

  const handleSelectSignal = (signal: Signal) => {
    setSelectedSignal(signal)
  }

  const handleCloseSignalDetail = () => {
    setSelectedSignal(null)
  }

  // Handle notification click - find and open the related signal
  const handleNotificationClick = useCallback((notification: Notification) => {
    if (notification.signalId) {
      const signal = signals.find((s) => s.id === notification.signalId)
      if (signal) {
        // Navigate to signals view and open the signal detail
        setActiveView("signals")
        setSelectedSignal(signal)
      }
    } else if (notification.area) {
      // If no specific signal but has area, navigate to that area
      setSelectedArea(notification.area)
      setActiveView("signals")
    }
  }, [signals])

  const handleUpdatePosted = useCallback((signalId: string, status: ResponseStatus, message: string, expectedResolution?: string) => {
    const timestamp = new Date().toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })
    
    // Find the signal for notifications
    const signal = signals.find((s) => s.id === signalId)
    
    // Determine new trend and condition based on status
    const getNewTrendAndCondition = (currentSignal: Signal, newStatus: ResponseStatus) => {
      let trend = currentSignal.trend
      let condition = currentSignal.condition

      switch (newStatus) {
        case "Acknowledged":
        case "Teams dispatched":
          // Signal is being addressed, may start slowing
          if (currentSignal.trend === "Growing") {
            trend = "Stable"
          }
          break
        case "Teams on site":
        case "Work ongoing":
          trend = "Slowing"
          condition = currentSignal.condition === "Active" ? "Elevated" : currentSignal.condition
          break
        case "Restoration in progress":
          trend = "Possible restoration"
          condition = "Elevated"
          break
        case "Service restored":
          trend = "Possible restoration"
          condition = "Calm"
          break
      }

      return { trend, condition }
    }

    // Update the signal
    setSignals((prev) =>
      prev.map((s) => {
        if (s.id === signalId) {
          const { trend, condition } = getNewTrendAndCondition(s, status)
          const newUpdate: OfficialUpdate = {
            id: `upd-${Date.now()}`,
            stage: status,
            message,
            timestamp,
            affectedAreas: [s.area],
            expectedResolution,
          }
          return {
            ...s,
            responseStatus: status,
            updates: [...s.updates, newUpdate],
            trend,
            condition,
          }
        }
        return s
      })
    )

    // Update selected signal if it's the one being updated
    setSelectedSignal((prev) => {
      if (prev && prev.id === signalId) {
        const { trend, condition } = getNewTrendAndCondition(prev, status)
        const newUpdate: OfficialUpdate = {
          id: `upd-${Date.now()}`,
          stage: status,
          message,
          timestamp,
          affectedAreas: [prev.area],
          expectedResolution,
        }
        return {
          ...prev,
          responseStatus: status,
          updates: [...prev.updates, newUpdate],
          trend,
          condition,
        }
      }
      return prev
    })

    // Add to activity feed
    if (signal) {
      let activityMessage: string
      let activityType: ActivityItem["type"]

      switch (status) {
        case "Service restored":
          activityMessage = `Service restored for ${signal.category.toLowerCase()} issue in ${signal.area}`
          activityType = "restoration"
          break
        case "Restoration in progress":
          activityMessage = `${signal.category} restoration underway in ${signal.area}`
          activityType = "restoration"
          break
        default:
          activityMessage = `Official update posted for ${signal.area} ${signal.category.toLowerCase()} issue`
          activityType = "update"
      }

      setActivityFeed((prev) => [
        {
          id: `act-${Date.now()}`,
          message: activityMessage,
          timestamp: "Just now",
          type: activityType,
        },
        ...prev,
      ])

      // Add notification
      let notifMessage: string
      let notifType: Notification["type"]

      switch (status) {
        case "Service restored":
          notifMessage = `Service restored for ${signal.category.toLowerCase()} issue in ${signal.area}`
          notifType = "restored"
          break
        case "Restoration in progress":
          notifMessage = `${signal.category} restoration in progress for ${signal.area}`
          notifType = "restoration"
          break
        default:
          notifMessage = `Official update posted for ${signal.area} ${signal.category.toLowerCase()} issue`
          notifType = "update_posted"
      }

      addNotification(notifMessage, notifType, signal)
    }
  }, [signals, addNotification])

  const handleSelectArea = useCallback((area: string) => {
    setSelectedArea(area)
    setDrilldownFilter(null)
    setActiveView("signals")
  }, [])

  const handleDrilldown = useCallback((filterType: DrilldownFilterType) => {
    setDrilldownFilter(filterType)
    setActiveView("signals")
  }, [])

  const handleClearDrilldown = useCallback(() => {
    setDrilldownFilter(null)
  }, [])

  const renderView = () => {
    switch (activeView) {
      case "overview":
        return (
          <Overview
            signals={filteredSignals}
            activityFeed={filteredActivityFeed}
            selectedArea={selectedArea}
            institution={institution}
            onDrilldown={handleDrilldown}
            onSelectArea={handleSelectArea}
          />
        )
      case "signals":
        return (
          <LiveSignals
            signals={filteredSignals}
            onSelectSignal={handleSelectSignal}
            selectedArea={selectedArea}
            institution={institution}
            drilldownFilter={drilldownFilter}
            onClearDrilldown={handleClearDrilldown}
          />
        )
      case "areas":
        return (
          <Areas
            signals={filteredSignals}
            onSelectArea={handleSelectArea}
            institution={institution}
          />
        )
      case "metrics":
        return (
          <Metrics
            signals={filteredSignals}
            selectedArea={selectedArea}
            institution={institution}
          />
        )
      default:
        return (
          <Overview
            signals={filteredSignals}
            activityFeed={filteredActivityFeed}
            selectedArea={selectedArea}
            institution={institution}
            onDrilldown={handleDrilldown}
            onSelectArea={handleSelectArea}
          />
        )
    }
  }

  return (
    <>
      {/* Small screen message */}
      <div className="fixed inset-0 z-[100] flex items-center justify-center bg-background p-8 lg:hidden">
        <div className="max-w-md text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-xl bg-primary">
            <span className="text-2xl font-bold text-primary-foreground">H</span>
          </div>
          <h1 className="mb-2 text-xl font-semibold">Hali Institution Dashboard</h1>
          <p className="text-muted-foreground">
            This dashboard is optimized for desktop and laptop screens. Please use a device with a larger display for the best experience.
          </p>
        </div>
      </div>

      {/* Main dashboard - hidden on small screens */}
      <div className="hidden min-h-screen min-w-[1024px] bg-background lg:block">
        <Sidebar activeView={activeView} onViewChange={setActiveView} />
<Topbar
  institution={institution}
  selectedArea={selectedArea}
  onInstitutionChange={setInstitution}
  onAreaChange={setSelectedArea}
  notifications={filteredNotifications}
  onNotificationClick={handleNotificationClick}
  onRefreshActivity={handleRefreshActivity}
  isRefreshing={isRefreshing}
  />
        <main className="ml-56 pt-16">
          <div className="p-6">{renderView()}</div>
        </main>

        {selectedSignal && (
          <SignalDetail
            signal={selectedSignal}
            onClose={handleCloseSignalDetail}
            onUpdatePosted={handleUpdatePosted}
          />
        )}
      </div>
    </>
  )
}
