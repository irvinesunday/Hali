export type SignalCategory = "Power" | "Water" | "Roads" | "Drainage" | "Waste" | "Traffic"

export type Institution = "Kenya Power" | "Nairobi Water" | "KenHA / KURA" | "Nairobi County"

export const institutionCategories: Record<Institution, SignalCategory[]> = {
  "Kenya Power": ["Power"],
  "Nairobi Water": ["Water"],
  "KenHA / KURA": ["Roads", "Traffic"],
  "Nairobi County": ["Drainage", "Waste"],
}

export type SignalCondition = "Active" | "Elevated" | "Calm"

export type SignalTrend = "Growing" | "Stable" | "Slowing" | "Possible restoration"

export type ResponseStatus =
  | "No official update yet"
  | "Acknowledged"
  | "Teams dispatched"
  | "Teams on site"
  | "Work ongoing"
  | "Restoration in progress"
  | "Service restored"

export interface Signal {
  id: string
  title: string
  area: string
  category: SignalCategory
  condition: SignalCondition
  affectedCount: number
  trend: SignalTrend
  timeActive: string
  responseStatus: ResponseStatus
  description: string
  citizenSummary: string
  recentReports: number
  location: string
  updates: OfficialUpdate[]
}

export interface OfficialUpdate {
  id: string
  stage: ResponseStatus
  message: string
  timestamp: string
  affectedAreas: string[]
  expectedResolution?: string
}

export interface Area {
  id: string
  name: string
  status: SignalCondition
  activeSignals: number
  topCategory: SignalCategory | null
  lastUpdated: string
}

export interface ActivityItem {
  id: string
  message: string
  timestamp: string
  type: "growing" | "stabilizing" | "update" | "restoration"
}

export type DrilldownFilterType = "active" | "growing" | "updates-today" | "stabilized-today" | null

export interface DrilldownFilter {
  type: DrilldownFilterType
  label: string
}

export interface Notification {
  id: string
  message: string
  timestamp: string
  type: "new_signal" | "growing" | "needs_attention" | "restoration" | "update_posted" | "restored"
  signalId?: string
  category?: SignalCategory
  area?: string
}
